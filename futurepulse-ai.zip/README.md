# FuturePulse AI

FuturePulse AI is a futuristic Health & Career Predictive application built with React, TypeScript, and Tailwind CSS.

## Features

- **Health Scan Module**: Simulated bio-data scanning (PPG/Retina) with predictive analytics.
- **Career Projection Module**: AI-driven career path forecasting based on education, skills, and interests.
- **Responsive UI**: Designed for mobile-first experiences.

## Setup

### Prerequisites
- Node.js (v18+)
- npm

### Installation
```bash
npm install
```

### Development
```bash
npm run dev
```

### Build
```bash
npm run build
```

## Deployment
This project is optimized for deployment on standard web platforms. Ensure the `VITE_` environment variables are configured in your production environment.
