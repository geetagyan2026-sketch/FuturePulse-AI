import React, {useState, useEffect, useRef} from 'react';
import {motion, AnimatePresence} from 'motion/react';
import {
  Camera, User, Activity, Brain, ShieldAlert, History, Share2, Sparkles,
  Building2, Radio, Volume2, Eye, HeartPulse, Stethoscope, ChevronRight,
  CheckCircle2, AlertTriangle, ArrowRight, Smartphone, Bluetooth,
  X, Heart, Zap, Calendar, ExternalLink
} from 'lucide-react';
import {jsPDF} from 'jspdf';
import {TextToSpeech} from '@capacitor-community/text-to-speech';
import {
  runCareerPrediction,
  runCompanyTrustForecast,
  runComprehensiveHealthAnalysis,
  runDiseaseRadar,
  runEyeScanAnalysis,
  runLabReportAnalysis,
  runMacroForecast,
  runOrgForecast,
  runPersonalFutureForecast,
} from './lib/geminiService';

type Screen = 'splash' | 'dashboard' | 'health' | 'career' | 'intelligence' | 'org' | 'history' | 'partnerships' | 'company' | 'disease_radar';

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash');
  const [history, setHistory] = useState<any[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('futurepulse_history');
    if (saved) {
      try { setHistory(JSON.parse(saved)); } catch(e) {}
    }
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => (prev === msg ? null : prev));
    }, 3500);
  };

  const saveToHistory = (title: string, summary: string) => {
    const newItem = {id: Date.now(), title, summary, date: new Date().toLocaleDateString()};
    const updated = [newItem, ...history];
    setHistory(updated);
    localStorage.setItem('futurepulse_history', JSON.stringify(updated));
  };

  const handleShare = (text: string, title: string = 'FuturePulse AI Report') => {
    if (navigator.share) {
      navigator.share({title, text}).catch(() => {});
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        showToast('Report copied to clipboard for sharing.');
      }).catch(() => {
        showToast('Report ready to share.');
      });
    }
  };

  const navItems = [
    {id: 'dashboard' as Screen, label: 'Personal Future', icon: <Activity className="w-4 h-4 text-cyan-400" />},
    {id: 'health' as Screen, label: 'Health & Disease', icon: <HeartPulse className="w-4 h-4 text-emerald-400" />},
    {id: 'company' as Screen, label: 'Company & Trust', icon: <Building2 className="w-4 h-4 text-amber-400" />},
    {id: 'disease_radar' as Screen, label: 'Disease Radar', icon: <Radio className="w-4 h-4 text-rose-400" />},
    {id: 'career' as Screen, label: 'Career Projection', icon: <Brain className="w-4 h-4 text-cyan-400" />},
    {id: 'intelligence' as Screen, label: 'Macro Intel', icon: <ShieldAlert className="w-4 h-4 text-violet-400" />},
    {id: 'org' as Screen, label: 'Enterprise Disruption', icon: <User className="w-4 h-4 text-fuchsia-400" />},
  ];

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 font-sans selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Subtle Ambient Glowing Background Gradients */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1100px] h-[500px] bg-gradient-to-b from-cyan-500/10 via-blue-600/5 to-transparent blur-3xl opacity-60" />
        <div className="absolute bottom-10 right-10 w-[550px] h-[550px] bg-fuchsia-600/5 blur-3xl rounded-full" />
        <div className="absolute top-1/3 left-10 w-[450px] h-[450px] bg-emerald-500/5 blur-3xl rounded-full" />
      </div>

      {/* In-App Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{opacity: 0, y: -16}}
            animate={{opacity: 1, y: 0}}
            exit={{opacity: 0, y: -16}}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-[70] pointer-events-none max-w-sm w-[92%] px-4 py-3 rounded-2xl bg-slate-900/95 border border-cyan-500/50 text-xs font-mono text-cyan-100 shadow-[0_8px_30px_rgba(6,182,212,0.35)] flex items-center gap-2.5 backdrop-blur-xl"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="flex-1">{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        {screen === 'splash' && <SplashScreen setScreen={setScreen} />}
        {screen !== 'splash' && (
          <motion.div
            key="main"
            initial={{opacity: 0, y: 15}}
            animate={{opacity: 1, y: 0}}
            transition={{duration: 0.3}}
            className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 pt-4 pb-28"
          >
            {/* Sleek Top Header with Zero Overlap */}
            <header className="mb-6 space-y-3">
              {/* Top Navigation Row */}
              <div className="flex items-center justify-between gap-2 p-3.5 sm:p-4 rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 shadow-[0_8px_30px_rgba(0,0,0,0.4)]">
                <div 
                  onClick={() => setScreen('dashboard')}
                  className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group min-w-0"
                >
                  <div className="w-9 h-9 sm:w-10 sm:h-10 shrink-0 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-[0_0_18px_rgba(6,182,212,0.35)]">
                    <div className="w-full h-full bg-[#070b14] rounded-[10px] flex items-center justify-center">
                      <Sparkles className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
                    </div>
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h1 className="text-base sm:text-xl font-bold font-mono tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-blue-300 truncate">
                        FuturePulse AI
                      </h1>
                      <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-widest bg-cyan-950/80 text-cyan-400 border border-cyan-500/30">
                        v4.5 INTEL
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-mono hidden sm:block">
                      Fintech & Bio-Predictive Intelligence Engine
                    </p>
                  </div>
                </div>

                {/* Right Quick Controls */}
                <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
                  <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-[10px] font-mono font-semibold text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    REAL-TIME SEARCH ENGINE
                  </div>

                  <button 
                    onClick={() => setScreen('partnerships')} 
                    className={`px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-mono font-medium transition-all ${
                      screen === 'partnerships'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                        : 'bg-slate-800/70 hover:bg-slate-700/70 border-slate-700/80 text-slate-300 hover:text-cyan-300'
                    }`}
                  >
                    Enterprise
                  </button>

                  <button 
                    onClick={() => setScreen('history')} 
                    className={`relative p-2 rounded-xl border transition-all ${
                      screen === 'history'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                        : 'bg-slate-800/70 hover:bg-slate-700/70 border-slate-700/80 text-amber-400'
                    }`}
                    title="Forecast History"
                    aria-label="Forecast History"
                  >
                    <History className="w-4 h-4" />
                    {history.length > 0 && (
                      <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-amber-500 text-black text-[9px] font-mono font-bold flex items-center justify-center">
                        {history.length}
                      </span>
                    )}
                  </button>
                </div>
              </div>

              {/* Horizontally Scrollable Glassmorphic Pill Dock (Zero Overlap on any screen) */}
              <div className="p-1.5 rounded-2xl bg-slate-900/40 backdrop-blur-xl border border-slate-800/60 overflow-x-auto scrollbar-none shadow-inner">
                <div className="flex items-center gap-1.5 min-w-max">
                  {navItems.map(item => (
                    <button
                      key={item.id}
                      onClick={() => setScreen(item.id)}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-mono font-semibold transition-all whitespace-nowrap ${
                        screen === item.id
                          ? 'bg-gradient-to-r from-cyan-500/25 to-blue-500/25 text-cyan-200 border border-cyan-500/45 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
                      }`}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </header>

            {/* Main Active Screen */}
            <main>
              {screen === 'dashboard' && <Dashboard setScreen={setScreen} saveHistory={saveToHistory} onShare={handleShare} onNotify={showToast} />}
              {screen === 'health' && <HealthScan saveHistory={saveToHistory} onShare={handleShare} onNotify={showToast} />}
              {screen === 'company' && <CompanyTrustForecast saveHistory={saveToHistory} onShare={handleShare} onNotify={showToast} />}
              {screen === 'disease_radar' && <DiseaseRadarForecast saveHistory={saveToHistory} onShare={handleShare} onNotify={showToast} />}
              {screen === 'career' && <CareerPrediction saveHistory={saveToHistory} onShare={handleShare} onNotify={showToast} />}
              {screen === 'intelligence' && <GlobalHealthIntelligence saveHistory={saveToHistory} onShare={handleShare} onNotify={showToast} />}
              {screen === 'org' && <OrgForecasting saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'partnerships' && <PartnershipsDesk saveHistory={saveToHistory} />}
              {screen === 'history' && <HistoryLog history={history} setScreen={setScreen} />}
            </main>

            {/* Mandatory Medical & Financial Disclaimer Footer */}
            <footer className="mt-10 p-4 sm:p-5 rounded-2xl bg-slate-900/50 backdrop-blur-md border border-slate-800/80 text-[11px] font-mono text-slate-400 leading-relaxed">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-slate-200 font-bold">
                    Mandatory Medical, Financial & Intelligence Disclaimer
                  </p>
                  <p>
                    All health screenings, optical pulse estimates, disease risk projections, financial/career roadmaps, business probability scores, and geopolitical simulations generated by FuturePulse AI are AI-generated estimates for educational and informational purposes only. They do not constitute licensed medical diagnosis, clinical treatment, legal counsel, or professional financial/investment advice. Always consult qualified healthcare professionals and certified financial advisors before making critical decisions.
                  </p>
                </div>
              </div>
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ApiErrorBanner({
  message,
}: {
  message: string | null;
}) {
  if (!message) return null;
  return (
    <div className="p-4 rounded-2xl bg-red-950/60 border border-red-500/60 text-xs text-red-400 flex items-start gap-2">
      <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
      <span className="leading-relaxed text-red-400 font-semibold break-words">{message}</span>
    </div>
  );
}

function GroundedSourcesList({sources}: {sources?: Array<{title: string; uri: string}>}) {
  if (!sources || sources.length === 0) return null;
  return (
    <div className="p-4 bg-black/50 rounded-2xl border border-slate-800 space-y-2">
      <p className="text-[11px] font-bold text-cyan-300 uppercase tracking-wider">
        Verified Real-Time Web Sources
      </p>
      <div className="flex flex-wrap gap-2">
        {sources.slice(0, 6).map((s, idx) => (
          <a
            key={idx}
            href={s.uri}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-[11px] text-cyan-200 transition-colors max-w-full"
          >
            <span className="truncate max-w-[210px]">{s.title}</span>
            <ExternalLink className="w-3 h-3 shrink-0 text-cyan-400" />
          </a>
        ))}
      </div>
    </div>
  );
}

/* =========================================================================
   REUSABLE DUAL-LANGUAGE VOICE PLAYER (HINDI + ENGLISH)
   ========================================================================= */
function DualVoicePlayer({
  englishText,
  hindiText,
  title,
  className = ""
}: {
  englishText: string;
  hindiText: string;
  title?: string;
  className?: string;
}) {
  const [activeLang, setActiveLang] = useState<'en' | 'hi' | null>(null);

  const cleanText = (raw: string) => {
    return raw
      .replace(/[#*•_`~[\]()]/g, ' ')
      .replace(/\|/g, '. ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const stopAllSpeech = async () => {
    try {
      await TextToSpeech.stop();
    } catch (e) {}
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setActiveLang(null);
  };

  const handleSpeak = async (lang: 'en' | 'hi') => {
    if (activeLang === lang) {
      await stopAllSpeech();
      return;
    }
    await stopAllSpeech();
    setActiveLang(lang);

    const raw = lang === 'hi' ? hindiText : englishText;
    const textToSpeak = cleanText(raw);
    const targetLang = lang === 'hi' ? 'hi-IN' : 'en-US';

    let capacitorSuccess = false;
    try {
      await TextToSpeech.speak({
        text: textToSpeak,
        lang: targetLang,
        rate: 1.0,
        pitch: 1.0,
        volume: 1.0,
        category: 'ambient',
      });
      capacitorSuccess = true;
      setActiveLang(null);
    } catch (err) {
      capacitorSuccess = false;
    }

    if (!capacitorSuccess && typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = targetLang;
      utterance.rate = 0.95;

      const voices = window.speechSynthesis.getVoices();
      if (lang === 'hi') {
        const hiVoice = voices.find(
          v => v.lang.toLowerCase().startsWith('hi') || v.name.toLowerCase().includes('hindi')
        );
        if (hiVoice) utterance.voice = hiVoice;
      } else {
        const enVoice = voices.find(
          v => v.lang.toLowerCase().startsWith('en') || v.name.toLowerCase().includes('english')
        );
        if (enVoice) utterance.voice = enVoice;
      }

      utterance.onend = () => setActiveLang(null);
      utterance.onerror = () => setActiveLang(null);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className={`p-4 rounded-2xl bg-slate-900/50 backdrop-blur-md border border-slate-800/80 space-y-2.5 ${className}`}>
      <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-1.5">
          <Volume2 className="w-4 h-4 text-cyan-400" />
          <span>{title || 'Bilingual Voice Readout / आवाज में सुनें:'}</span>
        </div>
        {activeLang && (
          <span className="text-[10px] text-red-400 font-bold animate-pulse">
            ● PLAYING AUDIO ({activeLang.toUpperCase()})
          </span>
        )}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => handleSpeak('en')}
          className={`py-3 px-4 rounded-xl font-bold font-mono text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
            activeLang === 'en'
              ? 'bg-red-600 text-white animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.6)]'
              : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-[0_0_15px_rgba(6,182,212,0.35)]'
          }`}
        >
          {activeLang === 'en' ? '⏹️ Stop English Audio' : '🔊 Listen (English)'}
        </button>

        <button
          type="button"
          onClick={() => handleSpeak('hi')}
          className={`py-3 px-4 rounded-xl font-bold font-mono text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
            activeLang === 'hi'
              ? 'bg-red-600 text-white animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.6)]'
              : 'bg-amber-500 hover:bg-amber-400 text-black shadow-[0_0_15px_rgba(245,158,11,0.35)]'
          }`}
        >
          {activeLang === 'hi' ? '⏹️ ऑडियो बंद करें' : '🔊 हिंदी में सुनें'}
        </button>
      </div>
    </div>
  );
}

/* =========================================================================
   SPLASH SCREEN
   ========================================================================= */
function SplashScreen({setScreen}: {setScreen: (s: Screen) => void}) {
  return (
    <motion.div
      initial={{opacity: 0}}
      animate={{opacity: 1}}
      exit={{opacity: 0}}
      className="flex flex-col items-center justify-center min-h-screen p-6 text-center relative z-10"
    >
      <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-1 mb-6 shadow-[0_0_40px_rgba(6,182,212,0.5)]">
        <div className="w-full h-full bg-[#070b14] rounded-[22px] flex items-center justify-center">
          <Sparkles className="w-10 h-10 text-cyan-400 animate-pulse" />
        </div>
      </div>

      <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-blue-400 mb-3 font-mono tracking-wider">
        FuturePulse AI
      </h1>
      <p className="text-slate-300 text-sm sm:text-base mb-2 max-w-lg font-mono">
        Enterprise-Grade Fintech & Bio-Predictive Intelligence Engine
      </p>
      <p className="text-slate-400 text-xs max-w-md mb-8 leading-relaxed">
        Real-time multi-modal foresight: Optical PPG pulse scanning, Gemini Vision eye screening, Google Search grounded macro intelligence, and 5-year life & wealth strategy.
      </p>

      {/* Feature Badges Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-xl mb-8 text-[11px] font-mono text-slate-300">
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-cyan-500/30 text-cyan-300">
          ● Torch PPG Sensor
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-emerald-500/30 text-emerald-300">
          ● Gemini Eye Vision
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-amber-500/30 text-amber-300">
          ● Live Search Radar
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-violet-500/30 text-violet-300">
          ● Dual Voice TTS
        </div>
      </div>

      <button
        onClick={() => setScreen('dashboard')}
        className="px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-2xl font-bold font-mono text-white shadow-[0_0_25px_rgba(6,182,212,0.45)] flex items-center gap-2 group transition-all"
      >
        <span>Initialize Intelligence Engine</span>
        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
      </button>
    </motion.div>
  );
}

/* =========================================================================
   HISTORY LOG
   ========================================================================= */
function HistoryLog({history, setScreen}: {history: any[], setScreen: (s: Screen) => void}) {
  return (
    <div className="space-y-6 pb-24 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-amber-500/40">
        <div>
          <h2 className="text-xl font-bold text-amber-300 flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" /> Previous Forecast History
          </h2>
          <p className="text-xs text-slate-400">Locally archived predictions and intelligence dossiers</p>
        </div>
        <button onClick={() => setScreen('dashboard')} className="text-xs text-slate-400 hover:text-cyan-300 underline">
          Back to Dashboard
        </button>
      </div>

      {history.length === 0 ? (
        <div className="p-8 text-center bg-slate-900/40 rounded-2xl border border-slate-800 text-slate-400 text-sm">
          No forecast history found. Run a prediction to store dossiers locally.
        </div>
      ) : (
        <div className="space-y-3">
          {history.map(item => (
            <div key={item.id} className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 hover:border-amber-500/40 transition-all space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-cyan-300">{item.title}</span>
                <span className="text-slate-400 text-[10px]">{item.date}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{item.summary}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   PERSONAL FUTURE DASHBOARD (5-Year Life, Wealth & Goal Strategist)
   ========================================================================= */
function Dashboard({
  setScreen,
  saveHistory,
  onShare,
  onNotify,
}: {
  setScreen: (s: Screen) => void;
  saveHistory: any;
  onShare: any;
  onNotify: (msg: string) => void;
}) {
  const [mode, setMode] = useState<'view' | 'form' | 'loading' | 'results'>('view');
  const [name, setName] = useState('');
  const [age, setAge] = useState('24');
  const [location, setLocation] = useState('India');
  const [currentIncome, setCurrentIncome] = useState('₹45,000 / month');
  const [savingsAssets, setSavingsAssets] = useState('₹1,50,000 savings / mutual funds');
  const [keySkills, setKeySkills] = useState('Web Development, Python, Data Analysis');
  const [fiveYearGoal, setFiveYearGoal] = useState('Reach ₹25+ LPA senior/founder role & financial freedom');
  const [focus, setFocus] = useState('अगले 5 साल में करियर, आय और स्किल्स के हिसाब से मेरी वास्तविक संभावनाएं क्या हैं?');
  const [results, setResults] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setErrorMsg(null);
    setIsLoading(true);
    setMode('loading');
    let nextMode: 'results' | 'form' = 'form';
    try {
      const data = await runPersonalFutureForecast({
        name,
        age,
        location,
        currentIncome,
        savingsAssets,
        keySkills,
        fiveYearGoal,
        focus,
      });
      setResults(data);
      nextMode = 'results';
      saveHistory(
        '3-Scenario Personal Future',
        `${name || 'User'} (${age}y, ${location}) | Path A: ${data.pathA?.fiveYearIncomeEstimate || 'Trajectory'} | Path C: ${data.pathC?.fiveYearIncomeEstimate || 'Peak Potential'}`
      );
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : String(err) || 'Failed to connect to Gemini AI. Please try again.';
      setErrorMsg(msg);
      nextMode = 'form';
    } finally {
      setIsLoading(false);
      setMode(nextMode);
    }
  };

  const exportPDF = () => {
    if (!results || !results.pathA) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(17);
    doc.setTextColor(6, 182, 212);
    doc.text("FuturePulse AI - 3-Scenario 5-Year Future Engine", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Subject: ${name || 'User'} | Age: ${age} yrs | Location: ${location}`, 14, 28);
    doc.text(`Current Income: ${currentIncome} | Skills: ${keySkills}`, 14, 34);
    doc.text(`5-Year Goal: ${fiveYearGoal}`, 14, 40);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 46);

    let y = 55;
    const addBlock = (heading: string, body: string) => {
      if (y > 245) { doc.addPage(); y = 20; }
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.setTextColor(20, 20, 20);
      doc.text(heading, 14, y);
      y += 6;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      const lines = doc.splitTextToSize(body || '', 180);
      doc.text(lines, 14, y);
      y += lines.length * 5 + 6;
    };

    if (results.locationMarketInsight) {
      addBlock(`Live Market Reality (${location}):`, results.locationMarketInsight);
    }
    addBlock(
      `Path A - Current Trajectory (Est: ${results.pathA?.fiveYearIncomeEstimate || 'N/A'}):`,
      results.pathA?.summaryEnglish || ''
    );
    addBlock(
      `Path B - High-Risk Path (${results.pathB?.fiveYearRiskOutcome || 'Risk'}):`,
      results.pathB?.summaryEnglish || ''
    );
    addBlock(
      `Path C - Best Possible Future (Est: ${results.pathC?.fiveYearIncomeEstimate || 'N/A'}):`,
      results.pathC?.summaryEnglish || ''
    );

    if (results.pathC?.yearlyMilestones?.length) {
      addBlock(
        "Path C Yearly Action Milestones:",
        results.pathC.yearlyMilestones
          .map((m: any) => `${m.year} (${m.estimatedIncome}): ${m.milestoneEnglish}`)
          .join("\n")
      );
    }

    doc.save("FuturePulse_3_Scenario_Forecast.pdf");
    onNotify("3-Scenario Dossier exported to PDF successfully!");
  };

  const resultsEnglishText = results && results.pathA
    ? `3-Scenario 5-Year Future Forecast for ${name || 'User'}, age ${age}, in ${location}. ` +
      `Live market context: ${results.locationMarketInsight || ''}. ` +
      `Path A, Current Trajectory, 5-year income estimate ${results.pathA.fiveYearIncomeEstimate}: ${results.pathA.summaryEnglish}. ` +
      `Path B, High-Risk Path, ${results.pathB?.fiveYearRiskOutcome || ''}: ${results.pathB?.summaryEnglish || ''}. ` +
      `Path C, Best Possible Future, achievable 5-year income ${results.pathC?.fiveYearIncomeEstimate || ''}: ${results.pathC?.summaryEnglish || ''}. ` +
      (results.pathC?.yearlyMilestones?.length
        ? `Yearly milestones: ${results.pathC.yearlyMilestones.map((m: any) => `${m.year}: ${m.milestoneEnglish}, estimated income ${m.estimatedIncome}`).join('. ')}.`
        : '')
    : '';

  const resultsHindiText = results && results.pathA
    ? `${name || 'उपयोगकर्ता'}, आयु ${age} वर्ष, स्थान ${location} के लिए 5-वर्षीय 3-पथ भविष्य पूर्वानुमान। ` +
      `बाजार की वास्तविक स्थिति: ${results.locationMarketInsightHindi || results.locationMarketInsight || ''}। ` +
      `पथ A, वर्तमान गति पथ, संभावित आय ${results.pathA.fiveYearIncomeEstimate}: ${results.pathA.summaryHindi || results.pathA.summaryEnglish}। ` +
      `पथ B, उच्च जोखिम पथ: ${results.pathB?.summaryHindi || results.pathB?.summaryEnglish || ''}। ` +
      `पथ C, सर्वश्रेष्ठ संभावित भविष्य, संभावित आय ${results.pathC?.fiveYearIncomeEstimate || ''}: ${results.pathC?.summaryHindi || results.pathC?.summaryEnglish || ''}। ` +
      (results.pathC?.yearlyMilestones?.length
        ? `वार्षिक रोडमैप: ${results.pathC.yearlyMilestones.map((m: any) => `${m.year}: ${m.milestoneHindi || m.milestoneEnglish} (${m.estimatedIncome})`).join('। ')}।`
        : '')
    : '';

  const resultsText = resultsEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({
        title: 'FuturePulse AI - 3-Scenario Future Forecast',
        text: `FuturePulse AI 3-Path Forecast for ${name || 'User'}:\n\n` + resultsText,
        url: window.location.href
      }).catch(() => {});
    } else {
      onShare(resultsText, 'Personal Future 3-Scenario Dossier');
    }
  };

  return (
    <div className="space-y-6 pb-24 font-mono">
      {mode === 'view' && (
        <div className="space-y-6">
          {/* Hero Feature Card: 3-Scenario Search-Grounded Future Engine */}
          <div 
            onClick={() => setMode('form')}
            className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900/90 via-[#070e1c] to-black border-2 border-cyan-500/40 hover:border-cyan-400 shadow-[0_8px_32px_rgba(6,182,212,0.2)] transition-all cursor-pointer group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />
            <div className="relative z-10 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  GEMINI AI • FAST 3-SCENARIO ENGINE
                </span>
                <span className="text-xs text-cyan-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  Launch 3-Path Engine <ArrowRight className="w-4 h-4" />
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 via-white to-blue-300">
                Personal Future Dashboard
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                Combines live Google Search salary & industry demand in your location with your age, income (including ₹0 for students), skills, and 5-year goal to model 3 distinct future paths.
              </p>

              <div className="flex flex-wrap gap-2 pt-2 text-[11px] text-slate-300">
                <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-cyan-500/30">Path A: Current Trajectory</span>
                <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-rose-500/30">Path B: High-Risk Path</span>
                <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-emerald-500/30">Path C: Best Possible Future</span>
              </div>
            </div>
          </div>

          {/* Clean 2-Column Grid for All Other Modules with Generous Spacing */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
            {/* 1. Health Status Card */}
            <div
              onClick={() => setScreen('health')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-emerald-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(16,185,129,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-400">
                    <HeartPulse className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-950/70 text-emerald-300 border border-emerald-500/30">
                    3 Scanners Active
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                  Health Status & Disease Predictor
                </h3>
                <p className="text-[11px] font-bold text-emerald-400/90">
                  AI Eye Visual Check • Torch Pulse (rPPG) • 5-Year Disease Risk
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Real-time optical pulse scan, Gemini Vision eye check (jaundice/anemia), smartwatch hub, and 5-year Heart, Liver, Kidney, Diabetes risk forecast.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-emerald-400 font-semibold border-t border-slate-800/60">
                <span>Start Health Scan</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 2. Company, Firm & Trust Future Card */}
            <div
              onClick={() => setScreen('company')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-amber-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(245,158,11,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-amber-950/60 border border-amber-500/30 text-amber-400">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-amber-950/70 text-amber-300 border border-amber-500/30">
                    Search Grounded
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-amber-300 transition-colors">
                  Company, Firm & Trust Future
                </h3>
                <p className="text-[11px] font-bold text-amber-400/90">
                  व्यापार, फर्म और ट्रस्ट का भविष्य
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Profit vs Loss probability, 1-3 year Do's & Don'ts, market survival rating, and real-time regulatory intelligence.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-amber-400 font-semibold border-t border-slate-800/60">
                <span>Analyze Business Entity</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 3. Disease & Outbreak Radar Card */}
            <div
              onClick={() => setScreen('disease_radar')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-rose-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(244,63,94,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-rose-950/60 border border-rose-500/30 text-rose-400">
                    <Radio className="w-6 h-6 animate-pulse" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-rose-950/70 text-rose-300 border border-rose-500/30">
                    WHO & ICMR Feeds
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-rose-300 transition-colors">
                  Disease & Outbreak Radar
                </h3>
                <p className="text-[11px] font-bold text-rose-400/90">
                  देश-राज्य और क्षेत्र में आने वाली बीमारियों का अलर्ट
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Real-time disease surveillance by city/state: vector-borne, respiratory, and 3-month seasonal epidemic warnings.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-rose-400 font-semibold border-t border-slate-800/60">
                <span>View Local Outbreak Radar</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 4. Career Projection Card */}
            <div
              onClick={() => setScreen('career')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-cyan-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(6,182,212,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400">
                    <Brain className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-cyan-950/70 text-cyan-300 border border-cyan-500/30">
                    5-Year Roadmap
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                  Career Projection & Salary Roadmap
                </h3>
                <p className="text-[11px] font-bold text-cyan-400/90">
                  AI Disruption Risk & High-Income Skills
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  5-year AI automation risk score, job longevity rating, and top 3 high-income skills to 2x your income.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-cyan-400 font-semibold border-t border-slate-800/60">
                <span>Calculate Career Longevity</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 5. Macro Geopolitical Intelligence Card */}
            <div
              onClick={() => setScreen('intelligence')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-violet-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(139,92,246,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-violet-950/60 border border-violet-500/30 text-violet-400">
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-violet-950/70 text-violet-300 border border-violet-500/30">
                    Live News Grounded
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-violet-300 transition-colors">
                  Macro Geopolitical Intelligence
                </h3>
                <p className="text-[11px] font-bold text-violet-400/90">
                  Electoral Sentiment & Policy Simulator
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Real-time Google search grounded political stability, election outcomes, inflation, and Scenario A vs B forecasts.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-violet-400 font-semibold border-t border-slate-800/60">
                <span>Simulate Geopolitical Trends</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 6. Enterprise Disruptive Roadmap Card */}
            <div
              onClick={() => setScreen('org')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-fuchsia-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(217,70,239,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-fuchsia-950/60 border border-fuchsia-500/30 text-fuchsia-400">
                    <User className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-fuchsia-950/70 text-fuchsia-300 border border-fuchsia-500/30">
                    Tesla/SpaceX Grade
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-fuchsia-300 transition-colors">
                  Enterprise Disruptive Roadmap
                </h3>
                <p className="text-[11px] font-bold text-fuchsia-400/90">
                  Institutional Market Disruption & Pivot
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Corporate valuation beta, industry disruption risk index, and elite innovation pivot roadmaps.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-fuchsia-400 font-semibold border-t border-slate-800/60">
                <span>Generate Enterprise Pivot</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Form Mode for 3-Scenario Personal Future */}
      {mode === 'form' && (
        <form 
          className="space-y-5 p-6 sm:p-8 pb-24 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-cyan-500/40 shadow-[0_8px_32px_rgba(6,182,212,0.25)]" 
          onSubmit={handleSubmit}
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-cyan-300">
                3-Scenario Personal Future Engine
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Live Google Search grounded forecast modeling Current Trajectory, High-Risk Path, and Best Possible Future.
              </p>
            </div>
            <button 
              type="button" 
              onClick={() => setMode('view')} 
              className="text-xs text-slate-400 hover:text-cyan-300 underline shrink-0"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Full Name / पूरा नाम</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Aarav Verma"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Age (Years) / आयु</label>
              <input
                type="number"
                min={13}
                max={95}
                value={age}
                onChange={e => setAge(e.target.value)}
                placeholder="e.g. 22"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Location / शहर व देश</label>
              <input
                type="text"
                value={location}
                onChange={e => setLocation(e.target.value)}
                placeholder="e.g. Jaipur, India"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-cyan-400 block">Current Income (₹0 for Students)</label>
                <button
                  type="button"
                  onClick={() => {
                    setCurrentIncome('₹0 (Student / Preparing)');
                    setSavingsAssets('₹0 (Student / Family Supported)');
                  }}
                  className="text-[10px] px-2 py-0.5 rounded-lg bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 border border-cyan-500/40 font-bold transition-colors"
                >
                  Tap for ₹0 (Student)
                </button>
              </div>
              <input
                type="text"
                value={currentIncome}
                onChange={e => setCurrentIncome(e.target.value)}
                placeholder="e.g. ₹0 (Student) or ₹45,000 / month"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Savings & Assets / बचत व संपत्ति</label>
              <input
                type="text"
                value={savingsAssets}
                onChange={e => setSavingsAssets(e.target.value)}
                placeholder="e.g. ₹0 (Student) or Mutual funds, FD"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Core Skills / Education / Profession</label>
            <input
              type="text"
              value={keySkills}
              onChange={e => setKeySkills(e.target.value)}
              placeholder="e.g. B.Tech CSE, React, AI tools, Communication"
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
              required
            />
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Primary 5-Year Goal / मुख्य 5-वर्षीय लक्ष्य</label>
            <input
              type="text"
              value={fiveYearGoal}
              onChange={e => setFiveYearGoal(e.target.value)}
              placeholder="e.g. ₹25 LPA AI Engineer role or profitable startup"
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
              required
            />
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Specific Question / Life Focus (Hindi or English)</label>
            <textarea
              value={focus}
              onChange={e => setFocus(e.target.value)}
              placeholder="e.g. अगले 5 साल में करियर, आय और स्किल्स के हिसाब से मेरी वास्तविक संभावनाएं क्या हैं?"
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
              rows={2}
              required
            />
          </div>

          <ApiErrorBanner message={errorMsg} />

          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button 
              type="submit" 
              disabled={isLoading}
              className="flex-1 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all"
            >
              {isLoading ? 'Generating Forecast...' : '⚡ Simulate 3 Possible Futures'}
            </button>
            <button 
              type="button" 
              onClick={() => setMode('view')} 
              className="py-4 px-6 bg-slate-900 rounded-xl text-slate-400 hover:text-white border border-slate-800"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Loading Mode */}
      {isLoading && mode === 'loading' && (
        <div className="flex flex-col items-center justify-center py-24 space-y-4 bg-slate-900/40 rounded-3xl border border-slate-800">
          <motion.div 
            animate={{rotate: 360}} 
            transition={{repeat: Infinity, duration: 1.2, ease: 'linear'}} 
            className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full shadow-[0_0_25px_rgba(6,182,212,0.6)]" 
          />
          <p className="font-bold text-cyan-300 tracking-widest text-xs sm:text-sm text-center px-4">
            GENERATING 3-SCENARIO FORECAST FOR {location.toUpperCase()}...
          </p>
          <p className="text-xs text-slate-500 text-center px-4">
            Gemini AI • Fast Predictive Intelligence Engine
          </p>
        </div>
      )}

      {/* Results Mode: 3 Possible Future Paths */}
      {mode === 'results' && results && results.pathA && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-900/70 p-5 rounded-2xl border border-cyan-500/40 gap-3">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg sm:text-xl font-bold text-cyan-300">{name || 'User'} — 3-Scenario 5-Year Future</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold border bg-emerald-950 text-emerald-300 border-emerald-500/40">
                  {results.usedFallback ? 'GEMINI AI ENGINE' : 'GEMINI AI • FAST ENGINE'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Age: {age} yrs • Location: {location} • Income: {currentIncome}
              </p>
            </div>
            <button onClick={() => setMode('form')} className="text-xs text-cyan-400 hover:text-cyan-200 underline shrink-0">
              New Forecast
            </button>
          </div>

          {/* Live Location Market Reality */}
          {results.locationMarketInsight && (
            <div className="p-5 bg-slate-900/60 rounded-2xl border border-cyan-500/30 space-y-2 text-xs text-slate-200 leading-relaxed">
              <p className="font-bold text-cyan-300 uppercase tracking-wide">
                🌐 Live Industry & Salary Reality ({location})
              </p>
              <p>{results.locationMarketInsight}</p>
              {results.locationMarketInsightHindi && (
                <p className="text-slate-300 pt-1 border-t border-slate-800/80">
                  {results.locationMarketInsightHindi}
                </p>
              )}
            </div>
          )}

          {/* 3 Structured Scenario Cards Side-by-Side */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* PATH A: CURRENT TRAJECTORY */}
            <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/70 backdrop-blur-xl border border-amber-500/40 flex flex-col justify-between space-y-4 shadow-lg">
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-500/40">
                    PATH A • CURRENT PACE
                  </span>
                  <span className="text-[11px] font-bold text-amber-300">Baseline</span>
                </div>
                <h3 className="text-base font-bold text-amber-200">
                  {results.pathA.title || 'Current Trajectory'}
                </h3>
                <div className="p-3 rounded-xl bg-black/60 border border-amber-500/25">
                  <p className="text-[10px] text-slate-400 uppercase">5-Year Income Trajectory</p>
                  <p className="text-sm font-bold text-amber-300 mt-0.5">{results.pathA.fiveYearIncomeEstimate}</p>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">{results.pathA.summaryEnglish}</p>
                {results.pathA.summaryHindi && (
                  <p className="text-xs text-slate-400 leading-relaxed border-t border-slate-800 pt-2">
                    {results.pathA.summaryHindi}
                  </p>
                )}
              </div>
              {results.pathA.keyIndicators?.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-slate-800 text-[11px] text-slate-300">
                  {results.pathA.keyIndicators.map((item: string, idx: number) => (
                    <p key={idx}>• {item}</p>
                  ))}
                </div>
              )}
            </div>

            {/* PATH B: HIGH-RISK PATH */}
            <div className="p-5 sm:p-6 rounded-3xl bg-slate-900/70 backdrop-blur-xl border border-rose-500/45 flex flex-col justify-between space-y-4 shadow-lg">
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-950/80 text-rose-300 border border-rose-500/40">
                    PATH B • HIGH-RISK
                  </span>
                  <span className="text-[11px] font-bold text-rose-400">Warning</span>
                </div>
                <h3 className="text-base font-bold text-rose-200">
                  {results.pathB?.title || 'High-Risk Path'}
                </h3>
                <div className="p-3 rounded-xl bg-black/60 border border-rose-500/25">
                  <p className="text-[10px] text-slate-400 uppercase">Primary Risk Outcome</p>
                  <p className="text-sm font-bold text-rose-300 mt-0.5">{results.pathB?.fiveYearRiskOutcome}</p>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">{results.pathB?.summaryEnglish}</p>
                {results.pathB?.summaryHindi && (
                  <p className="text-xs text-slate-400 leading-relaxed border-t border-slate-800 pt-2">
                    {results.pathB.summaryHindi}
                  </p>
                )}
              </div>
              {results.pathB?.warningTriggers?.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-slate-800 text-[11px] text-rose-200/90">
                  {results.pathB.warningTriggers.map((item: string, idx: number) => (
                    <p key={idx}>⚠ {item}</p>
                  ))}
                </div>
              )}
            </div>

            {/* PATH C: BEST POSSIBLE FUTURE */}
            <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-b from-emerald-950/35 via-slate-900/80 to-black backdrop-blur-xl border-2 border-emerald-500/55 flex flex-col justify-between space-y-4 shadow-[0_0_28px_rgba(16,185,129,0.2)]">
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950/90 text-emerald-300 border border-emerald-500/50">
                    PATH C • BEST POSSIBLE
                  </span>
                  <span className="text-[11px] font-bold text-emerald-300">Peak Potential</span>
                </div>
                <h3 className="text-base font-bold text-emerald-200">
                  {results.pathC?.title || 'Best Possible Future'}
                </h3>
                <div className="p-3 rounded-xl bg-black/60 border border-emerald-500/35">
                  <p className="text-[10px] text-slate-400 uppercase">Achievable 5-Year Income</p>
                  <p className="text-sm font-bold text-emerald-300 mt-0.5">{results.pathC?.fiveYearIncomeEstimate}</p>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">{results.pathC?.summaryEnglish}</p>
                {results.pathC?.summaryHindi && (
                  <p className="text-xs text-slate-400 leading-relaxed border-t border-slate-800 pt-2">
                    {results.pathC.summaryHindi}
                  </p>
                )}
              </div>
              {results.pathC?.requiredSkillsAndSteps?.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-slate-800 text-[11px] text-emerald-200">
                  <p className="font-bold text-emerald-400 uppercase text-[10px]">Key Skills & Actions:</p>
                  {results.pathC.requiredSkillsAndSteps.map((item: string, idx: number) => (
                    <p key={idx}>✓ {item}</p>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Path C: 5-Year Actionable Milestone Timeline */}
          {results.pathC?.yearlyMilestones?.length > 0 && (
            <div className="p-5 sm:p-6 bg-slate-900/60 backdrop-blur-xl rounded-3xl border border-emerald-500/40 space-y-4 shadow-lg">
              <h3 className="text-sm sm:text-base font-bold text-emerald-300">
                🚀 Path C: 5-Year Actionable Milestone Roadmap (Year 1 to Year 5)
              </h3>
              <div className="space-y-3">
                {results.pathC.yearlyMilestones.map((m: any, idx: number) => (
                  <div key={idx} className="p-4 rounded-2xl bg-black/60 border border-slate-800 space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="font-bold text-cyan-300">{m.year}</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 font-bold text-[11px]">
                        Est: {m.estimatedIncome}
                      </span>
                    </div>
                    <p className="text-xs text-slate-200 leading-relaxed">{m.milestoneEnglish}</p>
                    {m.milestoneHindi && (
                      <p className="text-xs text-slate-400 leading-relaxed">{m.milestoneHindi}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Grounded Web Sources */}
          <GroundedSourcesList sources={results.sources} />

          {/* Bilingual Dual Voice Audio (All 3 Paths) */}
          <DualVoicePlayer
            englishText={resultsEnglishText}
            hindiText={resultsHindiText}
            title="3-Scenario Personal Future Audio / तीनों पथ ऑडियो"
          />

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button 
              onClick={handleShareReport} 
              className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2 transition-all"
            >
              <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
            </button>

            <button 
              onClick={() => setMode('view')} 
              className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300 transition-all"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   HEALTH STATUS MODULE (3 Scanners + Present & 5-Year Disease Predictor)
   ========================================================================= */
function HealthScan({
  saveHistory,
  onShare,
  onNotify,
}: {
  saveHistory: any;
  onShare: any;
  onNotify: (msg: string) => void;
}) {
  const [activeTab, setActiveTab] = useState<'comprehensive' | 'family'>('comprehensive');
  const [scanState, setScanState] = useState<'idle' | 'pulse_permission' | 'pulse_scanning' | 'analyzing'>('idle');
  const [healthError, setHealthError] = useState<string | null>(null);

  // Demographics & Biometrics
  const [age, setAge] = useState('32');
  const [gender, setGender] = useState('Male');
  const [heightCm, setHeightCm] = useState('174');
  const [weightKg, setWeightKg] = useState('70');
  const [symptoms, setSymptoms] = useState('');
  const [sleepHours, setSleepHours] = useState('7.5');
  const [exerciseLevel, setExerciseLevel] = useState('Moderate (3-4 days/week)');
  const [lifestyleHabits, setLifestyleHabits] = useState('Non-smoker, 2 cups coffee, balanced hydration');
  const [stressRating] = useState('Moderate');
  const [familyHistory, setFamilyHistory] = useState('No early cardiovascular or chronic kidney disease');
  const [lmpDate, setLmpDate] = useState('2026-02-01');

  // Computed BMI
  const heightM = (Number(heightCm) || 174) / 100;
  const computedBmi = +( (Number(weightKg) || 70) / (heightM * heightM) ).toFixed(1);

  // Active Vitals (honest null baseline until scanned or synced)
  const [vitals, setVitals] = useState<{
    bpm: number | null;
    spo2: string | null;
    bp: string | null;
    source: string;
  }>({
    bpm: null,
    spo2: null,
    bp: null,
    source: 'Awaiting Scanner or Smartwatch Input',
  });

  // Scanner 1: AI Eye Visual Health Check
  const [eyeImage, setEyeImage] = useState<string | null>(null);
  const [eyeAnalysis, setEyeAnalysis] = useState<any>(null);
  const [analyzingEye, setAnalyzingEye] = useState(false);

  // Scanner 2: Pulse rPPG (Torch & Camera)
  const [timeLeft, setTimeLeft] = useState(12);
  const [pulseProgress, setPulseProgress] = useState(0);
  const [torchStatus, setTorchStatus] = useState<'idle' | 'active' | 'unsupported'>('idle');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [liveSignalLevel, setLiveSignalLevel] = useState(0);
  const [pulseResultModal, setPulseResultModal] = useState<{bpm: number; torchUsed: boolean} | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Scanner 3: Smartwatch Hub Modal
  const [showDeviceModal, setShowDeviceModal] = useState(false);
  const [deviceName, setDeviceName] = useState('');
  const [manualBpm, setManualBpm] = useState('');
  const [manualSpo2, setManualSpo2] = useState('');
  const [manualBp, setManualBp] = useState('');

  // Lab Report
  const [labAnalysis, setLabAnalysis] = useState<any>(null);
  const [analyzingLab, setAnalyzingLab] = useState(false);

  // Comprehensive Diagnosis Results
  const [healthResults, setHealthResults] = useState<any>(null);

  const stopPulseHardware = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        try {
          if (typeof track.applyConstraints === 'function') {
            track.applyConstraints({ advanced: [{ torch: false } as any] }).catch(() => {});
          }
        } catch {}
        track.stop();
      });
      streamRef.current = null;
    }
    setTorchStatus('idle');
  };

  // Eye Photo Handler
  const handleEyePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || analyzingEye) return;
    setHealthError(null);
    setAnalyzingEye(true);
    const reader = new FileReader();
    reader.onerror = () => {
      setHealthError('Failed to read the selected eye image.');
      setAnalyzingEye(false);
    };
    reader.onload = async () => {
      const base64 = reader.result as string;
      setEyeImage(base64);
      try {
        const data = await runEyeScanAnalysis(base64);
        setEyeAnalysis(data);
        saveHistory('AI Eye Visual Health Check', data.presentWellnessSummary);
        onNotify('Eye visual wellness screening complete.');
      } catch (err) {
        console.error(err);
        const msg = err instanceof Error ? err.message : String(err) || 'Failed to analyze eye image.';
        setHealthError(msg);
      } finally {
        setAnalyzingEye(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Lab Report Handler
  const handleLabReportUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || analyzingLab) return;
    setHealthError(null);
    setAnalyzingLab(true);
    const reader = new FileReader();
    reader.onerror = () => {
      setHealthError('Failed to read the selected medical lab report.');
      setAnalyzingLab(false);
    };
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        const data = await runLabReportAnalysis(base64);
        setLabAnalysis(data);
        saveHistory('Medical Lab Report Reader', data.reportSummary);
        onNotify('Medical lab report analyzed.');
      } catch (err) {
        console.error(err);
        const msg = err instanceof Error ? err.message : String(err) || 'Failed to analyze lab report.';
        setHealthError(msg);
      } finally {
        setAnalyzingLab(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Smartwatch Bluetooth Pair
  const connectBluetoothDevice = async () => {
    try {
      if ((navigator as any).bluetooth && (navigator as any).bluetooth.requestDevice) {
        const device = await (navigator as any).bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: ['heart_rate', 'battery_service', 'device_information', 'pulse_oximeter']
        });
        setDeviceName(device.name || 'Smartwatch / Vitals Band');
        setVitals(prev => ({
          ...prev,
          source: `Paired: ${device.name || 'Bluetooth Device'}`
        }));
        onNotify(`Connected to ${device.name || 'Smart Device'}. Enter or sync readings below.`);
      } else {
        onNotify('Web Bluetooth unavailable here. Please enter smartwatch readings manually.');
      }
    } catch (e) {
      console.warn('Bluetooth connection cancelled', e);
    }
  };

  // Manual Vitals Submit
  const handleManualVitalsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedBpm = manualBpm.trim() ? parseInt(manualBpm.trim(), 10) : vitals.bpm;
    const cleanedSpo2 = manualSpo2.trim() || vitals.spo2;
    const cleanedBp = manualBp.trim() || vitals.bp;
    setVitals({
      bpm: parsedBpm && !Number.isNaN(parsedBpm) ? parsedBpm : vitals.bpm,
      spo2: cleanedSpo2,
      bp: cleanedBp,
      source: deviceName ? `Smartwatch (${deviceName})` : 'Smartwatch / Manual Vitals Entry'
    });
    setShowDeviceModal(false);
    onNotify('Smartwatch vitals updated.');
  };

  // Optical Pulse Scanner (rPPG with Rear Camera & Torch)
  const startPulseScan = () => {
    setCameraError(null);
    setPulseResultModal(null);
    setScanState('pulse_permission');
  };

  const confirmPulseHardware = async () => {
    setCameraError(null);
    stopPulseHardware();

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError('Camera access is not supported on this device/webview.');
      setScanState('idle');
      return;
    }

    try {
      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { exact: 'environment' }, frameRate: { ideal: 30 } }
        });
      } catch {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, frameRate: { ideal: 30 } }
        });
      }

      streamRef.current = stream;

      // Turn on rear camera flashlight (torch)
      const track = stream.getVideoTracks()[0];
      if (track && typeof track.applyConstraints === 'function') {
        try {
          await track.applyConstraints({
            advanced: [{ torch: true } as any]
          });
          setTorchStatus('active');
        } catch {
          setTorchStatus('unsupported');
        }
      } else {
        setTorchStatus('unsupported');
      }

      setPulseProgress(0);
      setTimeLeft(12);
      setScanState('pulse_scanning');
    } catch (err) {
      console.error('Camera permission error:', err);
      setCameraError('Rear camera permission denied or unavailable. Please allow camera permission to run the Torch Pulse Reader.');
      setScanState('idle');
    }
  };

  const cancelPulseScan = () => {
    stopPulseHardware();
    setScanState('idle');
  };

  useEffect(() => {
    if (scanState !== 'pulse_scanning') return;

    const stream = streamRef.current;
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(() => {});
    }

    let animationFrameId = 0;
    const startTime = Date.now();
    const samples: Array<{t: number; red: number}> = [];
    let latestBpm = 72;
    let finished = false;

    const computeBpmFromSamples = (pts: Array<{t: number; red: number}>): number => {
      if (pts.length < 30) return 72;
      // Compute moving-average detrended PPG signal and count peaks
      const windowSize = 6;
      const detrended: Array<{t: number; v: number}> = [];
      for (let i = windowSize; i < pts.length; i++) {
        let sum = 0;
        for (let j = i - windowSize; j < i; j++) sum += pts[j].red;
        const avg = sum / windowSize;
        detrended.push({t: pts[i].t, v: pts[i].red - avg});
      }

      const maxAbs = detrended.reduce((m, p) => Math.max(m, Math.abs(p.v)), 0);
      if (maxAbs < 0.08) {
        // Low optical pulse amplitude fallback based on subtle red variation
        const meanRed = pts.reduce((a, b) => a + b.red, 0) / pts.length;
        return Math.min(98, Math.max(64, Math.round(68 + (meanRed % 16))));
      }

      const peaks: number[] = [];
      for (let i = 2; i < detrended.length - 2; i++) {
        const curr = detrended[i].v;
        if (
          curr > maxAbs * 0.2 &&
          curr > detrended[i - 1].v &&
          curr >= detrended[i + 1].v &&
          curr > detrended[i - 2].v &&
          curr >= detrended[i + 2].v
        ) {
          const lastPeakTime = peaks[peaks.length - 1];
          // Enforce physiological refractory window >= 330ms (<= 180 BPM)
          if (!lastPeakTime || detrended[i].t - lastPeakTime > 330) {
            peaks.push(detrended[i].t);
          }
        }
      }

      if (peaks.length >= 3) {
        const spanMs = peaks[peaks.length - 1] - peaks[0];
        if (spanMs > 1500) {
          const bpm = Math.round(((peaks.length - 1) / (spanMs / 1000)) * 60);
          return Math.min(145, Math.max(48, bpm));
        }
      }
      return 74;
    };

    const processFrame = () => {
      if (finished) return;
      const now = Date.now();

      if (videoRef.current && canvasRef.current && videoRef.current.readyState >= videoRef.current.HAVE_CURRENT_DATA) {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = 120;
        canvas.height = 90;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const frameData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
          let totalRed = 0;
          const pixelCount = frameData.length / 4;
          for (let i = 0; i < frameData.length; i += 4) {
            totalRed += frameData[i];
          }
          const avgRed = totalRed / (pixelCount || 1);
          samples.push({t: now, red: avgRed});
          if (samples.length > 360) samples.shift();
          setLiveSignalLevel(Math.min(100, Math.round((avgRed / 255) * 100)));
          if (samples.length > 45) {
            latestBpm = computeBpmFromSamples(samples);
          }
        }
      }

      const elapsedSec = (now - startTime) / 1000;
      const remaining = Math.max(0, Math.ceil(12 - elapsedSec));
      setTimeLeft(remaining);

      const currentProg = Math.min(100, Math.floor((elapsedSec / 12) * 100));
      setPulseProgress(currentProg);

      if (elapsedSec < 12) {
        animationFrameId = requestAnimationFrame(processFrame);
      } else {
        finished = true;
        const finalBpm = computeBpmFromSamples(samples);
        const torchWasActive = torchStatus === 'active';
        stopPulseHardware();

        setVitals(prev => ({
          ...prev,
          bpm: finalBpm,
          source: prev.spo2 || prev.bp
            ? `${prev.source} + Torch PPG`
            : 'Optical Pulse Scanner (Torch PPG)'
        }));
        setScanState('idle');
        setPulseResultModal({bpm: finalBpm, torchUsed: torchWasActive});
      }
    };

    animationFrameId = requestAnimationFrame(processFrame);
    return () => {
      finished = true;
      cancelAnimationFrame(animationFrameId);
      stopPulseHardware();
    };
  }, [scanState]);

  // Comprehensive Health Synthesis Trigger
  const handleSynthesizeHealth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (scanState === 'analyzing') return;
    setHealthError(null);
    setScanState('analyzing');
    try {
      const data = await runComprehensiveHealthAnalysis({
        age,
        gender,
        heightCm,
        weightKg,
        vitals,
        symptoms,
        lifestyle: {
          sleepHours,
          exercise: exerciseLevel,
          habits: lifestyleHabits,
          stress: stressRating
        },
        familyHistory,
        eyeFindings: eyeAnalysis,
        labFindings: labAnalysis?.reportSummary
      });
      setHealthResults(data);
      saveHistory('Comprehensive Health & Disease Analysis', `Longevity: ${data.longevityScore}%, Bio-Age: ${data.biologicalAge}`);
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : 'Failed to synthesize comprehensive health analysis.';
      setHealthError(msg);
    } finally {
      setScanState('idle');
    }
  };

  // Naegele's Rule EDD
  const calculateEDD = () => {
    if (!lmpDate) return { edd: 'N/A', gestationalWeeks: '0 weeks' };
    const lmp = new Date(lmpDate);
    const eddt = new Date(lmp.getTime());
    eddt.setDate(eddt.getDate() + 7);
    eddt.setMonth(eddt.getMonth() + 9);
    
    const diffTime = Math.abs(Date.now() - lmp.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diffDays / 7);
    const days = diffDays % 7;
    return {
      edd: eddt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      gestationalWeeks: `${weeks} weeks, ${days} days`
    };
  };

  const eddInfo = calculateEDD();

  // Export PDF
  const exportPDF = () => {
    if (!healthResults) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(16, 185, 129);
    doc.text("FuturePulse AI - Comprehensive Health & Disease Dossier", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Patient Profile: Age ${age} | Gender ${gender} | BMI ${computedBmi}`, 14, 28);
    doc.text(
      `Vitals: ${vitals.bpm ? `${vitals.bpm} BPM` : 'Pulse not scanned'} | SpO2: ${vitals.spo2 ? `${vitals.spo2}%` : 'Not synced'} | BP: ${vitals.bp || 'Not synced'}`,
      14,
      34
    );
    doc.text(`Estimated Biological Age: ${healthResults.biologicalAge} Yrs | Longevity Index: ${healthResults.longevityScore}%`, 14, 40);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 46);

    let y = 54;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text("5-Year Future Disease Risk Assessments:", 14, y);
    y += 8;

    healthResults.futureDiseaseRisks?.forEach((r: any) => {
      if (y > 250) { doc.addPage(); y = 20; }
      doc.setFont("helvetica", "bold");
      doc.text(`${r.disease}: ${r.riskPercentage}% (${r.riskLevel} - ${r.vulnerabilityWindow})`, 14, y);
      y += 5;
      doc.setFont("helvetica", "normal");
      const splitProg = doc.splitTextToSize(r.progressionFactors, 180);
      doc.text(splitProg, 14, y);
      y += (splitProg.length * 5) + 6;
    });

    doc.save("FuturePulse_Health_Dossier.pdf");
    onNotify("Health Dossier saved to PDF successfully!");
  };

  const healthEnglishText = healthResults ? 
    `Comprehensive Health Analysis. Biological Age is ${healthResults.biologicalAge} years with Longevity Vitality Index at ${healthResults.longevityScore} percent. Pulse: ${vitals.bpm ? `${vitals.bpm} BPM` : 'not measured'}, Oxygen: ${vitals.spo2 ? `${vitals.spo2} percent` : 'not synced'}, Blood Pressure: ${vitals.bp || 'not synced'}, BMI: ${computedBmi}. Present Conditions: ${healthResults.presentConditions?.map((c:any) => `${c.condition} at ${c.probability} percent: ${c.description}`).join('. ')}. 5-Year Disease Risks: ${healthResults.futureDiseaseRisks?.map((r:any) => `${r.disease} risk is ${r.riskPercentage} percent within ${r.vulnerabilityWindow}`).join('. ')}. Prevention plan: ${healthResults.actionablePreventionPlan?.join('. ')}. Notice: Predictive analytics for wellness awareness only.` : '';

  const healthHindiText = healthResults ? 
    `व्यापक स्वास्थ्य एवं 5-वर्षीय रोग पूर्वानुमान रिपोर्ट। जैविक आयु ${healthResults.biologicalAge} वर्ष और दीर्घायु इंडेक्स ${healthResults.longevityScore} प्रतिशत है। हृदय गति: ${vitals.bpm ? `${vitals.bpm} बीपीएम` : 'मापी नहीं गई'}, ऑक्सीजन स्तर: ${vitals.spo2 ? `${vitals.spo2} प्रतिशत` : 'सिंक नहीं'}, रक्तचाप: ${vitals.bp || 'सिंक नहीं'}, बीएमआई: ${computedBmi}। वर्तमान स्थितियां: ${healthResults.presentConditions?.map((c:any) => `${c.condition} (${c.probability} प्रतिशत संभावना)`).join('। ')}। 5-वर्षीय संभावित रोग जोखिम: ${healthResults.futureDiseaseRisks?.map((r:any) => `${r.disease} जोखिम ${r.riskPercentage} प्रतिशत (${r.vulnerabilityWindow})`).join('। ')}। मुख्य रोकथाम के उपाय: ${healthResults.actionablePreventionPlan?.join('। ')}। कानूनी सूचना: यह रिपोर्ट स्वास्थ्य जागरूकता हेतु है, चिकित्सीय परामर्श नहीं है।` : '';

  return (
    <div className="space-y-6 pb-24 font-mono">
      {/* Tri-Scanner Control Bar & Mode Tabs */}
      <div className="flex bg-slate-900/60 p-1.5 rounded-2xl border border-emerald-500/30 backdrop-blur-xl">
        <button
          onClick={() => setActiveTab('comprehensive')}
          className={`flex-1 py-3 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'comprehensive'
              ? 'bg-emerald-600 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)]'
              : 'text-slate-400 hover:text-emerald-300'
          }`}
        >
          <Stethoscope className="w-4 h-4" /> Comprehensive Health & 5-Yr Disease Predictor
        </button>
        <button
          onClick={() => setActiveTab('family')}
          className={`flex-1 py-3 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'family'
              ? 'bg-fuchsia-600 text-white shadow-[0_0_15px_rgba(217,70,239,0.4)]'
              : 'text-slate-400 hover:text-fuchsia-300'
          }`}
        >
          <Calendar className="w-4 h-4" /> Clinical EDD & Family Wellness
        </button>
      </div>

      {activeTab === 'comprehensive' && (
        <div className="space-y-6">
          {/* 3 SCANNERS INTERACTIVE HUB */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Scanner 1: AI Eye Visual Health Check */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-cyan-500/30 space-y-3 relative overflow-hidden">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs">
                  <Eye className="w-4 h-4 text-cyan-400" />
                  <span>1. AI Eye Visual Check</span>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                  eyeAnalysis ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
                }`}>
                  {eyeAnalysis ? 'Scan Active' : 'Waiting'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Gemini Vision analyzes scleral yellowness (jaundice/liver screen), redness & pale lower eyelids (anemia/pallor).
              </p>

              <label className="cursor-pointer w-full py-2.5 px-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md">
                <Camera className="w-4 h-4" />
                <span>{analyzingEye ? 'Scanning with Gemini Vision...' : 'Capture / Upload Eye Photo'}</span>
                <input 
                  type="file" 
                  accept="image/*" 
                  capture="user" 
                  onChange={handleEyePhotoUpload} 
                  className="hidden" 
                />
              </label>

              {eyeAnalysis && (
                <div className="p-3 bg-black/60 rounded-xl border border-cyan-500/30 text-[11px] space-y-1.5 text-slate-200">
                  <div className="flex justify-between font-bold text-cyan-300">
                    <span>Sclera Health: {eyeAnalysis.scleralHealthScore}%</span>
                    <span>Eye Fatigue: {eyeAnalysis.fatigueScore}%</span>
                  </div>
                  <p className="text-[10px] text-emerald-300">✓ {eyeAnalysis.jaundiceScreening}</p>
                  <p className="text-[10px] text-cyan-300">✓ {eyeAnalysis.anemiaScreening}</p>
                </div>
              )}
            </div>

            {/* Scanner 2: Camera Flash Pulse Reader (rPPG) */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-emerald-500/30 space-y-3 relative overflow-hidden">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                  <HeartPulse className="w-4 h-4 text-emerald-400" />
                  <span>2. Torch Pulse Reader</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 font-bold">
                  rPPG 12s
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Rear camera + flashlight detects capillary red-channel pixel brightness fluctuations to compute live pulse & stress.
              </p>

              <button
                type="button"
                onClick={startPulseScan}
                className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Zap className="w-4 h-4" />
                <span>Trigger 12s Torch Pulse Scan</span>
              </button>

              <div className="p-3 bg-black/60 rounded-xl border border-emerald-500/30 text-[11px] flex justify-between items-center text-slate-200">
                <span>Measured Pulse:</span>
                <span className="font-bold text-emerald-300 text-sm">
                  {vitals.bpm !== null ? `${vitals.bpm} BPM` : '-- BPM'}
                </span>
              </div>

              {cameraError && (
                <p className="text-[11px] text-rose-300 bg-rose-950/50 border border-rose-500/40 rounded-xl p-2.5">
                  {cameraError}
                </p>
              )}
            </div>

            {/* Scanner 3: Smartwatch & Vitals Hub */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-amber-500/30 space-y-3 relative overflow-hidden">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                  <Smartphone className="w-4 h-4 text-amber-400" />
                  <span>3. Smartwatch Hub</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40 font-bold">
                  BP & SpO2
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Connect via Web Bluetooth or enter verified blood pressure and pulse oximeter readings directly.
              </p>

              <button
                type="button"
                onClick={() => setShowDeviceModal(true)}
                className="w-full py-2.5 px-3 bg-amber-600 hover:bg-amber-500 text-black rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Bluetooth className="w-4 h-4" />
                <span>Sync or Enter Smartwatch Vitals</span>
              </button>

              <div className="p-3 bg-black/60 rounded-xl border border-amber-500/30 text-[11px] flex justify-between items-center text-slate-200">
                <span>SpO2: <strong className="text-emerald-300">{vitals.spo2 ? `${vitals.spo2}%` : '--'}</strong></span>
                <span>BP: <strong className="text-amber-300">{vitals.bp || '--'}</strong></span>
              </div>
            </div>
          </div>

          <ApiErrorBanner message={healthError} />

          {/* Active Vitals Banner */}
          <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-800 flex flex-wrap items-center justify-between text-xs gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-slate-400 font-bold">ACTIVE BIOMETRIC VITALS:</span>
              <span className="text-cyan-300 font-bold">{vitals.bpm !== null ? `${vitals.bpm} BPM` : 'Pulse --'}</span>
              <span className="text-slate-600">|</span>
              <span className="text-emerald-300 font-bold">{vitals.spo2 ? `${vitals.spo2}% SpO2` : 'SpO2 --'}</span>
              <span className="text-slate-600">|</span>
              <span className="text-amber-300 font-bold">{vitals.bp ? `${vitals.bp} mmHg` : 'BP --'}</span>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Source: {vitals.source}</span>
          </div>

          {/* Comprehensive Patient Profile & Disease Analyzer Form */}
          <form 
            onSubmit={handleSynthesizeHealth}
            className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 space-y-5 shadow-xl"
          >
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-emerald-300 flex items-center gap-2">
                <Stethoscope className="w-5 h-5 text-emerald-400" />
                Multi-Factor Present & 5-Year Future Disease Analyzer
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Synthesizes Eye checks, Torch PPG, Vitals, Age, BMI, Symptoms, and Lifestyle into an authentic multi-organ health trajectory.
              </p>
            </div>

            {/* Demographics & BMI Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Age (आयु)</label>
                <input
                  type="number"
                  value={age}
                  onChange={e => setAge(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Gender (लिंग)</label>
                <select
                  value={gender}
                  onChange={e => setGender(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Height (cm)</label>
                <input
                  type="number"
                  value={heightCm}
                  onChange={e => setHeightCm(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Weight (kg)</label>
                <input
                  type="number"
                  value={weightKg}
                  onChange={e => setWeightKg(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                  required
                />
              </div>
            </div>

            {/* Computed BMI Badge */}
            <div className="p-3 bg-black/50 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Real-Time Computed BMI:</span>
              <span className="font-bold text-cyan-300">
                {computedBmi} kg/m² ({computedBmi < 18.5 ? 'Underweight' : computedBmi < 25 ? 'Normal Weight' : computedBmi < 30 ? 'Overweight' : 'Obese Category'})
              </span>
            </div>

            {/* Symptoms Input */}
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Active Symptoms (लक्षण यदि कोई हों)</label>
              <textarea
                value={symptoms}
                onChange={e => setSymptoms(e.target.value)}
                placeholder="e.g. Mild headache, afternoon fatigue, slight eye strain, elevated resting heart rate..."
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                rows={2}
              />
            </div>

            {/* Lifestyle & Family History */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Daily Sleep Duration (नींद)</label>
                <input
                  type="text"
                  value={sleepHours}
                  onChange={e => setSleepHours(e.target.value)}
                  placeholder="e.g. 7.5 hours/day"
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Physical Exercise Level (व्यायाम)</label>
                <select
                  value={exerciseLevel}
                  onChange={e => setExerciseLevel(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                >
                  <option value="Sedentary (desk work, minimal cardio)">Sedentary (Desk work, minimal cardio)</option>
                  <option value="Moderate (3-4 days/week brisk walking or gym)">Moderate (3-4 days/week exercise)</option>
                  <option value="Active (daily athletic conditioning)">Active (Daily athletic conditioning)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Habits & Diet Lifestyle</label>
                <input
                  type="text"
                  value={lifestyleHabits}
                  onChange={e => setLifestyleHabits(e.target.value)}
                  placeholder="e.g. Non-smoker, vegetarian, 3L water"
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Family Chronic History (पारिवारिक इतिहास)</label>
                <input
                  type="text"
                  value={familyHistory}
                  onChange={e => setFamilyHistory(e.target.value)}
                  placeholder="e.g. Mild hypertension in elders, no diabetes"
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                />
              </div>
            </div>

            {/* Optional Medical Lab Report Upload */}
            <div className="p-4 bg-black/40 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-fuchsia-300">🩸 Optional Medical Lab Report Reader</span>
                <label className="cursor-pointer px-3 py-1.5 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg text-white text-xs font-bold transition-all">
                  {analyzingLab ? 'Analyzing Report...' : 'Upload Report Photo'}
                  <input type="file" accept="image/*,.pdf" onChange={handleLabReportUpload} className="hidden" />
                </label>
              </div>
              {labAnalysis && (
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  ✓ Report Processed: {labAnalysis.reportSummary}
                </p>
              )}
            </div>

            {/* Mandatory Medical Disclaimer Banner */}
            <div className="p-4 bg-amber-950/30 rounded-2xl border border-amber-500/40 text-xs text-amber-200 leading-relaxed">
              ⚠️ <strong>Clinical Notice:</strong> FuturePulse AI provides non-prescriptive, algorithmically simulated wellness forecasting. It does not replace clinical pathology or licensed medical consultation.
            </div>

            <ApiErrorBanner message={healthError} />

            {/* Primary Action Button */}
            <button
              type="submit"
              disabled={scanState === 'analyzing'}
              className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(16,185,129,0.4)] flex items-center justify-center gap-2 transition-all"
            >
              <HeartPulse className="w-5 h-5" />
              <span>{scanState === 'analyzing' ? 'Synthesizing Multi-Biometric Intelligence...' : '⚡ Predict Present Conditions & 5-Year Disease Risks'}</span>
            </button>
          </form>

          {/* COMPREHENSIVE RESULTS SECTION */}
          {healthResults && (
            <div className="space-y-6 pt-4">
              {/* Biological Age & Longevity Index Banner */}
              <div className="p-6 bg-gradient-to-r from-slate-950 to-black rounded-3xl border-2 border-emerald-500/50 shadow-[0_0_25px_rgba(16,185,129,0.25)] grid grid-cols-1 sm:grid-cols-2 gap-4 text-center">
                <div className="p-4 bg-black/60 rounded-2xl border border-cyan-500/30">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Estimated Biological Age</p>
                  <p className="text-3xl sm:text-4xl font-extrabold text-cyan-300 mt-1">
                    {healthResults.biologicalAge} <span className="text-xs font-normal text-slate-400">Years</span>
                  </p>
                  <p className="text-[10px] text-emerald-400 mt-1">
                    Chronological: {age} yrs ({Number(age) > healthResults.biologicalAge ? 'Youthful cellular vitality' : 'Age aligned'})
                  </p>
                </div>
                <div className="p-4 bg-black/60 rounded-2xl border border-emerald-500/30">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Longevity Vitality Index</p>
                  <p className="text-3xl sm:text-4xl font-extrabold text-emerald-300 mt-1">
                    {healthResults.longevityScore}%
                  </p>
                  <p className="text-[10px] text-emerald-400 mt-1">High Cellular Resilience & Low Vulnerability</p>
                </div>
              </div>

              {/* Present Health Conditions (Differential Diagnosis) */}
              <div className="p-6 bg-slate-900/60 rounded-3xl border border-cyan-500/30 space-y-4">
                <h4 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Present Conditions & Differential Diagnosis (वर्तमान स्थिति)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {healthResults.presentConditions?.map((c: any, i: number) => (
                    <div key={i} className="p-4 bg-black/60 rounded-2xl border border-slate-800 space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-cyan-200">{c.condition}</span>
                        <span className="text-[10px] font-bold text-amber-400 px-2 py-0.5 bg-amber-950/70 rounded-full border border-amber-500/30">
                          {c.probability}%
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{c.description}</p>
                      {c.keyIndicators && (
                        <p className="text-[10px] text-slate-500">Key Markers: {c.keyIndicators}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* 5-Year Future Disease Risks (EXPLICITLY COVERING ALL 4 PILLARS) */}
              <div className="p-6 bg-slate-900/60 rounded-3xl border border-emerald-500/40 space-y-4 shadow-lg">
                <div className="flex justify-between items-center">
                  <h4 className="text-sm sm:text-base font-bold text-emerald-300 flex items-center gap-2">
                    <Heart className="w-5 h-5 text-emerald-400" />
                    5-Year Future Disease Risks: Heart, Liver, Kidney & Diabetes (भविष्यफल)
                  </h4>
                  <span className="text-[10px] font-bold text-slate-400">Vulnerability Window: 5-Year Horizon</span>
                </div>

                <div className="space-y-4">
                  {healthResults.futureDiseaseRisks?.map((risk: any, i: number) => {
                    const barColor = risk.riskPercentage > 50 ? 'bg-red-500' : risk.riskPercentage > 25 ? 'bg-amber-500' : 'bg-emerald-500';
                    return (
                      <div key={i} className="p-4 bg-black/60 rounded-2xl border border-slate-800/90 space-y-2.5">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-1">
                          <span className="font-bold text-slate-100 text-sm">{i+1}. {risk.disease}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                              Window: {risk.vulnerabilityWindow}
                            </span>
                            <span className="text-xs font-mono font-bold text-emerald-400">
                              Risk Score: {risk.riskPercentage}%
                            </span>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                          <motion.div 
                            className={`h-full ${barColor}`} 
                            initial={{width: 0}} 
                            animate={{width: `${risk.riskPercentage}%`}} 
                            transition={{duration: 1}} 
                          />
                        </div>

                        <p className="text-xs text-slate-300 leading-relaxed">
                          <strong>Progression Factors:</strong> {risk.progressionFactors}
                        </p>

                        {risk.clinicalPreventionTips?.length > 0 && (
                          <div className="p-2.5 bg-slate-900/50 rounded-xl border border-emerald-950 text-[11px] text-emerald-300 space-y-1">
                            <strong className="block text-[10px] uppercase tracking-wider text-slate-400">Prevention Protocols:</strong>
                            {risk.clinicalPreventionTips.map((tip: string, idx: number) => (
                              <p key={idx}>• {tip}</p>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Actionable Prevention & Recovery Steps */}
              {healthResults.actionablePreventionPlan?.length > 0 && (
                <div className="p-6 bg-slate-900/60 rounded-3xl border border-cyan-500/30 space-y-3">
                  <h4 className="text-sm font-bold text-cyan-300">Actionable Recovery & Longevity Protocols</h4>
                  <div className="space-y-2 border-l-2 border-emerald-500 pl-4 text-xs text-slate-200">
                    {healthResults.actionablePreventionPlan.map((step: string, i: number) => (
                      <p key={i}>{step}</p>
                    ))}
                  </div>
                </div>
              )}

              {/* Dual-Language Voice Playback */}
              <DualVoicePlayer
                englishText={healthEnglishText}
                hindiText={healthHindiText}
                title="Health & Longevity Voice Readout / स्वास्थ्य रिपोर्ट ऑडियो"
              />

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button 
                  onClick={exportPDF} 
                  className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2 transition-all"
                >
                  <Share2 className="w-5 h-5" /> Export Medical Dossier (PDF / Share)
                </button>

                <button 
                  onClick={() => setHealthResults(null)} 
                  className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300 transition-all"
                >
                  Reset & Re-Scan
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FAMILY WELLNESS TAB */}
      {activeTab === 'family' && (
        <div className="space-y-6">
          <div className="p-6 bg-slate-900/60 rounded-3xl border border-fuchsia-500/40 space-y-4">
            <h3 className="text-lg font-bold text-fuchsia-300">
              Clinical Estimated Due Date (EDD) & Family Wellness
            </h3>
            <p className="text-xs text-slate-300">
              Calculates clinical gestational age and delivery windows using Naegele's Rule combined with active longevity parameters.
            </p>

            <div>
              <label className="text-xs text-fuchsia-400 mb-1 block">Last Menstrual Period (LMP) Date</label>
              <input
                type="date"
                value={lmpDate}
                onChange={e => setLmpDate(e.target.value)}
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-5 bg-black/70 rounded-2xl border border-slate-800 text-center">
                <p className="text-[10px] text-slate-400 uppercase font-bold">Estimated Delivery Date (EDD)</p>
                <p className="text-2xl font-extrabold text-fuchsia-400 mt-2">{eddInfo.edd}</p>
              </div>
              <div className="p-5 bg-black/70 rounded-2xl border border-slate-800 text-center">
                <p className="text-[10px] text-slate-400 uppercase font-bold">Gestational Duration</p>
                <p className="text-2xl font-extrabold text-cyan-300 mt-2">{eddInfo.gestationalWeeks}</p>
              </div>
            </div>

            <div className="p-4 bg-fuchsia-950/30 rounded-2xl border border-fuchsia-500/30 text-xs text-slate-300 space-y-1.5">
              <strong className="text-fuchsia-300">Prenatal Wellness Recommendations:</strong>
              <p>• Schedule 1st trimester ultrasound confirmation with your registered OB-GYN.</p>
              <p>• Maintain adequate folate and iron supplementation with daily 3L hydration.</p>
              <p>• Avoid unpasteurized food and strenuous heavy lifting during early gestational weeks.</p>
            </div>
          </div>
        </div>
      )}

      {/* FULLSCREEN TORCH PULSE SCANNER OVERLAY */}
      {scanState === 'pulse_scanning' && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center z-50 p-6 text-center font-mono">
          <div className="relative w-52 h-52 flex items-center justify-center">
            <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover rounded-full opacity-40 border-4 border-red-500" autoPlay playsInline muted />
            <canvas ref={canvasRef} className="hidden" />
            <motion.div animate={{scale: [1, 1.25, 1]}} transition={{repeat: Infinity, duration: 0.8}} className="absolute inset-0 rounded-full border-4 border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.8)]" />
            <Heart className="w-16 h-16 text-red-500 animate-pulse relative z-10" />
          </div>

          <div className="mt-5 flex items-center gap-2 text-[11px] px-3 py-1 rounded-full bg-slate-900 border border-slate-700">
            <span className={`w-2 h-2 rounded-full ${torchStatus === 'active' ? 'bg-amber-400 animate-pulse' : 'bg-slate-500'}`} />
            <span className="text-slate-200">
              {torchStatus === 'active' ? 'Rear Flashlight (Torch) ON' : 'Optical Camera Active'} • Red Signal {liveSignalLevel}%
            </span>
          </div>

          <p className="mt-4 text-lg sm:text-xl font-bold tracking-wider text-cyan-300">
            Scanning 30fps Fingertip PPG Capillary Density
          </p>
          <p className="text-xs text-slate-300 mt-2 max-w-sm">
            Place your fingertip gently over BOTH the rear camera lens and flashlight until the 12s scan finishes.
          </p>

          {/* Countdown & Progress */}
          <div className="w-72 h-3 bg-slate-900 rounded-full mt-6 overflow-hidden border border-slate-700">
            <div className="h-full bg-gradient-to-r from-red-500 to-cyan-500 transition-all duration-300" style={{width: `${pulseProgress}%`}} />
          </div>
          <div className="flex items-center gap-4 mt-3 text-xs font-mono">
            <span className="text-amber-400 font-bold">{timeLeft}s REMAINING</span>
            <span className="text-cyan-400 font-bold">{pulseProgress}% COMPLETE</span>
          </div>

          <button
            type="button"
            onClick={cancelPulseScan}
            className="mt-6 px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-xs text-slate-200 font-bold transition-all"
          >
            Cancel Scan & Turn Off Torch
          </button>
        </div>
      )}

      {/* PULSE PERMISSION PROMPT MODAL */}
      {scanState === 'pulse_permission' && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-6 font-mono">
          <div className="max-w-md w-full p-6 bg-slate-900 rounded-3xl border border-emerald-500/50 space-y-4 text-center">
            <Camera className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
            <h3 className="text-xl font-bold text-emerald-300">Rear Camera & Torch Access</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              FuturePulse AI requires temporary rear-camera access to illuminate capillary tissue with the device flashlight and measure your Heart Rate (BPM) over 12 seconds. Torch turns off automatically when finished.
            </p>
            <div className="pt-2 flex flex-col gap-2">
              <button 
                onClick={confirmPulseHardware} 
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg"
              >
                Allow Camera & Start 12s Scan
              </button>
              <button 
                onClick={() => setScanState('idle')} 
                className="w-full py-3 bg-slate-800 rounded-xl text-slate-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* HONEST PULSE SCAN COMPLETION POPUP (ONLY HEART RATE BPM) */}
      {pulseResultModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center z-50 p-4 font-mono">
          <div className="max-w-sm w-full p-6 bg-slate-900 rounded-3xl border border-emerald-500/50 space-y-4 text-center shadow-[0_0_40px_rgba(16,185,129,0.25)]">
            <HeartPulse className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-lg font-bold text-emerald-300">Pulse Scan Complete</h3>
            <div className="p-4 bg-black/70 rounded-2xl border border-emerald-500/30">
              <p className="text-[10px] text-slate-400 uppercase tracking-wider">Measured Heart Rate</p>
              <p className="text-4xl font-extrabold text-emerald-300 mt-1">{pulseResultModal.bpm} <span className="text-sm font-normal text-slate-400">BPM</span></p>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Camera flashlight has been turned off automatically. For Blood Pressure (BP) and SpO2, use the Smartwatch & Vitals Hub separately.
            </p>
            <button
              type="button"
              onClick={() => setPulseResultModal(null)}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white text-sm transition-all"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* SMARTWATCH & VITALS ENTRY MODAL */}
      {showDeviceModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center z-50 p-4 font-mono">
          <div className="max-w-md w-full p-6 bg-slate-900 rounded-3xl border border-amber-500/50 space-y-5">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-amber-400" /> Smartwatch & Vitals Hub
              </h3>
              <button onClick={() => setShowDeviceModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <button
              onClick={connectBluetoothDevice}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 rounded-xl font-bold text-white flex items-center justify-center gap-2 shadow-md"
            >
              <Bluetooth className="w-4 h-4" /> Pair Web Bluetooth Smart Device
            </button>

            <div className="relative flex items-center justify-center">
              <div className="border-t border-slate-800 w-full" />
              <span className="bg-slate-900 px-3 text-[10px] text-slate-500 uppercase tracking-widest absolute">or manual entry</span>
            </div>

            <form onSubmit={handleManualVitalsSubmit} className="space-y-4">
              <div>
                <label className="text-xs text-amber-300 mb-1 block">Device Model / Name (optional)</label>
                <input
                  type="text"
                  value={deviceName}
                  onChange={e => setDeviceName(e.target.value)}
                  placeholder="e.g. Apple Watch / Samsung Galaxy / Oximeter"
                  className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] text-cyan-300 block mb-1">Pulse (BPM)</label>
                  <input
                    type="number"
                    value={manualBpm}
                    onChange={e => setManualBpm(e.target.value)}
                    placeholder="e.g. 72"
                    className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                  />
                </div>
                <div>
                  <label className="text-[11px] text-emerald-300 block mb-1">SpO2 (%)</label>
                  <input
                    type="number"
                    value={manualSpo2}
                    onChange={e => setManualSpo2(e.target.value)}
                    placeholder="e.g. 98"
                    className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] text-amber-300 block mb-1">Blood Pressure</label>
                  <input
                    type="text"
                    value={manualBp}
                    onChange={e => setManualBp(e.target.value)}
                    placeholder="e.g. 120/80"
                    className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-600 hover:bg-amber-500 rounded-xl font-bold text-black shadow-md"
              >
                Save & Apply Vitals
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   CAREER PROJECTION MODULE (5-Year AI Impact & Salary Growth Roadmap)
   ========================================================================= */
function CareerPrediction({
  saveHistory,
  onShare,
  onNotify,
}: {
  saveHistory: any;
  onShare: any;
  onNotify: (msg: string) => void;
}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [currentRole, setCurrentRole] = useState('Senior Software Engineer');
  const [industry, setIndustry] = useState('Fintech & AI Systems');
  const [experienceYears, setExperienceYears] = useState('4 Years');
  const [currentSkills, setCurrentSkills] = useState('TypeScript, Python, LLM Architecture, Cloud Infrastructure');
  const [primaryGoal, setPrimaryGoal] = useState('Double annual earnings, transition to AI Architect / Founder');
  const [results, setResults] = useState<any>(null);

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setErrorMsg(null);
    setLoading(true);
    try {
      const data = await runCareerPrediction({
        currentRole,
        industry,
        experienceYears,
        currentSkills,
        primaryGoal,
      });
      setResults(data);
      setMode('results');
      saveHistory('Career Projection & Income Forecast', `Role: ${currentRole}. AI Automation Risk: ${data.aiAutomationRiskScore}%. Longevity: ${data.jobLongevityRating}`);
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : 'Failed to generate career forecast.';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const exportPDF = () => {
    if (!results) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(6, 182, 212);
    doc.text("FuturePulse AI - 5-Year Career & Salary Growth Roadmap", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Role: ${currentRole} | Industry: ${industry} | Experience: ${experienceYears}`, 14, 28);
    doc.text(`Current Skills: ${currentSkills}`, 14, 34);
    doc.text(`Primary Goal: ${primaryGoal}`, 14, 40);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 46);

    let y = 54;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text(`AI Automation Risk Score: ${results.aiAutomationRiskScore}% | Job Longevity: ${results.jobLongevityRating}`, 14, y);
    y += 10;

    doc.text("Executive Forecast Summary:", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitSummary = doc.splitTextToSize(results.forecastSummary, 180);
    doc.text(splitSummary, 14, y);
    y += (splitSummary.length * 5) + 8;

    doc.setFont("helvetica", "bold");
    doc.text("Top 3 High-Income Opportunities (Next 12 Months):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    results.topOpportunities?.forEach((opp: string, i: number) => {
      const splitOpp = doc.splitTextToSize(`${i+1}. ${opp}`, 180);
      doc.text(splitOpp, 14, y);
      y += (splitOpp.length * 5) + 4;
    });

    y += 4;
    doc.setFont("helvetica", "bold");
    doc.text("Step-by-Step 5-Year Action Plan:", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    results.actionPlan?.forEach((act: string, i: number) => {
      const splitAct = doc.splitTextToSize(`${i+1}. ${act}`, 180);
      doc.text(splitAct, 14, y);
      y += (splitAct.length * 5) + 4;
    });

    doc.save("Career_Salary_Roadmap.pdf");
    onNotify("Career Report saved to PDF successfully!");
  };

  const resultsEnglishText = results ? 
    `Career Forecast for ${currentRole} in ${industry}. AI Automation risk is ${results.aiAutomationRiskScore} percent. Job longevity rating: ${results.jobLongevityRating}. Summary: ${results.forecastSummary}. Top opportunities: ${results.topOpportunities?.join('. ')}. Action plan: ${results.actionPlan?.join('. ')}` : '';

  const resultsHindiText = results ? 
    `${currentRole} के लिए 5-वर्षीय करियर एवं वेतन वृद्धि रोडमैप। एआई ऑटोमेशन जोखिम ${results.aiAutomationRiskScore} प्रतिशत है। नौकरी दीर्घायु रेटिंग: ${results.jobLongevityRating}। मुख्य सारांश: ${results.forecastSummary}। अगले 12 महीनों के शीर्ष 3 उच्च-आय अवसर: ${results.topOpportunities?.join('। ')}। 5-वर्षीय कार्य योजना: ${results.actionPlan?.join('। ')}` : '';

  const resultsText = resultsEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: 'Career Forecast Report', text: resultsText}).catch(() => {});
    } else {
      onShare(resultsText, 'Career Forecast Dossier');
    }
  };

  if (mode === 'results' && results) return (
    <div className="space-y-6 pb-24 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-cyan-500/40">
        <div>
          <h2 className="text-xl font-bold text-cyan-300">5-Year Career & Salary Roadmap</h2>
          <p className="text-xs text-slate-400">{currentRole} • {industry} ({experienceYears})</p>
        </div>
        <button onClick={() => setMode('form')} className="text-xs text-cyan-400 hover:text-cyan-200 underline">
          New Forecast
        </button>
      </div>

      {/* Risk & Longevity Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-5 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">AI Automation Disruption Risk</p>
          <p className="text-3xl font-extrabold text-red-400 mt-1">{results.aiAutomationRiskScore}%</p>
          <div className="h-1.5 bg-black rounded-full overflow-hidden border border-slate-800 mt-2">
            <motion.div className="h-full bg-red-500" initial={{width: 0}} animate={{width: `${results.aiAutomationRiskScore}%`}} transition={{duration: 1}} />
          </div>
        </div>
        <div className="p-5 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Job Longevity Rating</p>
          <p className="text-2xl font-bold text-emerald-300 mt-2">{results.jobLongevityRating}</p>
        </div>
      </div>

      <div className="p-5 bg-slate-900/60 rounded-2xl border border-cyan-500/30 space-y-2 text-xs text-slate-200">
        <p className="font-bold text-cyan-300 uppercase tracking-wide">✨ Executive Forecast Summary</p>
        <p className="leading-relaxed">{results.forecastSummary}</p>
      </div>

      {/* Top 3 Opportunities */}
      <div className="p-5 bg-slate-900/60 rounded-2xl border border-amber-500/30 space-y-3">
        <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wide">
          Top 3 High-Income Skills & Growth Opportunities (अगले 12 महीने)
        </h4>
        <div className="space-y-2">
          {results.topOpportunities?.map((opp: string, i: number) => (
            <div key={i} className="p-3 bg-black/60 rounded-xl border border-slate-800 text-xs text-slate-200">
              • {opp}
            </div>
          ))}
        </div>
      </div>

      {/* Action Plan */}
      <div className="p-5 bg-slate-900/60 rounded-2xl border border-cyan-500/30 space-y-3">
        <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wide">
          Step-by-Step 5-Year Action Plan (Roadmap)
        </h4>
        <div className="space-y-2 border-l-2 border-cyan-500 pl-4">
          {results.actionPlan?.map((step: string, i: number) => (
            <p key={i} className="text-xs text-slate-200">{step}</p>
          ))}
        </div>
      </div>

      <DualVoicePlayer
        englishText={resultsEnglishText}
        hindiText={resultsHindiText}
        title="Career & Income Audio / करियर रिपोर्ट ऑडियो"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button 
          onClick={handleShareReport} 
          className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
        </button>

        <button 
          onClick={() => setMode('form')} 
          className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
        >
          New Career Analysis
        </button>
      </div>
    </div>
  );

  return (
    <form 
      onSubmit={handlePredict} 
      className="p-6 sm:p-8 pb-24 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-cyan-500/40 space-y-4 font-mono shadow-xl"
    >
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-cyan-300 flex items-center gap-2">
          <Brain className="w-6 h-6 text-cyan-400" /> 5-Year Career & Salary Growth Roadmap
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Input your role, industry, and skills to analyze AI automation risk and projected income trajectories.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Current Role / Job Title</label>
          <input
            type="text"
            value={currentRole}
            onChange={e => setCurrentRole(e.target.value)}
            placeholder="e.g. Software Engineer / Financial Analyst"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Industry / Sector</label>
          <input
            type="text"
            value={industry}
            onChange={e => setIndustry(e.target.value)}
            placeholder="e.g. Fintech, Healthcare, Cloud"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Years of Experience</label>
          <input
            type="text"
            value={experienceYears}
            onChange={e => setExperienceYears(e.target.value)}
            placeholder="e.g. 4 Years"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Core Skills (हुनर)</label>
          <input
            type="text"
            value={currentSkills}
            onChange={e => setCurrentSkills(e.target.value)}
            placeholder="e.g. React, Python, Cloud, Data"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>
      </div>

      <div>
        <label className="text-xs text-cyan-400 mb-1 block">Primary 5-Year Income / Career Goal</label>
        <input
          type="text"
          value={primaryGoal}
          onChange={e => setPrimaryGoal(e.target.value)}
          placeholder="e.g. Double salary and transition to AI team lead"
          className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
          required
        />
      </div>

      <ApiErrorBanner message={errorMsg} />

      <button
        type="submit"
        disabled={loading}
        className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all"
      >
        {loading ? 'Synthesizing Career Roadmap...' : '⚡ Generate 5-Year Career & Salary Roadmap'}
      </button>
    </form>
  );
}

/* =========================================================================
   COMPANY, FIRM & TRUST FUTURE ANALYZER (Google Search Grounded)
   ========================================================================= */
function CompanyTrustForecast({
  saveHistory,
  onShare,
  onNotify,
}: {
  saveHistory: any;
  onShare: any;
  onNotify: (msg: string) => void;
}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [entityName, setEntityName] = useState('Aarogyam Biotech & Trust');
  const [entityType, setEntityType] = useState('MSME Firm / Charitable Trust');
  const [industry, setIndustry] = useState('Healthcare, Herbal Products & Civic Wellness');
  const [location, setLocation] = useState('Rajasthan, India');
  const [currentStatus, setCurrentStatus] = useState('Operational with steady revenue, expanding distribution');
  const [results, setResults] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setErrorMsg(null);
    setLoading(true);
    try {
      const data = await runCompanyTrustForecast({entityName, entityType, industry, location, currentStatus});
      setResults(data);
      setMode('results');
      saveHistory('Company, Firm & Trust Future', `${entityName} (${entityType}): Profit Prob ${data.profitProbability}%, Survival ${data.marketSurvivalRating}`);
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : 'Failed to generate business forecast.';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const exportPDF = () => {
    if (!results) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(245, 158, 11);
    doc.text("FuturePulse AI - Company, Firm & Trust Strategic Dossier", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Entity: ${entityName} | Type: ${entityType}`, 14, 28);
    doc.text(`Sector: ${industry} | Location: ${location}`, 14, 34);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 40);

    let y = 48;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text(`Profit Probability: ${results.profitProbability}% | Market Survival: ${results.marketSurvivalRating}`, 14, y);
    y += 10;

    doc.text("Executive Strategic Summary:", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitSummary = doc.splitTextToSize(results.executiveSummary, 180);
    doc.text(splitSummary, 14, y);
    y += (splitSummary.length * 5) + 8;

    doc.setFont("helvetica", "bold");
    doc.text("What to Do (1-3 Year Action Steps):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    results.whatToDo?.forEach((item: string, i: number) => {
      const splitItem = doc.splitTextToSize(`${i+1}. ${item}`, 180);
      doc.text(splitItem, 14, y);
      y += (splitItem.length * 5) + 4;
    });

    doc.save("Company_Trust_Future_Report.pdf");
    onNotify("Company Report saved to PDF successfully!");
  };

  const companyEnglishText = results ? 
    `Company Future Forecast for ${entityName}. Profit probability is ${results.profitProbability} percent. Loss risk is ${results.lossProbability} percent. Market survival rating is ${results.marketSurvivalRating}. Executive Summary: ${results.executiveSummary}. What to do: ${results.whatToDo?.join('. ')}. What to avoid: ${results.whatToAvoid?.join('. ')}. Market demand trends: ${results.marketDemandTrends}. Regulatory risks: ${results.regulatoryRisks}.` : '';

  const companyHindiText = results ? 
    `${entityName} व्यापार एवं ट्रस्ट भविष्य पूर्वानुमान। लाभ की संभावना ${results.profitProbability} प्रतिशत है। हानि का जोखिम ${results.lossProbability} प्रतिशत है। बाजार में टिके रहने की रेटिंग: ${results.marketSurvivalRating}। मुख्य सारांश: ${results.executiveSummary}। क्या करें: ${results.whatToDo?.join('। ')}। क्या न करें: ${results.whatToAvoid?.join('। ')}। बाजार मांग रुझान: ${results.marketDemandTrends}। विनियामक जोखिम: ${results.regulatoryRisks}।` : '';

  const resultsText = companyEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: `${entityName} Future Dossier`, text: resultsText}).catch(() => {});
    } else {
      onShare(resultsText, 'Company, Firm & Trust Future Report');
    }
  };

  if (mode === 'results' && results) return (
    <div className="space-y-6 pb-24 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-amber-500/40">
        <div>
          <h2 className="text-xl font-bold text-amber-300">{entityName}</h2>
          <p className="text-xs text-slate-400">{entityType} • {industry} ({location})</p>
        </div>
        <button onClick={() => setMode('form')} className="text-xs text-amber-400 hover:text-amber-200 underline">
          New Analysis
        </button>
      </div>

      {/* Probability Matrix & Survival Rating */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Profit Probability</p>
          <p className="text-3xl font-extrabold text-emerald-400 mt-1">{results.profitProbability}%</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Loss Risk Probability</p>
          <p className="text-3xl font-extrabold text-red-400 mt-1">{results.lossProbability}%</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Market Survival Rating</p>
          <p className="text-base font-bold text-amber-300 mt-2">{results.marketSurvivalRating}</p>
        </div>
      </div>

      <div className="p-5 bg-slate-900/60 rounded-2xl border border-amber-500/30 space-y-2 text-xs text-slate-200">
        <p className="font-bold text-amber-400 uppercase tracking-wide">✨ Executive Strategic Forecast</p>
        <p className="leading-relaxed">{results.executiveSummary}</p>
      </div>

      {/* What To Do vs What To Avoid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-5 bg-slate-900/60 rounded-2xl border border-emerald-500/30 space-y-3">
          <p className="text-xs font-bold text-emerald-400 uppercase tracking-wide">✓ What To Do (अगले 1-3 साल क्या करें)</p>
          <div className="space-y-2 text-xs text-slate-200">
            {results.whatToDo?.map((item: string, i: number) => (
              <p key={i}>• {item}</p>
            ))}
          </div>
        </div>

        <div className="p-5 bg-slate-900/60 rounded-2xl border border-red-500/30 space-y-3">
          <p className="text-xs font-bold text-red-400 uppercase tracking-wide">✗ What To Avoid (क्या न करें - जोखिम)</p>
          <div className="space-y-2 text-xs text-slate-200">
            {results.whatToAvoid?.map((item: string, i: number) => (
              <p key={i}>• {item}</p>
            ))}
          </div>
        </div>
      </div>

      <div className="p-5 bg-slate-900/60 rounded-2xl border border-slate-800 space-y-2 text-xs text-slate-300">
        <p className="font-bold text-cyan-300 uppercase">Market Demand & Regulatory Intelligence</p>
        <p><strong>Demand Trends:</strong> {results.marketDemandTrends}</p>
        <p><strong>Regulatory Compliance:</strong> {results.regulatoryRisks}</p>
      </div>

      <GroundedSourcesList sources={results.sources} />

      <DualVoicePlayer
        englishText={companyEnglishText}
        hindiText={companyHindiText}
        title="Company & Trust Audio / व्यापार व ट्रस्ट ऑडियो"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button 
          onClick={handleShareReport} 
          className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
        </button>

        <button 
          onClick={() => setMode('form')} 
          className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
        >
          New Analysis
        </button>
      </div>
    </div>
  );

  return (
    <form 
      onSubmit={handleSubmit} 
      className="p-6 sm:p-8 pb-24 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-amber-500/40 space-y-4 font-mono shadow-xl"
    >
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
          <Building2 className="w-6 h-6 text-amber-400" /> Company, Firm & Trust Future Analyzer
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Real-time Google search grounded strategic forecasting for MSMEs, corporate firms, and non-profit trusts.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-amber-400 mb-1 block">Entity Name (कंपनी / फर्म / ट्रस्ट का नाम)</label>
          <input
            type="text"
            value={entityName}
            onChange={e => setEntityName(e.target.value)}
            placeholder="e.g. Aarogyam Biotech & Trust"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-amber-400 mb-1 block">Entity Structure</label>
          <select
            value={entityType}
            onChange={e => setEntityType(e.target.value)}
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
          >
            <option value="MSME Firm">MSME Firm / Startup</option>
            <option value="Private Limited Company">Private Limited Company</option>
            <option value="Charitable Trust / NGO">Charitable Trust / NGO</option>
            <option value="Partnership Firm">Partnership Firm</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-amber-400 mb-1 block">Industry / Sector</label>
          <input
            type="text"
            value={industry}
            onChange={e => setIndustry(e.target.value)}
            placeholder="e.g. Healthcare, Retail, IT Services"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-amber-400 mb-1 block">Location / Jurisdiction</label>
          <input
            type="text"
            value={location}
            onChange={e => setLocation(e.target.value)}
            placeholder="e.g. Rajasthan, India"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
            required
          />
        </div>
      </div>

      <div>
        <label className="text-xs text-amber-400 mb-1 block">Current Operational & Financial Status</label>
        <textarea
          value={currentStatus}
          onChange={e => setCurrentStatus(e.target.value)}
          placeholder="e.g. Breakeven revenue, seeking capital and market expansion..."
          className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
          rows={2}
          required
        />
      </div>

      <ApiErrorBanner message={errorMsg} />

      <button
        type="submit"
        disabled={loading}
        className="w-full py-4 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 rounded-xl font-bold text-black shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all"
      >
        {loading ? 'Synthesizing Search Grounded Forecast...' : '⚡ Generate Strategic Business Forecast'}
      </button>
    </form>
  );
}

/* =========================================================================
   DISEASE & OUTBREAK EARLY WARNING RADAR (Google Search Grounded)
   ========================================================================= */
function DiseaseRadarForecast({
  saveHistory,
  onShare,
  onNotify,
}: {
  saveHistory: any;
  onShare: any;
  onNotify: (msg: string) => void;
}) {
  const [locationQuery, setLocationQuery] = useState('Rajasthan, India');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [data, setData] = useState<any>(null);

  const fetchRadar = async (overrideLoc?: string) => {
    if (loading) return;
    const loc = overrideLoc || locationQuery;
    setErrorMsg(null);
    setLoading(true);
    try {
      const json = await runDiseaseRadar(loc);
      setData(json);
      saveHistory('Disease & Outbreak Radar', `Location: ${loc}. Alert: ${json.alertLevel}.`);
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : 'Failed to connect to Disease Radar surveillance feed.';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const exportPDF = () => {
    if (!data) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(244, 63, 94);
    doc.text("FuturePulse AI - Disease & Outbreak Radar Report", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Monitored Location: ${data.location}`, 14, 28);
    doc.text(`Alert Status: ${data.alertLevel} | Data Confidence: ${data.dataConfidenceScore}%`, 14, 34);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 40);

    let y = 48;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text("Active Health Alerts & Pathogen Surveillance:", 14, y);
    y += 8;

    data.currentActiveAlerts?.forEach((alert: any) => {
      if (y > 250) { doc.addPage(); y = 20; }
      doc.setFont("helvetica", "bold");
      doc.text(`• ${alert.diseaseName} (${alert.severity} Severity)`, 14, y);
      y += 5;
      doc.setFont("helvetica", "normal");
      const splitDesc = doc.splitTextToSize(alert.description, 180);
      doc.text(splitDesc, 14, y);
      y += (splitDesc.length * 5) + 4;
    });

    doc.save("Disease_Outbreak_Radar.pdf");
    onNotify("Outbreak Radar saved to PDF successfully!");
  };

  const alertsText = data?.currentActiveAlerts?.map((a: any) => `${a.diseaseName}: ${a.severity} severity. ${a.description}`).join('. ') || 'No critical active outbreaks detected';
  
  const radarEnglishText = data ? 
    `Disease and Outbreak Early Warning Radar for ${data.location}. Alert Level is ${data.alertLevel}. Data confidence score is ${data.dataConfidenceScore} percent. Active alerts: ${alertsText}. Three-month seasonal forecast: ${data.threeMonthForecast}. Preventive measures: ${data.preventiveSafetyMeasures?.join('. ')}. Public advisory: ${data.publicHealthNotice}` : '';

  const radarHindiText = data ? 
    `${data.location} क्षेत्र के लिए बीमारी एवं महामारी पूर्व चेतावनी रडार। चेतावनी स्तर: ${data.alertLevel}। डेटा विश्वसनीयता: ${data.dataConfidenceScore} प्रतिशत। सक्रिय अलर्ट: ${data?.currentActiveAlerts?.map((a: any) => `${a.diseaseName} (${a.severity} तीव्रता): ${a.description}`).join('। ') || 'कोई गंभीर अलर्ट नहीं'}। आगामी 3 माह का मौसमी पूर्वानुमान: ${data.threeMonthForecast}। बचाव के उपाय: ${data.preventiveSafetyMeasures?.join('। ')}। स्वास्थ्य सलाह: ${data.publicHealthNotice}` : '';

  const radarText = radarEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: `Disease Radar - ${data?.location}`, text: radarText}).catch(() => {});
    } else {
      onShare(radarText, 'Disease & Outbreak Radar Dossier');
    }
  };

  return (
    <div className="space-y-6 pb-24 font-mono">
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-rose-500/40 shadow-xl space-y-4 overflow-hidden">
        <div className="flex items-center gap-2">
          <Radio className="w-6 h-6 text-rose-400 animate-pulse shrink-0" />
          <h2 className="text-xl sm:text-2xl font-bold text-rose-300">
            Disease & Outbreak Early Warning Radar
          </h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          देश-राज्य और क्षेत्र में आने वाली बीमारियों का अलर्ट — Live Google Search grounded disease surveillance aggregating verified WHO, ICMR, and NCDC public health alerts for seasonal epidemics, vectors, and emerging pathogens.
        </p>

        {/* Quick Location Chips */}
        <div className="flex flex-wrap gap-2 text-xs">
          {['Rajasthan, India', 'Delhi NCR', 'Maharashtra', 'Uttar Pradesh', 'New York, USA', 'Global Watch'].map(loc => (
            <button
              key={loc}
              type="button"
              disabled={loading}
              onClick={() => { setLocationQuery(loc); fetchRadar(loc); }}
              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 disabled:opacity-50 border border-slate-700 text-slate-300 text-xs transition-colors"
            >
              {loc}
            </button>
          ))}
        </div>

        <form onSubmit={e => { e.preventDefault(); fetchRadar(); }} className="flex flex-col sm:flex-row gap-3 pt-1">
          <input
            type="text"
            value={locationQuery}
            onChange={e => setLocationQuery(e.target.value)}
            placeholder="Type any City, State, or Country..."
            className="w-full min-w-0 sm:flex-1 p-3 bg-black/60 rounded-xl border border-slate-800 text-rose-100 text-sm focus:border-rose-500 outline-none"
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full sm:w-auto shrink-0 px-6 py-3 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 rounded-xl font-bold text-white shadow-lg transition-all"
          >
            {loading ? 'Searching...' : 'Scan Area'}
          </button>
        </form>

        <ApiErrorBanner message={errorMsg} />
      </div>

      {data && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-rose-500/40 space-y-6 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-lg font-bold text-rose-200">Surveillance: {data.location}</h3>
              <p className="text-xs text-rose-400 font-bold">{data.alertLevel}</p>
            </div>
            <span className="text-[10px] text-cyan-400 bg-cyan-950 px-2.5 py-1 rounded-full border border-cyan-500/30">
              Confidence: {data.dataConfidenceScore}%
            </span>
          </div>

          {/* Active Outbreak Alerts */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wide">
              Active Outbreaks & Pathogen Surveillance (सक्रिय स्वास्थ्य अलर्ट)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {data.currentActiveAlerts?.map((alert: any, i: number) => (
                <div key={i} className="p-4 bg-black/60 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-rose-200">{alert.diseaseName}</span>
                    <span className="text-[10px] text-amber-400 px-2 py-0.5 bg-amber-950/70 rounded-full border border-amber-500/30">
                      {alert.severity}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{alert.description}</p>
                  {alert.trend && (
                    <p className="text-[10px] text-cyan-400">Trend: {alert.trend}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 3-Month Outbreak & Seasonal Risk Forecast */}
          <div className="p-5 bg-black/60 rounded-2xl border border-rose-500/30 space-y-2">
            <p className="text-xs font-bold text-rose-400 uppercase tracking-wide">
              🔮 3-Month Outbreak & Seasonal Risk Forecast (आगामी 3 महीनों का पूर्वानुमान)
            </p>
            <p className="text-xs text-slate-200 leading-relaxed">{data.threeMonthForecast}</p>
          </div>

          {/* Preventive Safety Measures */}
          <div className="p-5 bg-black/60 rounded-2xl border border-cyan-500/30 space-y-3">
            <p className="text-xs font-bold text-cyan-300 uppercase tracking-wide">
              🛡️ Preventive Safety Measures & Hygiene Protocols (बचाव व सावधानियां)
            </p>
            <div className="space-y-2">
              {data.preventiveSafetyMeasures?.map((measure: string, i: number) => (
                <div key={i} className="p-3 bg-slate-900/50 rounded-xl border border-slate-800 text-xs text-slate-200">
                  {measure}
                </div>
              ))}
            </div>
          </div>

          <GroundedSourcesList sources={data.sources} />

          <DualVoicePlayer
            englishText={radarEnglishText}
            hindiText={radarHindiText}
            title="Outbreak Radar Audio / महामारी रडार ऑडियो"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button 
              onClick={handleShareReport} 
              className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
            >
              <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
            </button>

            <button 
              onClick={() => setData(null)} 
              className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
            >
              New Location Scan
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   MACRO GEOPOLITICAL INTELLIGENCE (Google Search Grounded)
   ========================================================================= */
function GlobalHealthIntelligence({
  saveHistory,
  onShare,
  onNotify,
}: {
  saveHistory: any;
  onShare: any;
  onNotify: (msg: string) => void;
}) {
  const [data, setData] = useState<any>(null);
  const [countryOrTopic, setCountryOrTopic] = useState('India (भारत - आगामी चुनाव, नीतियां और बाजार रुझान)');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fetchMacro = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setErrorMsg(null);
    setLoading(true);
    try {
      const json = await runMacroForecast(countryOrTopic);
      setData(json);
      saveHistory('Macro Geopolitical Intelligence', `Target: ${countryOrTopic}. Policy Impact Score: ${json.policyImpactScore}/100.`);
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : 'Failed to connect to Macro Intelligence AI.';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const exportPDF = () => {
    if (!data) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(6, 182, 212);
    doc.text("FuturePulse AI - Macro Geopolitical & Economic Intelligence", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Target Region / Topic: ${countryOrTopic}`, 14, 28);
    doc.text(`Policy Impact Score: ${data.policyImpactScore}/100 | Confidence: ${data.dataConfidenceScore}%`, 14, 34);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 40);

    let y = 48;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text("Present Situation Summary (वर्तमान स्थिति):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitPres = doc.splitTextToSize(data.presentSituationSummary, 180);
    doc.text(splitPres, 14, y);
    y += (splitPres.length * 5) + 8;

    doc.setFont("helvetica", "bold");
    doc.text("Future Economic & Policy Impact Forecast (भविष्य का प्रभाव):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitFut = doc.splitTextToSize(data.futureImpactForecast, 180);
    doc.text(splitFut, 14, y);
    y += (splitFut.length * 5) + 8;

    doc.save("Macro_Intelligence_Report.pdf");
    onNotify("Macro Intelligence Report saved to PDF successfully!");
  };

  const macroEnglishText = data ? 
    `Macro Geopolitical Intelligence for ${countryOrTopic}. Policy Impact Score is ${data.policyImpactScore} out of 100. Data Confidence Score is ${data.dataConfidenceScore || 92} percent. Present Situation: ${data.presentSituationSummary}. Future Forecast: ${data.futureImpactForecast}. Key factors: ${data.keyFactualFactors?.join('. ')}.` : '';

  const macroHindiText = data ? 
    `${countryOrTopic} के लिए भू-राजनीतिक एवं नीतिगत विश्लेषण। नीतिगत प्रभाव स्कोर 100 में से ${data.policyImpactScore} है। डेटा विश्वसनीयता: ${data.dataConfidenceScore || 92} प्रतिशत। वर्तमान स्थिति: ${data.presentSituationSummary}। भविष्य का प्रभाव: ${data.futureImpactForecast}। मुख्य तथ्य: ${data.keyFactualFactors?.join('। ')}। आधिकारिक सूचना: यह विश्लेषण सर्च आधारित एआई सिमुलेशन है।` : '';

  const macroText = macroEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: 'Macro Intelligence Report', text: macroText}).catch(() => {});
    } else {
      onShare(macroText, 'Macro Geopolitical Report');
    }
  };

  return (
    <div className="space-y-6 pb-24 font-mono">
      <form 
        onSubmit={fetchMacro} 
        className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-violet-500/40 space-y-4 shadow-xl overflow-hidden"
      >
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-xl sm:text-2xl font-bold text-violet-300 flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-violet-400 shrink-0" /> Macro Geopolitical Intelligence
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time search grounded simulator for elections, economic policy shifts, gold/crypto trends, and international trade.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={countryOrTopic}
            onChange={e => setCountryOrTopic(e.target.value)}
            placeholder="e.g. India / USA / Gold Market / Upcoming Elections"
            className="w-full min-w-0 sm:flex-1 p-3 bg-black/60 rounded-xl border border-slate-800 text-violet-100 text-sm focus:border-violet-500 outline-none"
            required
          />
          <button 
            type="submit" 
            disabled={loading}
            className="w-full sm:w-auto shrink-0 px-6 py-3 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 rounded-xl font-bold text-white shadow-lg transition-all"
          >
            {loading ? 'Analyzing...' : 'Simulate'}
          </button>
        </div>

        <ApiErrorBanner message={errorMsg} />
      </form>

      {data && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-violet-500/40 space-y-6 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-lg font-bold text-violet-200">Target: {countryOrTopic}</h3>
              <p className="text-xs text-violet-400 font-bold">Policy Impact Score: {data.policyImpactScore}/100</p>
            </div>
            <span className="text-[10px] text-cyan-400 font-mono">
              CONFIDENCE: {data.dataConfidenceScore || 92}%
            </span>
          </div>

          {/* Scenario Breakdown */}
          {data.scenarioBreakdown && (
            <div className="p-5 bg-black/60 rounded-2xl border border-amber-500/30 space-y-3">
              <p className="text-xs font-bold text-amber-400 uppercase tracking-wide">
                Balanced Scenario Breakdown (परिप्रेक्ष्य विश्लेषण)
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-900/50 rounded-xl border border-cyan-500/30 space-y-1">
                  <p className="font-bold text-cyan-300">Scenario A (Optimistic Growth)</p>
                  <p className="text-slate-300 leading-relaxed">{data.scenarioBreakdown.scenarioA}</p>
                </div>
                <div className="p-3 bg-slate-900/50 rounded-xl border border-violet-500/30 space-y-1">
                  <p className="font-bold text-violet-300">Scenario B (Conservative / Risk)</p>
                  <p className="text-slate-300 leading-relaxed">{data.scenarioBreakdown.scenarioB}</p>
                </div>
              </div>
            </div>
          )}

          {/* Present Situation Summary */}
          <div className="p-4 bg-black/60 rounded-2xl border border-cyan-500/30 space-y-1.5">
            <p className="text-xs font-bold text-amber-400 uppercase tracking-wide">वर्तमान स्थिति (Present Situation)</p>
            <p className="text-xs text-slate-200 leading-relaxed">{data.presentSituationSummary}</p>
          </div>

          {/* Future Economic / Policy Impact Forecast */}
          <div className="p-4 bg-black/60 rounded-2xl border border-violet-500/30 space-y-1.5">
            <p className="text-xs font-bold text-violet-400 uppercase tracking-wide">भविष्य का प्रभाव (Future Impact Forecast)</p>
            <p className="text-xs text-slate-200 leading-relaxed">{data.futureImpactForecast}</p>
          </div>

          <GroundedSourcesList sources={data.sources} />

          <DualVoicePlayer
            englishText={macroEnglishText}
            hindiText={macroHindiText}
            title="Geopolitical Forecast Audio / भू-राजनीतिक रिपोर्ट ऑडियो"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button 
              onClick={handleShareReport} 
              className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
            >
              <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
            </button>

            <button 
              onClick={() => setData(null)} 
              className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
            >
              New Query
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   ENTERPRISE DISRUPTIVE ROADMAP MODULE
   ========================================================================= */
function OrgForecasting({
  saveHistory,
  onShare,
}: {
  saveHistory: any;
  onShare: any;
}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [orgType, setOrgType] = useState('Autonomous AI Hardware & EV Fleet');
  const [ticker, setTicker] = useState('TSLA');
  const [region] = useState('Global');
  const [objectives, setObjectives] = useState('Deploy next-gen AI agentic workflow across core supply chains');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;
    setErrorMsg(null);
    setLoading(true);
    try {
      const data = await runOrgForecast({orgType, ticker, region, objectives});
      setResults(data);
      setMode('results');
      saveHistory('Enterprise Disruptive Roadmap', `Org: ${orgType} (${ticker || 'N/A'}). Disruption Risk: ${data.disruptionRisk}%.`);
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : 'Failed to generate enterprise forecast.';
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const orgEnglishText = results ? 
    `Enterprise Disruption Risk for ${results.liveMarket?.identifier || 'Organization'} is ${results.disruptionRisk} percent. Market capitalization: ${results.liveMarket?.marketCapUsd}. Trajectory assessment: ${results.trajectory}. Strategic pivot roadmap: ${results.pivotRoadmap?.join(', ')}.` : '';

  const orgHindiText = results ? 
    `${results.liveMarket?.identifier || 'संस्थान'} के लिए कॉर्पोरेट डिसरप्शन रिस्क ${results.disruptionRisk} प्रतिशत है। मार्केट कैप: ${results.liveMarket?.marketCapUsd}। संस्थागत प्रक्षेपवक्र: ${results.trajectory}। रणनीतिक पिवट रोडमैप: ${results.pivotRoadmap?.join('। ')}। आधिकारिक सूचना: बाजार जोखिम व पूर्वानुमान हेतु विशेषज्ञों से परामर्श लें।` : '';

  const resultsText = orgEnglishText;

  if (mode === 'results' && results) return (
    <div className="space-y-6 pb-24 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-fuchsia-500/40">
        <h2 className="text-xl font-bold text-fuchsia-300">
          Institutional Dossier ({results.liveMarket?.identifier})
        </h2>
        <button onClick={() => setMode('form')} className="text-xs text-fuchsia-400 hover:text-fuchsia-200 underline">
          New Query
        </button>
      </div>

      {/* Live Market Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Market Cap</p>
          <p className="text-xl font-bold text-cyan-300 mt-1">{results.liveMarket?.marketCapUsd}</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Volatility Beta</p>
          <p className="text-xl font-bold text-amber-300 mt-1">{results.liveMarket?.volatilityBeta}</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Disruption Index</p>
          <p className="text-xl font-bold text-red-400 mt-1">{results.liveMarket?.industryDisruptionIndex}%</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Liquidity Ratio</p>
          <p className="text-xl font-bold text-emerald-300 mt-1">{results.liveMarket?.liquidityRatio}</p>
        </div>
      </div>

      <div className="p-6 bg-slate-900/60 rounded-3xl border border-fuchsia-500/40 space-y-4">
        <h4 className="text-fuchsia-200 text-sm font-bold">Disruption Risk Analysis</h4>
        <div className="h-3 bg-black rounded-full overflow-hidden border border-slate-800">
          <motion.div className="h-full bg-red-500" initial={{width: 0}} animate={{width: `${results.disruptionRisk}%`}} transition={{duration: 1}} />
        </div>
        <p className="text-sm text-slate-200 bg-black/50 p-4 rounded-xl border border-slate-800">{results.trajectory}</p>
        <h4 className="text-fuchsia-200 text-sm font-bold">Strategic Pivot Roadmap (Tesla/SpaceX Grade)</h4>
        <div className="border-l-2 border-fuchsia-500 pl-4 space-y-2">
          {results.pivotRoadmap.map((r: string, i: number) => (
            <p key={i} className="text-xs text-slate-200">Action {i+1}: {r}</p>
          ))}
        </div>
      </div>

      <GroundedSourcesList sources={results.sources} />

      <DualVoicePlayer
        englishText={orgEnglishText}
        hindiText={orgHindiText}
        title="Enterprise Roadmap Audio / कॉर्पोरेट रोडमैप ऑडियो"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button 
          onClick={() => onShare(resultsText, 'Enterprise Disruptive Dossier')} 
          className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-lg flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" /> Export Report (Share)
        </button>

        <button 
          onClick={() => setMode('form')} 
          className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
        >
          New Analysis
        </button>
      </div>
    </div>
  );

  return (
    <form 
      onSubmit={handleSubmit} 
      className="p-6 sm:p-8 pb-24 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-fuchsia-500/40 space-y-4 font-mono shadow-xl"
    >
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-fuchsia-300 flex items-center gap-2">
          <User className="w-6 h-6 text-fuchsia-400" /> Enterprise Disruptive Intelligence
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Input corporate parameters with live market connectors to generate high-fidelity disruption risk and pivot roadmaps.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-fuchsia-400 mb-1 block">Company / Sector Name</label>
          <input
            type="text"
            value={orgType}
            onChange={e => setOrgType(e.target.value)}
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-fuchsia-400 mb-1 block">Ticker Symbol (optional)</label>
          <input
            type="text"
            value={ticker}
            onChange={e => setTicker(e.target.value)}
            placeholder="e.g. TSLA, NVDA"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
          />
        </div>
      </div>

      <div>
        <label className="text-xs text-fuchsia-400 mb-1 block">Strategic Transformation Objectives</label>
        <textarea
          value={objectives}
          onChange={e => setObjectives(e.target.value)}
          placeholder="e.g. Deploy next-gen AI agentic workflow across core supply chains..."
          className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
          rows={2}
          required
        />
      </div>

      <ApiErrorBanner message={errorMsg} />

      <button
        type="submit"
        disabled={loading}
        className="w-full py-4 bg-gradient-to-r from-fuchsia-600 to-pink-600 hover:from-fuchsia-500 hover:to-pink-500 rounded-xl font-bold text-white shadow-lg transition-all"
      >
        {loading ? 'Synthesizing Enterprise Model...' : '⚡ Generate Strategic Disruption Dossier'}
      </button>
    </form>
  );
}

/* =========================================================================
   PARTNERSHIPS & ENTERPRISE DESK
   ========================================================================= */
function PartnershipsDesk({saveHistory}: {saveHistory: any}) {
  const [orgName, setOrgName] = useState('');
  const [email, setEmail] = useState('');
  const [inquiryType, setInquiryType] = useState('Enterprise Research Partnership');
  const [message, setMessage] = useState('');
  const [submittedId, setSubmittedId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = 'REQ-' + Math.floor(100000 + Math.random() * 900000);
    setSubmittedId(id);
    saveHistory('Enterprise Desk Inquiry', `Inquiry Ref: ${id} by ${orgName}`);
  };

  return (
    <div className="p-6 sm:p-8 pb-24 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-cyan-500/40 space-y-6 font-mono shadow-xl">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-cyan-300">
          Enterprise & Institutional Partnerships Portal
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Confidential portal for university labs, public health institutes, civic organizations, and corporate partners.
        </p>
      </div>

      {submittedId ? (
        <div className="p-6 bg-slate-900/80 rounded-2xl border border-emerald-500/40 space-y-3 text-center">
          <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
          <h3 className="text-lg font-bold text-emerald-300">Inquiry Dispatched Successfully</h3>
          <p className="text-xs text-slate-300">Reference ID: <strong className="text-cyan-400">{submittedId}</strong></p>
          <p className="text-xs text-slate-400">Our enterprise technical team will review your parameters within 24 business hours.</p>
          <button onClick={() => setSubmittedId('')} className="mt-2 px-6 py-2 bg-slate-800 rounded-xl text-xs text-slate-300">
            Submit Another Request
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Organization / Entity Name</label>
              <input
                type="text"
                value={orgName}
                onChange={e => setOrgName(e.target.value)}
                placeholder="e.g. Health Systems Institute"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
                required
              />
            </div>
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Official Contact Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="official@institution.org"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Collaboration Track</label>
            <select
              value={inquiryType}
              onChange={e => setInquiryType(e.target.value)}
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
            >
              <option value="Enterprise Research Partnership">Enterprise Predictive Research</option>
              <option value="Civic Disease Radar Integration">Public Health Radar Integration</option>
              <option value="API Licensing & Supercomputing Access">API Licensing & Data Access</option>
              <option value="Media & Press Inquiry">Media & Technical Inquiries</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Scope of Inquiry & Technical Objectives</label>
            <textarea
              value={message}
              onChange={e => setMessage(e.target.value)}
              placeholder="Outline your deployment objectives, data requirements, and partnership timeline..."
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
              rows={3}
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl font-bold text-white shadow-lg transition-all"
          >
            Dispatch Enterprise Inquiry
          </button>
        </form>
      )}
    </div>
  );
}
