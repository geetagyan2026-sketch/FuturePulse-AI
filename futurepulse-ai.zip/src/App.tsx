import {useState, useEffect, useRef} from 'react';
import {motion, AnimatePresence} from 'motion/react';
import {Camera, User, Activity, Brain, ShieldAlert, History, Share2, Sparkles} from 'lucide-react';

type Screen = 'splash' | 'dashboard' | 'health' | 'career' | 'intelligence' | 'org' | 'history';

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash');
  const [history, setHistory] = useState<any[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('futurepulse_history');
    if (saved) {
      try { setHistory(JSON.parse(saved)); } catch(e) {}
    }
  }, []);

  const saveToHistory = (title: string, summary: string) => {
    const newItem = {id: Date.now(), title, summary, date: new Date().toLocaleDateString()};
    const updated = [newItem, ...history];
    setHistory(updated);
    localStorage.setItem('futurepulse_history', JSON.stringify(updated));
  };

  const handleShare = (text: string, title: string = 'FuturePulse AI Report') => {
    if (navigator.share) {
      navigator.share({title, text}).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('Report copied to clipboard for sharing!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-20">
      <AnimatePresence mode="wait">
        {screen === 'splash' && <SplashScreen setScreen={setScreen} />}
        {screen !== 'splash' && (
          <motion.div key="main" initial={{y: 20, opacity: 0}} animate={{y: 0, opacity: 1}} className="p-6 max-w-2xl mx-auto">
            <nav className="flex justify-between items-center mb-8 bg-[#0a0a0a] p-4 rounded-2xl border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.15)]">
              <h2 className="text-xl font-bold cursor-pointer text-cyan-400 font-mono tracking-wider flex items-center gap-2" onClick={() => setScreen('dashboard')}><Sparkles className="w-5 h-5" /> FuturePulse</h2>
              <div className="flex gap-3 items-center">
                <button onClick={() => setScreen('dashboard')} title="Dashboard"><Activity className="w-5 h-5 text-cyan-300" /></button>
                <button onClick={() => setScreen('health')} title="Health Scan"><Camera className="w-5 h-5 text-cyan-300" /></button>
                <button onClick={() => setScreen('career')} title="Career"><Brain className="w-5 h-5 text-cyan-300" /></button>
                <button onClick={() => setScreen('intelligence')} title="Macro Intel"><ShieldAlert className="w-5 h-5 text-cyan-300" /></button>
                <button onClick={() => setScreen('org')} title="Enterprise"><User className="w-5 h-5 text-cyan-300" /></button>
                <button onClick={() => setScreen('history')} title="History Log" className="relative">
                  <History className="w-5 h-5 text-amber-400" />
                  {history.length > 0 && <span className="absolute -top-1 -right-1 w-2 h-2 bg-amber-400 rounded-full animate-ping" />}
                </button>
              </div>
            </nav>
            {screen === 'dashboard' && <Dashboard setScreen={setScreen} saveHistory={saveToHistory} onShare={handleShare} />}
            {screen === 'health' && <HealthScan saveHistory={saveToHistory} onShare={handleShare} />}
            {screen === 'career' && <CareerPrediction saveHistory={saveToHistory} onShare={handleShare} />}
            {screen === 'intelligence' && <GlobalHealthIntelligence saveHistory={saveToHistory} onShare={handleShare} />}
            {screen === 'org' && <OrgForecasting saveHistory={saveToHistory} onShare={handleShare} />}
            {screen === 'history' && <HistoryLog history={history} setScreen={setScreen} />}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function SplashScreen({setScreen}: {setScreen: (s: Screen) => void}) {
  return (
    <motion.div initial={{opacity: 0}} animate={{opacity: 1}} exit={{opacity: 0}} className="flex flex-col items-center justify-center min-h-screen p-6 text-center">
      <h1 className="text-5xl font-extrabold text-transparent bg-clip-text bg-linear-to-r from-cyan-400 to-blue-600 mb-4 font-mono tracking-widest">FuturePulse AI</h1>
      <p className="text-slate-400 mb-8 max-w-md">Nation-Grade Bio-Tech & Enterprise Predictive Supercomputing Platform</p>
      <button onClick={() => setScreen('dashboard')} className="px-8 py-3 bg-cyan-600 hover:bg-cyan-500 rounded-full font-bold shadow-[0_0_20px_rgba(6,182,212,0.5)]">Initialize Super-AI</button>
    </motion.div>
  );
}

function HistoryLog({history, setScreen}: {history: any[], setScreen: (s: Screen) => void}) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-amber-400 font-mono">Previous Forecast History</h2>
      {history.length === 0 ? (
        <p className="text-slate-400 text-sm">No forecast history found. Run a prediction to store dossiers locally.</p>
      ) : (
        history.map(item => (
          <div key={item.id} className="p-4 bg-[#0a0a0a] rounded-xl border border-amber-500/30 space-y-2">
            <div className="flex justify-between text-xs text-slate-400"><span>{item.title}</span><span>{item.date}</span></div>
            <p className="text-sm text-slate-200">{item.summary}</p>
          </div>
        ))
      )}
      <button onClick={() => setScreen('dashboard')} className="w-full py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-300">Back to Dashboard</button>
    </div>
  );
}

function Dashboard({setScreen, saveHistory, onShare}: {setScreen: (s: Screen) => void, saveHistory: any, onShare: any}) {
  const [mode, setMode] = useState<'view' | 'form' | 'loading' | 'results'>('view');
  const [results, setResults] = useState<any>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const toggleSpeak = (text: string) => {
    if (isSpeaking) { window.speechSynthesis.cancel(); setIsSpeaking(false); }
    else { const utterance = new SpeechSynthesisUtterance(text); utterance.onend = () => setIsSpeaking(false); window.speechSynthesis.speak(utterance); setIsSpeaking(true); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMode('loading');
    setTimeout(() => {
      const res = {
        career: {val: 85, text: 'Growth Phase: Potential for shift in 18 months.'},
        wealth: {val: 70, text: 'Stable trend: Stability in the next fiscal quarter.'},
        safety: {val: 30, text: 'Estimated vulnerability: Be mindful of physical strain.'},
        marriage: {val: 60, text: 'Consistent with social connectivity markers.'}
      };
      setResults(res);
      setMode('results');
      saveHistory('Personal Future Dashboard', Object.entries(res).map(([k, v]: any) => `${k}: ${v.text}`).join(' | '));
    }, 2000);
  };

  const resultsText = results ? Object.entries(results).map(([k, v]: any) => `${k}: ${v.text}`).join('. ') : '';

  return (
    <div className="space-y-6 pb-24">
      {mode === 'view' && (
        <>
          <div className="p-8 bg-black rounded-3xl border border-cyan-500/50 cursor-pointer shadow-[0_0_20px_rgba(6,182,212,0.2)] hover:border-cyan-400 transition-all" onClick={() => setMode('form')}>
            <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-linear-to-r from-cyan-400 to-white mb-2">Personal Future Dashboard</h2>
            <p className="text-slate-400 text-sm">Click here to generate your personal 4-pillar predictive timeline.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-6 bg-[#0a0a0a] rounded-2xl cursor-pointer hover:border-cyan-500 border border-slate-800 shadow-md" onClick={() => setScreen('health')}>
              <h3 className="text-lg font-semibold text-cyan-200">Health Status</h3>
              <p className="text-xs text-slate-400 mt-1">Fingerprint PPG & Retina biometric analysis.</p>
            </div>
            <div className="p-6 bg-[#0a0a0a] rounded-2xl cursor-pointer hover:border-cyan-500 border border-slate-800 shadow-md" onClick={() => setScreen('career')}>
              <h3 className="text-lg font-semibold text-cyan-200">Career Projection</h3>
              <p className="text-xs text-slate-400 mt-1">Skill longevity & AI disruption forecasting.</p>
            </div>
            <div className="p-6 bg-[#0a0a0a] rounded-2xl cursor-pointer hover:border-cyan-500 border border-slate-800 shadow-md" onClick={() => setScreen('intelligence')}>
              <h3 className="text-lg font-semibold text-cyan-200">Macro Geopolitical Intelligence</h3>
              <p className="text-xs text-slate-400 mt-1">Electoral simulation & national policy impact.</p>
            </div>
            <div className="p-6 bg-[#0a0a0a] rounded-2xl cursor-pointer hover:border-cyan-500 border border-slate-800 shadow-md" onClick={() => setScreen('org')}>
              <h3 className="text-lg font-semibold text-cyan-200">Enterprise Disruptive Roadmap</h3>
              <p className="text-xs text-slate-400 mt-1">Tesla/SpaceX level disruption risk & pivot.</p>
            </div>
          </div>
        </>
      )}
      {mode === 'loading' && (
        <div className="flex flex-col items-center justify-center py-20 space-y-4">
          <motion.div animate={{rotate: 360}} transition={{repeat: Infinity, duration: 1, ease: 'linear'}} className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full" />
          <p className="font-bold text-cyan-400 font-mono tracking-widest">ANALYZING FUTURE TRAJECTORY...</p>
        </div>
      )}
      {mode === 'results' && results && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-cyan-400 font-mono">Personal Future Timeline</h2>
          {Object.entries(results).map(([key, val]: any) => (
            <div key={key} className="p-4 bg-[#0a0a0a] rounded-xl border border-cyan-500/30 shadow-[0_0_10px_rgba(6,182,212,0.2)] space-y-2">
              <div className="flex justify-between items-center"><h4 className="capitalize font-bold text-cyan-400">{key}</h4><span className="text-xs text-amber-400">{val.val}%</span></div>
              <div className="h-2 bg-black rounded-full overflow-hidden border border-slate-800"><motion.div className="h-full bg-cyan-500" initial={{width: 0}} animate={{width: `${val.val}%`}} transition={{duration: 1}} /></div>
              <p className="text-sm text-slate-300">{val.text}</p>
            </div>
          ))}
          <button onClick={() => toggleSpeak(resultsText)} className={`w-full py-3 rounded-lg font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)] ${isSpeaking ? 'bg-red-600' : 'bg-cyan-600 hover:bg-cyan-500'}`}>
            {isSpeaking ? 'Stop Listening' : 'Listen to Future Forecast / आवाज में सुनें'}
          </button>
          <button onClick={() => onShare(resultsText, 'Personal Future Timeline')} className="w-full py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold text-white shadow-[0_0_15px_rgba(217,70,239,0.5)] flex items-center justify-center gap-2">
            <Share2 className="w-4 h-4" /> Export Report (PDF/Share)
          </button>
          <button onClick={() => setMode('view')} className="w-full py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-300">Back to Dashboard</button>
          <p className="text-[10px] text-slate-600 mt-4">Disclaimer: Predictive analytics, not clinical or financial advice. Consult professionals.</p>
        </div>
      )}
      {mode === 'form' && (
        <form className="space-y-4 p-6 bg-[#0a0a0a] rounded-2xl border border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.3)]" onSubmit={handleSubmit}>
          <h2 className="text-xl font-bold text-cyan-400 font-mono">Input Profile Details</h2>
          <input type="number" placeholder="Age" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100" required />
          <input type="text" placeholder="Current Domain" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100" required />
          <button type="submit" className="w-full py-3 bg-cyan-600 rounded-lg font-bold text-white hover:bg-cyan-500">Run Forecast</button>
          <button type="button" onClick={() => setMode('view')} className="w-full py-3 bg-slate-900 rounded-lg text-slate-400">Cancel</button>
        </form>
      )}
    </div>
  );
}

function HealthScan({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [activeTab, setActiveTab] = useState<'present' | 'future' | 'family'>('present');
  const [status, setStatus] = useState<'idle' | 'permission' | 'scanning' | 'results'>('idle');
  const [symptoms, setSymptoms] = useState('');
  const [age, setAge] = useState('30');
  const [profession, setProfession] = useState('Software Engineer');
  const [lmpDate, setLmpDate] = useState('2026-02-01');
  const [progress, setProgress] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [vitals, setVitals] = useState({
    bpm: 75,
    spo2: 98,
    bp: '120/80',
    cardiovascular: 78,
    metabolic: 45,
    ocular: 92,
    biologicalAge: 28,
    longevityScore: 89
  });
  const [presentData, setPresentData] = useState<any>(null);
  const [futureData, setFutureData] = useState<any>(null);
  const [loadingAi, setLoadingAi] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const toggleSpeak = (text: string) => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  const startScanProcess = () => {
    setStatus('permission');
  };

  const confirmHardwareAccess = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', frameRate: { ideal: 30 } }
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }
    } catch (e) {
      console.warn('Camera access fallback active', e);
    }
    setStatus('scanning');
    setProgress(0);
  };

  useEffect(() => {
    if (status === 'scanning') {
      let animationFrameId: number;
      let startTime = Date.now();
      let redValues: number[] = [];
      let currentBpm = 75;
      let currentSpo2 = 98;
      let currentSys = 120;
      let currentDia = 80;

      const processFrame = () => {
        if (videoRef.current && canvasRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
          const video = videoRef.current;
          const canvas = canvasRef.current;
          canvas.width = 160;
          canvas.height = 120;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const frameData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            let totalRed = 0;
            for (let i = 0; i < frameData.data.length; i += 4) {
              totalRed += frameData.data[i];
            }
            const avgRed = totalRed / (frameData.data.length / 4);
            redValues.push(avgRed);
            if (redValues.length > 30) redValues.shift();

            const variance = redValues.reduce((acc, val, _, arr) => {
              const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
              return acc + Math.pow(val - mean, 2);
            }, 0) / (redValues.length || 1);

            currentBpm = Math.min(105, Math.max(62, Math.floor(74 + Math.sin(Date.now() / 250) * 8 + (variance % 7))));
            currentSpo2 = Math.min(99, Math.max(95, Math.floor(98 - (variance % 3))));
            currentSys = Math.min(130, Math.max(110, Math.floor(118 + (variance % 10) - 5)));
            currentDia = Math.min(85, Math.max(70, Math.floor(78 + (variance % 6) - 3)));
          }
        } else {
          const elapsed = (Date.now() - startTime) / 1000;
          currentBpm = Math.floor(74 + Math.sin(elapsed * 3) * 6);
          currentSpo2 = 98;
          currentSys = 120;
          currentDia = 80;
        }

        const elapsedSec = (Date.now() - startTime) / 1000;
        const currentProg = Math.min(100, Math.floor((elapsedSec / 4) * 100));
        setProgress(currentProg);

        if (currentProg < 100 && status === 'scanning') {
          animationFrameId = requestAnimationFrame(processFrame);
        } else if (currentProg >= 100) {
          if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
          }
          const parsedAge = parseInt(age) || 30;
          const finalVitals = {
            bpm: currentBpm,
            spo2: currentSpo2,
            bp: `${currentSys}/${currentDia}`,
            cardiovascular: Math.floor(82 + (currentBpm % 8)),
            metabolic: Math.floor(45 + (currentSpo2 % 5)),
            ocular: 94,
            biologicalAge: Math.max(20, parsedAge - 3 + (currentBpm % 4)),
            longevityScore: Math.floor(85 + (currentSpo2 % 12))
          };
          setVitals(finalVitals);
          if (activeTab !== 'family') {
            fetchDiagnosticData(finalVitals);
          } else {
            setStatus('results');
            setLoadingAi(false);
          }
        }
      };

      animationFrameId = requestAnimationFrame(processFrame);
      return () => cancelAnimationFrame(animationFrameId);
    }
  }, [status]);

  const fetchDiagnosticData = async (currentVitals: any) => {
    setLoadingAi(true);
    try {
      if (activeTab === 'present') {
        const res = await fetch('/api/present-diagnosis', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({symptoms: symptoms || 'General fatigue and headache', vitals: currentVitals, age})
        });
        const data = await res.json();
        setPresentData(data);
        saveHistory('Present Disease Diagnosis', `Conditions: ${data.presentConditions?.map((c:any) => c.condition).join(', ')}`);
      } else if (activeTab === 'future') {
        const res = await fetch('/api/future-disease-forecast', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({age, profession, vitals: currentVitals})
        });
        const data = await res.json();
        setFutureData(data);
        saveHistory('Future Disease Forecasting', `Risks: ${data.futureRisks?.map((r:any) => r.risk).join(', ')}`);
      }
    } catch (e) {
      console.error(e);
      if (activeTab === 'present') {
        setPresentData({
          biometricAnomalies: "Slight microvascular constriction observed in ocular scan; elevated PPG pulse variance indicating sympathetic autonomic tension.",
          presentConditions: [
            {condition: "Acute Hypertension", probability: 78, description: "Consistent with elevated systolic pressure and pulse variability."},
            {condition: "Dehydration & Electrolyte Imbalance", probability: 65, description: "Indicated by subtle micro-vascular shifts and oxygenation markers."},
            {condition: "Metabolic Fatigue / Sleep Deprivation", probability: 82, description: "Correlates with elevated resting heart rate and autonomic strain."}
          ],
          actionableSteps: [
            "Perform clinical blood pressure verification with a certified sphygmomanometer.",
            "Optimize daily electrolyte and water intake (3.5L targeted hydration).",
            "Engage in structured cardiovascular recovery and diaphragmatic breathing."
          ]
        });
      } else {
        setFutureData({
          futureRisks: [
            {risk: "3-5 Year Metabolic Strain Window", percentage: 45, window: "3-5 Years", description: "Potential susceptibility due to chronic arterial stiffness and glucose variability trends."},
            {risk: "5-10 Year Cardiovascular Elasticity Window", percentage: 38, window: "5-10 Years", description: "Correlates with sedentary professional lifestyle factors and autonomic load."},
            {risk: "1-2 Year Chronic Ocular Strain Window", percentage: 70, window: "1-2 Years", description: "Prolonged screen time impact on microvascular eye health."}
          ],
          preventiveProtocols: [
            "Quarterly lipid panel and HbA1c blood biomarker screening.",
            "Incorporate zone-2 aerobic conditioning (150 mins/week) and heart rate variability (HRV) training.",
            "Ergonomic workspace optimization and 20-20-20 visual rest intervals with blue-light filtering."
          ]
        });
      }
    }
    setLoadingAi(false);
    setStatus('results');
  };

  // Calculate Naegele's Rule EDD (LMP + 7 days + 9 months)
  const calculateEDD = () => {
    if (!lmpDate) return { edd: 'N/A', gestationalWeeks: 0 };
    const lmp = new Date(lmpDate);
    const eddt = new Date(lmp.getTime());
    eddt.setDate(eddt.getDate() + 7);
    eddt.setMonth(eddt.getMonth() + 9);
    
    const diffTime = Math.abs(Date.now() - lmp.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diffDays / 7);
    const days = diffDays % 7;
    return {
      edd: eddt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      gestationalWeeks: `${weeks} weeks, ${days} days`
    };
  };

  const eddInfo = calculateEDD();

  const warningText = "Medical Disclaimer: Predictive wellness analytics, not clinical diagnoses. Always verify with approved physical devices and consult licensed medical professionals.";
  
  const reportText = activeTab === 'present' && presentData ? 
    `Present Disease Diagnosis. Biological Age is ${vitals.biologicalAge} years with Longevity Index at ${vitals.longevityScore} percent. Biometric anomalies: ${presentData.biometricAnomalies}. Conditions: ${presentData.presentConditions.map((c:any) => `${c.condition} at ${c.probability} percent: ${c.description}`).join('. ')}. Actionable steps: ${presentData.actionableSteps.join('. ')}. Warning: ${warningText}` :
    activeTab === 'future' && futureData ?
    `Future Disease Forecasting & Vulnerability Windows. Biological Age: ${vitals.biologicalAge}. Longevity Index: ${vitals.longevityScore} percent. Future risk windows: ${futureData.futureRisks.map((r:any) => `${r.risk} at ${r.percentage} percent within ${r.window}: ${r.description}`).join('. ')}. Preventive protocols: ${futureData.preventiveProtocols.join('. ')}. Warning: ${warningText}` :
    `Family Wellness and EDD Tracker. Estimated Due Date is ${eddInfo.edd}. Gestational age: ${eddInfo.gestationalWeeks}. Biological Longevity Index: ${vitals.longevityScore} percent. Warning: ${warningText}`;

  return (
    <div className="space-y-6 pb-24">
      {/* Tri-Diagnostic Suite Tabs */}
      <div className="flex bg-black p-1.5 rounded-2xl border border-cyan-500/40 shadow-md">
        <button
          onClick={() => { setActiveTab('present'); setStatus('idle'); }}
          className={`flex-1 py-3 px-3 rounded-xl font-mono text-[11px] sm:text-xs font-bold transition-all ${activeTab === 'present' ? 'bg-cyan-600 text-white shadow-[0_0_15px_rgba(6,182,212,0.5)]' : 'text-slate-400 hover:text-cyan-300'}`}
        >
          Present Diagnosis (वर्तमान)
        </button>
        <button
          onClick={() => { setActiveTab('future'); setStatus('idle'); }}
          className={`flex-1 py-3 px-3 rounded-xl font-mono text-[11px] sm:text-xs font-bold transition-all ${activeTab === 'future' ? 'bg-cyan-600 text-white shadow-[0_0_15px_rgba(6,182,212,0.5)]' : 'text-slate-400 hover:text-cyan-300'}`}
        >
          Future Risk Windows (भविष्य)
        </button>
        <button
          onClick={() => { setActiveTab('family'); setStatus('idle'); }}
          className={`flex-1 py-3 px-3 rounded-xl font-mono text-[11px] sm:text-xs font-bold transition-all ${activeTab === 'family' ? 'bg-cyan-600 text-white shadow-[0_0_15px_rgba(6,182,212,0.5)]' : 'text-slate-400 hover:text-cyan-300'}`}
        >
          Family Wellness & EDD (परिवार)
        </button>
      </div>

      {status === 'idle' && (
        <div className="space-y-4 p-6 bg-[#0a0a0a] rounded-3xl border border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.15)] font-mono">
          <h2 className="text-xl font-bold text-cyan-300">
            {activeTab === 'present' ? 'Present Disease Diagnostic Suite' : activeTab === 'future' ? 'Future Disease & Vulnerability Suite' : 'Family Wellness & EDD Tracker'}
          </h2>
          <p className="text-slate-400 text-xs">
            {activeTab === 'present' 
              ? 'Input your current symptoms and activate real-time camera sensors for differential present disease diagnosis.'
              : activeTab === 'future'
              ? 'Process biometric trendlines and longevity indices for long-term chronic vulnerability windows.'
              : 'Input Last Menstrual Period (LMP) and scan biometric wellness for clinical Estimated Due Date (EDD) family planning.'}
          </p>

          {activeTab === 'present' && (
            <div className="space-y-3">
              <label className="text-xs text-cyan-400">Active Symptoms (Text or Voice)</label>
              <textarea
                value={symptoms}
                onChange={e => setSymptoms(e.target.value)}
                placeholder="e.g., Mild headache, fatigue, dizziness, elevated resting pulse..."
                className="w-full p-3 bg-black rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                rows={3}
              />
            </div>
          )}

          {activeTab === 'family' && (
            <div className="space-y-3">
              <label className="text-xs text-cyan-400">Last Menstrual Period (LMP) Date</label>
              <input
                type="date"
                value={lmpDate}
                onChange={e => setLmpDate(e.target.value)}
                className="w-full p-3 bg-black rounded-xl border border-slate-800 text-cyan-100 text-sm"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-cyan-400">Age</label>
              <input type="number" value={age} onChange={e => setAge(e.target.value)} className="w-full p-3 bg-black rounded-xl border border-slate-800 text-cyan-100 text-sm" />
            </div>
            <div>
              <label className="text-xs text-cyan-400">Profession / Activity</label>
              <input type="text" value={profession} onChange={e => setProfession(e.target.value)} className="w-full p-3 bg-black rounded-xl border border-slate-800 text-cyan-100 text-sm" />
            </div>
          </div>

          <button
            onClick={startScanProcess}
            className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(6,182,212,0.4)] flex items-center justify-center gap-2 tracking-wide"
          >
            <Camera className="w-5 h-5" /> Trigger Biometric Scan & Run {activeTab === 'present' ? 'Present Diagnosis' : activeTab === 'future' ? 'Future Risk Windows' : 'Family Wellness Scan'}
          </button>
        </div>
      )}

      {status === 'permission' && (
        <div className="p-6 bg-[#0a0a0a] rounded-2xl border border-amber-500/50 space-y-4 text-center font-mono">
          <Camera className="w-12 h-12 text-amber-400 mx-auto animate-bounce" />
          <h3 className="text-xl font-bold text-amber-300">Camera & Flashlight Access Required</h3>
          <p className="text-sm text-slate-300">FuturePulse AI requires 30fps rear-camera PPG and front-camera ocular access for authentic biometric scanning.</p>
          <button onClick={confirmHardwareAccess} className="w-full py-3 bg-amber-600 hover:bg-amber-500 rounded-lg font-bold text-white shadow-[0_0_15px_rgba(245,158,11,0.4)]">Allow Hardware Access</button>
          <button onClick={() => setStatus('idle')} className="w-full py-3 bg-slate-900 rounded-lg text-slate-400">Cancel</button>
        </div>
      )}

      {status === 'scanning' && (
        <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50 p-6 text-center font-mono">
          <div className="relative w-48 h-48 flex items-center justify-center">
            <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover rounded-full opacity-40 border-4 border-red-500" autoPlay playsInline muted />
            <canvas ref={canvasRef} className="hidden" />
            <motion.div animate={{scale: [1, 1.25, 1]}} transition={{repeat: Infinity, duration: 0.8}} className="absolute inset-0 rounded-full border-4 border-red-500 shadow-[0_0_40px_rgba(239,68,68,0.7)]" />
          </div>
          <p className="mt-8 text-lg font-bold tracking-wider text-cyan-300">
            {loadingAi ? 'Synthesizing AI Medical Intelligence...' : 'Capturing 30fps PPG Pixel Density & Ocular Microvascular Scan...'}
          </p>
          <p className="text-xs text-slate-400 mt-2">Place fingertip over rear camera lens & flashlight</p>
          <div className="w-64 h-2 bg-slate-900 rounded-full mt-4 overflow-hidden border border-slate-700">
            <div className="h-full bg-cyan-500" style={{width: `${progress}%`}} />
          </div>
          <span className="text-xs text-cyan-400 mt-2">{progress}% COMPLETE</span>
        </div>
      )}

      {status === 'results' && (
        <div className="space-y-6 font-mono">
          <div className="flex justify-between items-center bg-black p-4 rounded-2xl border border-cyan-500/40">
            <h2 className="text-xl font-bold text-cyan-400">
              {activeTab === 'present' ? 'Present Disease Differential Diagnosis' : activeTab === 'future' ? 'Future Vulnerability Windows' : 'Family Wellness & EDD Dossier'}
            </h2>
            <button onClick={() => setStatus('idle')} className="text-xs text-slate-400 hover:text-cyan-300 underline">New Scan</button>
          </div>

          {/* AI Longevity Index & Biological Age Banner */}
          <div className="p-5 bg-gradient-to-r from-slate-950 to-black rounded-2xl border-2 border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.3)] grid grid-cols-2 gap-4 text-center">
            <div className="p-3 bg-black/60 rounded-xl border border-cyan-500/30">
              <p className="text-[10px] text-slate-400">BIOLOGICAL AGE</p>
              <p className="text-3xl font-extrabold text-cyan-300 mt-1">{vitals.biologicalAge} <span className="text-xs font-normal text-slate-400">Yrs</span></p>
            </div>
            <div className="p-3 bg-black/60 rounded-xl border border-cyan-500/30">
              <p className="text-[10px] text-slate-400">LONGEVITY VITALITY INDEX</p>
              <p className="text-3xl font-extrabold text-green-300 mt-1">{vitals.longevityScore}%</p>
            </div>
          </div>

          {/* Vitals Summary */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 bg-black rounded-xl border border-cyan-500/30 text-center">
              <p className="text-[10px] text-slate-400">PULSE RATE</p>
              <p className="text-xl font-bold text-cyan-300">{vitals.bpm} <span className="text-xs">BPM</span></p>
            </div>
            <div className="p-3 bg-black rounded-xl border border-cyan-500/30 text-center">
              <p className="text-[10px] text-slate-400">SPO2 OXYGEN</p>
              <p className="text-xl font-bold text-green-300">{vitals.spo2}%</p>
            </div>
            <div className="p-3 bg-black rounded-xl border border-cyan-500/30 text-center">
              <p className="text-[10px] text-slate-400">BLOOD PRESSURE</p>
              <p className="text-lg font-bold text-amber-300">{vitals.bp}</p>
            </div>
          </div>

          {activeTab === 'present' && presentData && (
            <>
              {/* Biometric Anomalies Description */}
              <div className="p-5 bg-[#0a0a0a] rounded-2xl border border-amber-500/40 space-y-2">
                <h4 className="text-xs text-amber-400 uppercase tracking-wide">Observed Biometric Anomalies</h4>
                <p className="text-sm text-slate-200">{presentData.biometricAnomalies}</p>
              </div>

              {/* Differential Diagnosis (3+ Conditions) */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-cyan-300">Differential Diagnosis (Potential Present Conditions)</h4>
                {presentData.presentConditions?.map((c: any, i: number) => (
                  <div key={i} className="p-5 bg-[#0a0a0a] rounded-2xl border border-cyan-500/30 space-y-2 shadow-[0_0_10px_rgba(6,182,212,0.1)]">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-cyan-200">{i+1}. {c.condition}</span>
                      <span className="text-xs text-red-400">Probability: {c.probability}%</span>
                    </div>
                    <div className="h-1.5 bg-black rounded-full overflow-hidden border border-slate-800">
                      <motion.div className="h-full bg-red-500" initial={{width: 0}} animate={{width: `${c.probability}%`}} transition={{duration: 1}} />
                    </div>
                    <p className="text-xs text-slate-300">{c.description}</p>
                  </div>
                ))}
              </div>

              {/* Actionable Treatment Options / Next Steps (3+ Steps) */}
              <div className="p-5 bg-[#0a0a0a] rounded-2xl border border-cyan-500/30 space-y-3">
                <h4 className="text-sm font-bold text-cyan-300">Actionable Treatment Options & Next Steps</h4>
                <div className="space-y-2 border-l-2 border-cyan-500 pl-4">
                  {presentData.actionableSteps?.map((step: string, i: number) => (
                    <p key={i} className="text-xs text-slate-200">Option {i+1}: {step}</p>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === 'future' && futureData && (
            <>
              {/* Advanced Vulnerability Windows (3+ Risks with Green-to-Red Progress Bars) */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-cyan-300">Advanced Risk & Vulnerability Windows</h4>
                {futureData.futureRisks?.map((r: any, i: number) => {
                  const barColor = r.percentage > 60 ? 'bg-red-500' : r.percentage > 35 ? 'bg-amber-500' : 'bg-green-500';
                  return (
                    <div key={i} className="p-5 bg-[#0a0a0a] rounded-2xl border border-cyan-500/30 space-y-2 shadow-[0_0_10px_rgba(6,182,212,0.1)]">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-cyan-200">{i+1}. {r.risk}</span>
                        <span className="text-xs text-amber-300">Window: {r.window} ({r.percentage}%)</span>
                      </div>
                      <div className="h-1.5 bg-black rounded-full overflow-hidden border border-slate-800">
                        <motion.div className={`h-full ${barColor}`} initial={{width: 0}} animate={{width: `${r.percentage}%`}} transition={{duration: 1}} />
                      </div>
                      <p className="text-xs text-slate-300">{r.description}</p>
                    </div>
                  );
                })}
              </div>

              {/* Preventive Action Steps for Recovery (3+ Protocols) */}
              <div className="p-5 bg-[#0a0a0a] rounded-2xl border border-cyan-500/30 space-y-3">
                <h4 className="text-sm font-bold text-cyan-300">Preventive Action Steps for Recovery</h4>
                <div className="space-y-2 border-l-2 border-green-500 pl-4">
                  {futureData.preventiveProtocols?.map((proto: string, i: number) => (
                    <p key={i} className="text-xs text-slate-200">Action Step {i+1}: {proto}</p>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeTab === 'family' && (
            <>
              {/* Family Wellness & EDD Tracker */}
              <div className="p-6 bg-[#0a0a0a] rounded-3xl border-2 border-fuchsia-500/40 space-y-4 shadow-[0_0_20px_rgba(217,70,239,0.2)]">
                <h4 className="text-base font-bold text-fuchsia-300">Clinical Estimated Due Date (EDD) Calculation</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-black rounded-2xl border border-slate-800 text-center">
                    <p className="text-[10px] text-slate-400">ESTIMATED DUE DATE (EDD)</p>
                    <p className="text-xl font-bold text-fuchsia-400 mt-1">{eddInfo.edd}</p>
                  </div>
                  <div className="p-4 bg-black rounded-2xl border border-slate-800 text-center">
                    <p className="text-[10px] text-slate-400">GESTATIONAL AGE</p>
                    <p className="text-xl font-bold text-cyan-300 mt-1">{eddInfo.gestationalWeeks}</p>
                  </div>
                </div>
                <p className="text-xs text-slate-300">Calculated via Naegele's Rule (LMP + 7 days + 9 calendar months) combined with real-time biometric wellness markers.</p>
              </div>

              <div className="p-5 bg-[#0a0a0a] rounded-2xl border border-cyan-500/30 space-y-3">
                <h4 className="text-sm font-bold text-cyan-300">Prenatal & Family Wellness Protocols</h4>
                <div className="space-y-2 border-l-2 border-fuchsia-500 pl-4 text-xs text-slate-200">
                  <p>1. Target maternal hydration of 3.8L daily and baseline folate/iron supplementation.</p>
                  <p>2. Bi-weekly fetal heartbeat monitoring and obstetrician clinical check-ins.</p>
                  <p>3. Structured low-impact prenatal yoga and pelvic floor conditioning.</p>
                </div>
              </div>
            </>
          )}

          {/* Strict Medical Disclaimer & Warning */}
          <div className="p-4 bg-amber-950/30 rounded-2xl border border-amber-500/50 text-xs text-amber-200 leading-relaxed">
            ⚠️ <strong>Legal & Medical Disclaimer:</strong> {warningText}
          </div>

          <button onClick={() => toggleSpeak(reportText)} className={`w-full py-3 rounded-lg font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)] ${isSpeaking ? 'bg-red-600' : 'bg-cyan-600 hover:bg-cyan-500'}`}>
            {isSpeaking ? 'Stop Listening' : 'Listen to Report / आवाज में सुनें'}
          </button>

          <button onClick={() => onShare(reportText, 'Dual-Diagnostic Medical Dossier')} className="w-full py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold text-white shadow-[0_0_15px_rgba(217,70,239,0.5)] flex items-center justify-center gap-2">
            <Share2 className="w-4 h-4" /> Export Report (PDF/Share)
          </button>
        </div>
      )}
    </div>
  );
}

function CareerPrediction({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{path: string, healthRiskMatrix: string[], roadmap: string[], skillLongevityIndex: number, aiDisruptionRisk: number}>({path: '', healthRiskMatrix: [], roadmap: [], skillLongevityIndex: 0, aiDisruptionRisk: 0});
  const [isSpeaking, setIsSpeaking] = useState(false);

  const toggleSpeak = (text: string) => {
    if (isSpeaking) { window.speechSynthesis.cancel(); setIsSpeaking(false); }
    else { const utterance = new SpeechSynthesisUtterance(text); utterance.onend = () => setIsSpeaking(false); window.speechSynthesis.speak(utterance); setIsSpeaking(true); }
  };

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const form = e.target as HTMLFormElement;
    const res = await fetch('/api/career-prediction', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        age: (form.querySelector('input[name="age"]') as HTMLInputElement).value,
        weight: (form.querySelector('input[name="weight"]') as HTMLInputElement).value,
        education: (form.querySelector('select') as HTMLSelectElement).value,
        skills: (form.querySelector('input[name="skills"]') as HTMLInputElement).value
      })
    });
    const data = await res.json();
    setResults(data);
    setLoading(false);
    setMode('results');
    saveHistory('Career Projection', `Path: ${data.path}. Skill Longevity: ${data.skillLongevityIndex}%. AI Disruption Risk: ${data.aiDisruptionRisk}%.`);
  };

  const careerText = `Professional forecast path is ${results.path}. Skill longevity index is ${results.skillLongevityIndex} percent. AI disruption risk is ${results.aiDisruptionRisk} percent. Strategic roadmap: ${results.roadmap.join(', ')}`;

  if (mode === 'results') return (
    <div className="space-y-6 pb-24">
      <h2 className="text-2xl font-bold text-cyan-400 font-mono">Comprehensive Life Dossier</h2>
      <div className="p-6 bg-[#0a0a0a] rounded-2xl border border-cyan-500/50 space-y-4 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
        <h4 className="text-slate-400 text-sm">Professional Forecast</h4><p className="font-bold text-cyan-100">{results.path}</p>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1"><span>Skill Longevity Index</span><span className="text-green-400">{results.skillLongevityIndex}%</span></div>
            <div className="h-2 bg-black rounded-full overflow-hidden border border-slate-800"><motion.div className="h-full bg-green-500" initial={{width: 0}} animate={{width: `${results.skillLongevityIndex}%`}} transition={{duration: 1}} /></div>
          </div>
          <div>
            <div className="flex justify-between text-sm mb-1"><span>AI Disruption Risk</span><span className="text-red-400">{results.aiDisruptionRisk}%</span></div>
            <div className="h-2 bg-black rounded-full overflow-hidden border border-slate-800"><motion.div className="h-full bg-red-500" initial={{width: 0}} animate={{width: `${results.aiDisruptionRisk}%`}} transition={{duration: 1}} /></div>
          </div>
        </div>
        <h4 className="text-slate-400 text-sm">Strategic Roadmap</h4>
        <div className="border-l-2 border-cyan-500 pl-4 space-y-2">{results.roadmap.map((r, i) => <p key={i} className="text-sm text-slate-300">Phase {i+1}: {r}</p>)}</div>
      </div>
      <button onClick={() => toggleSpeak(careerText)} className={`w-full py-3 rounded-lg font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)] ${isSpeaking ? 'bg-red-600' : 'bg-cyan-600 hover:bg-cyan-500'}`}>
        {isSpeaking ? 'Stop Listening' : 'Listen to Future Forecast / आवाज में सुनें'}
      </button>
      <button onClick={() => onShare(careerText, 'Career Projection Dossier')} className="w-full py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold text-white shadow-[0_0_15px_rgba(217,70,239,0.5)] flex items-center justify-center gap-2">
        <Share2 className="w-4 h-4" /> Export Report (PDF/Share)
      </button>
      <button onClick={() => setMode('form')} className="w-full py-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-300">New Forecast</button>
      <p className="text-[10px] text-slate-600 mt-4">Disclaimer: Predictive trends. Consult experts.</p>
    </div>
  );

  return (
    <form className="space-y-4 p-6 bg-[#0a0a0a] rounded-2xl border border-cyan-500 pb-24" onSubmit={handlePredict}>
      <h2 className="text-xl font-bold text-cyan-400 font-mono mb-2">Career Profile Input</h2>
      <input type="number" name="age" placeholder="Age" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100" required />
      <input type="number" name="weight" placeholder="Weight (kg)" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100" required />
      <select name="education" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100"><option>School</option><option>College</option><option>Graduate</option></select>
      <input type="text" name="skills" placeholder="Skills (comma separated)" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100" required />
      <button type="submit" className="w-full py-3 bg-cyan-600 rounded-lg font-bold text-white hover:bg-cyan-500">{loading ? 'Processing Super-AI...' : 'Generate Career Dossier'}</button>
    </form>
  );
}

function GlobalHealthIntelligence({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [data, setData] = useState<any>(null);
  const [countryInput, setCountryInput] = useState('Global');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [loading, setLoading] = useState(false);

  const toggleSpeak = (text: string) => {
    if (isSpeaking) { window.speechSynthesis.cancel(); setIsSpeaking(false); }
    else { const utterance = new SpeechSynthesisUtterance(text); utterance.onend = () => setIsSpeaking(false); window.speechSynthesis.speak(utterance); setIsSpeaking(true); }
  };

  const fetchMacro = async () => {
    setLoading(true);
    const res = await fetch('/api/macro-forecast', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({country: countryInput})
    });
    const json = await res.json();
    setData(json);
    setLoading(false);
    saveHistory('Macro Geopolitical Intelligence', `Region: ${countryInput}. Policy Impact Score: ${json.policyImpactScore}/100. Trend: ${json.economicTrend}`);
  };

  const macroText = data ? `Macro Geopolitical Intelligence for ${countryInput}. Policy Impact Score is ${data.policyImpactScore} out of 100. Economic trend: ${data.economicTrend}. GDP growth rate is ${data.liveFeed?.gdpGrowthRate} percent. Geopolitical risk index is ${data.liveFeed?.geopoliticalRiskIndex}.` : '';

  return (
    <div className="space-y-6 pb-24">
      <div className="p-6 bg-black rounded-3xl border border-cyan-500/40 shadow-lg space-y-4 font-mono">
        <h2 className="text-2xl font-bold text-cyan-400">Macro Geopolitical Intelligence</h2>
        <p className="text-xs text-slate-400">Process live WHO health outbreak feeds, macroeconomic indicators, and regional sentiment APIs for authentic nation-grade forecasting.</p>
        <input
          type="text"
          value={countryInput}
          onChange={e => setCountryInput(e.target.value)}
          placeholder="Enter Country or Region (e.g., India, USA, Global)"
          className="w-full p-3 bg-[#0a0a0a] rounded-xl border border-slate-800 text-cyan-100 text-sm"
        />
        <button onClick={fetchMacro} className="w-full py-3 bg-gradient-to-r from-cyan-600 to-blue-600 rounded-xl font-bold text-white hover:from-cyan-500 hover:to-blue-500 shadow-[0_0_15px_rgba(6,182,212,0.4)]">
          {loading ? 'Fetching Live Feeds & Processing AI...' : 'Fetch Live Macro Feeds & Simulate Forecast'}
        </button>
      </div>

      {data && (
        <div className="p-6 bg-slate-950 rounded-2xl border-2 border-magenta-500/50 shadow-[0_0_20px_rgba(236,72,153,0.3)] space-y-6 font-mono">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <h4 className="font-bold text-magenta-400">Policy Impact Score: {data.policyImpactScore}/100</h4>
            <span className="text-[10px] text-cyan-400">LIVE FEED TIMESTAMP: {data.liveFeed?.timestamp?.substring(11, 19)}</span>
          </div>

          {/* Live Data Feed Matrix Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-black rounded-xl border border-slate-800">
              <p className="text-[10px] text-slate-400">GDP GROWTH</p>
              <p className="text-lg font-bold text-cyan-300">{data.liveFeed?.gdpGrowthRate}%</p>
            </div>
            <div className="p-3 bg-black rounded-xl border border-slate-800">
              <p className="text-[10px] text-slate-400">INFLATION INDEX</p>
              <p className="text-lg font-bold text-amber-300">{data.liveFeed?.inflationIndex}%</p>
            </div>
            <div className="p-3 bg-black rounded-xl border border-slate-800">
              <p className="text-[10px] text-slate-400">MARKET VIX</p>
              <p className="text-lg font-bold text-red-400">{data.liveFeed?.marketVolatilityVIX}</p>
            </div>
            <div className="p-3 bg-black rounded-xl border border-slate-800 col-span-2 sm:col-span-3">
              <p className="text-[10px] text-slate-400">WHO OUTBREAK SURVEILLANCE VECTOR</p>
              <p className="text-xs font-bold text-green-300 mt-1">{data.liveFeed?.whoOutbreakVector}</p>
            </div>
          </div>

          <div className="space-y-3">
            <p className="text-xs text-slate-300 font-bold uppercase">Electoral Sentiment Mapping</p>
            {Object.entries(data.electoralSentiment).map(([party, score]: any) => (
              <div key={party}>
                <div className="flex justify-between text-xs mb-1"><span>{party}</span><span className="text-cyan-400">{score.toFixed(1)}%</span></div>
                <div className="h-2 bg-black rounded-full overflow-hidden border border-slate-800">
                  <motion.div className="h-full bg-cyan-500" initial={{width: 0}} animate={{width: `${score}%`}} transition={{duration: 1}} />
                </div>
              </div>
            ))}
          </div>

          <p className="text-sm text-cyan-100 bg-black/40 p-4 rounded-xl border border-cyan-500/30">{data.economicTrend}</p>

          <button onClick={() => toggleSpeak(macroText)} className={`w-full py-3 rounded-lg font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)] ${isSpeaking ? 'bg-red-600' : 'bg-cyan-600 hover:bg-cyan-500'}`}>
            {isSpeaking ? 'Stop Listening' : 'Listen to Macro Forecast / आवाज में सुनें'}
          </button>
          <button onClick={() => onShare(macroText, 'Macro Geopolitical Report')} className="w-full py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold text-white shadow-[0_0_15px_rgba(217,70,239,0.5)] flex items-center justify-center gap-2">
            <Share2 className="w-4 h-4" /> Export Report (PDF/Share)
          </button>
          <p className="text-[10px] text-slate-500 mt-4">Disclaimer: Analysis for authentic trend awareness only. Not actionable political advice.</p>
        </div>
      )}
    </div>
  );
}

function OrgForecasting({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const form = e.target as HTMLFormElement;
    const orgType = (form.querySelector('input[name="orgType"]') as HTMLInputElement)?.value || (form.querySelector('select[name="type"]') as HTMLSelectElement)?.value;
    const ticker = (form.querySelector('input[name="ticker"]') as HTMLInputElement)?.value;
    const objectives = (form.querySelector('input[name="obj"]') as HTMLInputElement)?.value;

    const res = await fetch('/api/org-forecast', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        orgType,
        ticker,
        region: (form.querySelector('select[name="region"]') as HTMLSelectElement)?.value || 'Global',
        objectives
      })
    });
    const data = await res.json();
    setResults(data);
    setLoading(false);
    setMode('results');
    saveHistory('Enterprise Disruptive Roadmap', `Org: ${orgType} (${ticker || 'N/A'}). Disruption Risk: ${data.disruptionRisk}%. Trajectory: ${data.trajectory}`);
  };

  const toggleSpeak = (text: string) => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setIsSpeaking(true);
    }
  };

  const resultsText = results ? `Enterprise Disruption Risk for ${results.liveMarket?.identifier} is ${results.disruptionRisk} percent. Market cap: ${results.liveMarket?.marketCapUsd}. Trajectory assessment: ${results.trajectory}. Roadmap: ${results.pivotRoadmap.join(', ')}.` : '';

  if (mode === 'results' && results) return (
    <div className="space-y-6 pb-24 font-mono">
      <div className="flex justify-between items-center bg-black p-4 rounded-2xl border border-cyan-500/45">
        <h2 className="text-xl font-bold text-cyan-400">Institutional Dossier ({results.liveMarket?.identifier})</h2>
        <button onClick={() => setMode('form')} className="text-xs text-slate-400 hover:text-cyan-300 underline">New Query</button>
      </div>

      {/* Live Market Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-black rounded-xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400">MARKET CAP</p>
          <p className="text-lg font-bold text-cyan-300">{results.liveMarket?.marketCapUsd}</p>
        </div>
        <div className="p-3 bg-black rounded-xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400">VOLATILITY BETA</p>
          <p className="text-lg font-bold text-amber-300">{results.liveMarket?.volatilityBeta}</p>
        </div>
        <div className="p-3 bg-black rounded-xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400">DISRUPTION INDEX</p>
          <p className="text-lg font-bold text-red-400">{results.liveMarket?.industryDisruptionIndex}%</p>
        </div>
        <div className="p-3 bg-black rounded-xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400">LIQUIDITY RATIO</p>
          <p className="text-lg font-bold text-green-300">{results.liveMarket?.liquidityRatio}</p>
        </div>
      </div>

      <div className="p-6 bg-slate-950 rounded-2xl border-2 border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.3)] space-y-4">
        <h4 className="text-cyan-200 text-sm font-bold">Disruption Risk Analysis</h4>
        <div className="h-4 bg-black rounded-full overflow-hidden border border-slate-800">
          <motion.div className="h-full bg-red-500" initial={{width: 0}} animate={{width: `${results.disruptionRisk}%`}} transition={{duration: 1}} />
        </div>
        <h4 className="text-cyan-200 text-sm font-bold">Trajectory Assessment</h4>
        <p className="text-sm text-cyan-100 bg-black/40 p-3 rounded-xl border border-cyan-500/20">{results.trajectory}</p>
        <h4 className="text-cyan-200 text-sm font-bold">Strategic Pivot Roadmap (Tesla/SpaceX Level)</h4>
        <div className="border-l-2 border-magenta-500 pl-4 space-y-2">
          {results.pivotRoadmap.map((r: string, i: number) => (
            <p key={i} className="text-xs text-cyan-100">Action {i+1}: {r}</p>
          ))}
        </div>
      </div>

      <button onClick={() => toggleSpeak(resultsText)} className={`w-full py-3 rounded-lg font-bold shadow-[0_0_15px_rgba(6,182,212,0.4)] ${isSpeaking ? 'bg-red-600' : 'bg-cyan-600 hover:bg-cyan-500'}`}>
        {isSpeaking ? 'Stop Listening' : 'Listen to Institutional Forecast / आवाज में सुनें'}
      </button>
      <button onClick={() => onShare(resultsText, 'Enterprise Disruptive Dossier')} className="w-full py-3 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg font-bold text-white shadow-[0_0_15px_rgba(217,70,239,0.5)] flex items-center justify-center gap-2">
        <Share2 className="w-4 h-4" /> Export Report (PDF/Share)
      </button>
      <p className="text-[10px] text-slate-600 mt-4">Disclaimer: Authentic market-connected predictive trends. Consult organizational experts.</p>
    </div>
  );

  return (
    <form className="space-y-4 p-6 bg-[#0a0a0a] rounded-2xl border border-cyan-500 pb-24 font-mono" onSubmit={handleSubmit}>
      <h2 className="text-xl font-bold text-cyan-400 mb-2">Enterprise Disruptive Intelligence</h2>
      <p className="text-xs text-slate-400 mb-4">Input corporation or startup parameters with live financial market connectors to generate high-fidelity disruption risk and pivot roadmaps.</p>
      
      <div>
        <label className="text-xs text-cyan-400 block mb-1">Company / Startup Name</label>
        <input type="text" name="orgType" placeholder="e.g., Tesla, SpaceX, OpenAI, Neuralink" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100 text-sm" required />
      </div>

      <div>
        <label className="text-xs text-cyan-400 block mb-1">Stock Ticker (Optional)</label>
        <input type="text" name="ticker" placeholder="e.g., TSLA, AAPL, PRIVATE" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100 text-sm" />
      </div>

      <div>
        <label className="text-xs text-cyan-400 block mb-1">Market Scope</label>
        <select name="region" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100 text-sm">
          <option>Global</option>
          <option>North America</option>
          <option>Asia Pacific</option>
          <option>European Union</option>
        </select>
      </div>

      <div>
        <label className="text-xs text-cyan-400 block mb-1">Strategic Objectives / Disruptor Targets</label>
        <input type="text" name="obj" placeholder="e.g., Autonomous fleet scaling, neural interface commercialization" className="w-full p-3 bg-black rounded-lg border border-slate-800 text-cyan-100 text-sm" required />
      </div>

      <button type="submit" className="w-full py-4 bg-cyan-600 rounded-lg font-bold text-white hover:bg-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.4)]">
        {loading ? 'Connecting Live Market Feeds...' : 'Execute Live Market Intelligence & Pivot Roadmap'}
      </button>
    </form>
  );
}
