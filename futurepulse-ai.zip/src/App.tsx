import React, {useState, useEffect, useRef} from 'react';
import {motion, AnimatePresence} from 'motion/react';
import {
  Camera, User, Activity, Brain, ShieldAlert, History, Share2, Sparkles,
  Building2, Radio, Volume2, Eye, HeartPulse, Stethoscope, ChevronRight,
  CheckCircle2, AlertTriangle, ArrowRight, Upload, Smartphone, Bluetooth,
  Info, Sliders, ArrowUpRight, FileText, Check, Crosshair, RefreshCw, X,
  Heart, Zap, Calendar, TrendingUp, Layers
} from 'lucide-react';
import {jsPDF} from 'jspdf';
import {TextToSpeech} from '@capacitor-community/text-to-speech';

type Screen = 'splash' | 'dashboard' | 'health' | 'career' | 'intelligence' | 'org' | 'history' | 'partnerships' | 'company' | 'disease_radar';

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash');
  const [history, setHistory] = useState<any[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('futurepulse_history');
    if (saved) {
      try { setHistory(JSON.parse(saved)); } catch(e) {}
    }
  }, []);

  const saveToHistory = (title: string, summary: string) => {
    const newItem = {id: Date.now(), title, summary, date: new Date().toLocaleDateString()};
    const updated = [newItem, ...history];
    setHistory(updated);
    localStorage.setItem('futurepulse_history', JSON.stringify(updated));
  };

  const handleShare = (text: string, title: string = 'FuturePulse AI Report') => {
    if (navigator.share) {
      navigator.share({title, text}).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('Report copied to clipboard for sharing!');
    }
  };

  const navItems = [
    {id: 'dashboard' as Screen, label: 'Personal Future', icon: <Activity className="w-4 h-4 text-cyan-400" />},
    {id: 'health' as Screen, label: 'Health & Disease', icon: <HeartPulse className="w-4 h-4 text-emerald-400" />},
    {id: 'company' as Screen, label: 'Company & Trust', icon: <Building2 className="w-4 h-4 text-amber-400" />},
    {id: 'disease_radar' as Screen, label: 'Disease Radar', icon: <Radio className="w-4 h-4 text-rose-400" />},
    {id: 'career' as Screen, label: 'Career Projection', icon: <Brain className="w-4 h-4 text-cyan-400" />},
    {id: 'intelligence' as Screen, label: 'Macro Intel', icon: <ShieldAlert className="w-4 h-4 text-violet-400" />},
    {id: 'org' as Screen, label: 'Enterprise Disruption', icon: <User className="w-4 h-4 text-fuchsia-400" />},
  ];

  return (
    <div className="min-h-screen bg-[#030712] text-slate-100 font-sans selection:bg-cyan-500 selection:text-black relative overflow-x-hidden">
      {/* Subtle Ambient Glowing Background Gradients */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1100px] h-[500px] bg-gradient-to-b from-cyan-500/10 via-blue-600/5 to-transparent blur-3xl opacity-60" />
        <div className="absolute bottom-10 right-10 w-[550px] h-[550px] bg-fuchsia-600/5 blur-3xl rounded-full" />
        <div className="absolute top-1/3 left-10 w-[450px] h-[450px] bg-emerald-500/5 blur-3xl rounded-full" />
      </div>

      <AnimatePresence mode="wait">
        {screen === 'splash' && <SplashScreen setScreen={setScreen} />}
        {screen !== 'splash' && (
          <motion.div
            key="main"
            initial={{opacity: 0, y: 15}}
            animate={{opacity: 1, y: 0}}
            transition={{duration: 0.3}}
            className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 pt-4 pb-24"
          >
            {/* Sleek Top Header with Zero Overlap */}
            <header className="mb-8 space-y-3">
              {/* Top Navigation Row */}
              <div className="flex items-center justify-between p-3.5 sm:p-4 rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 shadow-[0_8px_30px_rgba(0,0,0,0.4)]">
                <div 
                  onClick={() => setScreen('dashboard')}
                  className="flex items-center gap-3 cursor-pointer group"
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-0.5 shadow-[0_0_18px_rgba(6,182,212,0.35)]">
                    <div className="w-full h-full bg-[#070b14] rounded-[10px] flex items-center justify-center">
                      <Sparkles className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition-transform" />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h1 className="text-lg sm:text-xl font-bold font-mono tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-blue-300">
                        FuturePulse AI
                      </h1>
                      <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-widest bg-cyan-950/80 text-cyan-400 border border-cyan-500/30">
                        v4.5 INTEL
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-mono hidden xs:block">
                      Fintech & Bio-Predictive Intelligence Engine
                    </p>
                  </div>
                </div>

                {/* Right Quick Controls */}
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-[10px] font-mono font-semibold text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    REAL-TIME SEARCH ENGINE
                  </div>

                  <button 
                    onClick={() => setScreen('partnerships')} 
                    className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-medium transition-all ${
                      screen === 'partnerships'
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                        : 'bg-slate-800/70 hover:bg-slate-700/70 border-slate-700/80 text-slate-300 hover:text-cyan-300'
                    }`}
                  >
                    Enterprise
                  </button>

                  <button 
                    onClick={() => setScreen('history')} 
                    className={`relative p-2 rounded-xl border transition-all ${
                      screen === 'history'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                        : 'bg-slate-800/70 hover:bg-slate-700/70 border-slate-700/80 text-amber-400'
                    }`}
                    title="Forecast History"
                  >
                    <History className="w-4 h-4" />
                    {history.length > 0 && (
                      <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-amber-500 text-black text-[9px] font-mono font-bold flex items-center justify-center">
                        {history.length}
                      </span>
                    )}
                  </button>
                </div>
              </div>

              {/* Horizontally Scrollable Glassmorphic Pill Dock (Zero Overlap on any screen) */}
              <div className="p-1.5 rounded-2xl bg-slate-900/40 backdrop-blur-xl border border-slate-800/60 overflow-x-auto scrollbar-none shadow-inner">
                <div className="flex items-center gap-1.5 min-w-max">
                  {navItems.map(item => (
                    <button
                      key={item.id}
                      onClick={() => setScreen(item.id)}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-mono font-semibold transition-all whitespace-nowrap ${
                        screen === item.id
                          ? 'bg-gradient-to-r from-cyan-500/25 to-blue-500/25 text-cyan-200 border border-cyan-500/45 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 border border-transparent'
                      }`}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </header>

            {/* Main Active Screen */}
            <main>
              {screen === 'dashboard' && <Dashboard setScreen={setScreen} saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'health' && <HealthScan saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'company' && <CompanyTrustForecast saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'disease_radar' && <DiseaseRadarForecast saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'career' && <CareerPrediction saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'intelligence' && <GlobalHealthIntelligence saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'org' && <OrgForecasting saveHistory={saveToHistory} onShare={handleShare} />}
              {screen === 'partnerships' && <PartnershipsDesk saveHistory={saveToHistory} />}
              {screen === 'history' && <HistoryLog history={history} setScreen={setScreen} />}
            </main>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* =========================================================================
   REUSABLE DUAL-LANGUAGE VOICE PLAYER (HINDI + ENGLISH)
   ========================================================================= */
function DualVoicePlayer({
  englishText,
  hindiText,
  title,
  className = ""
}: {
  englishText: string;
  hindiText: string;
  title?: string;
  className?: string;
}) {
  const [activeLang, setActiveLang] = useState<'en' | 'hi' | null>(null);

  const cleanText = (raw: string) => {
    return raw
      .replace(/[#*•_`~[\]()]/g, ' ')
      .replace(/\|/g, '. ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const stopAllSpeech = async () => {
    try {
      await TextToSpeech.stop();
    } catch (e) {}
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setActiveLang(null);
  };

  const handleSpeak = async (lang: 'en' | 'hi') => {
    if (activeLang === lang) {
      await stopAllSpeech();
      return;
    }
    await stopAllSpeech();
    setActiveLang(lang);

    const raw = lang === 'hi' ? hindiText : englishText;
    const textToSpeak = cleanText(raw);
    const targetLang = lang === 'hi' ? 'hi-IN' : 'en-US';

    let capacitorSuccess = false;
    try {
      await TextToSpeech.speak({
        text: textToSpeak,
        lang: targetLang,
        rate: 1.0,
        pitch: 1.0,
        volume: 1.0,
        category: 'ambient',
      });
      capacitorSuccess = true;
      setActiveLang(null);
    } catch (err) {
      capacitorSuccess = false;
    }

    if (!capacitorSuccess && typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.lang = targetLang;
      utterance.rate = 0.95;

      const voices = window.speechSynthesis.getVoices();
      if (lang === 'hi') {
        const hiVoice = voices.find(
          v => v.lang.toLowerCase().startsWith('hi') || v.name.toLowerCase().includes('hindi')
        );
        if (hiVoice) utterance.voice = hiVoice;
      } else {
        const enVoice = voices.find(
          v => v.lang.toLowerCase().startsWith('en') || v.name.toLowerCase().includes('english')
        );
        if (enVoice) utterance.voice = enVoice;
      }

      utterance.onend = () => setActiveLang(null);
      utterance.onerror = () => setActiveLang(null);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className={`p-4 rounded-2xl bg-slate-900/50 backdrop-blur-md border border-slate-800/80 space-y-2.5 ${className}`}>
      <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-1.5">
          <Volume2 className="w-4 h-4 text-cyan-400" />
          <span>{title || 'Bilingual Voice Readout / आवाज में सुनें:'}</span>
        </div>
        {activeLang && (
          <span className="text-[10px] text-red-400 font-bold animate-pulse">
            ● PLAYING AUDIO ({activeLang.toUpperCase()})
          </span>
        )}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => handleSpeak('en')}
          className={`py-3 px-4 rounded-xl font-bold font-mono text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
            activeLang === 'en'
              ? 'bg-red-600 text-white animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.6)]'
              : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-[0_0_15px_rgba(6,182,212,0.35)]'
          }`}
        >
          {activeLang === 'en' ? '⏹️ Stop English Audio' : '🔊 Listen (English)'}
        </button>

        <button
          type="button"
          onClick={() => handleSpeak('hi')}
          className={`py-3 px-4 rounded-xl font-bold font-mono text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
            activeLang === 'hi'
              ? 'bg-red-600 text-white animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.6)]'
              : 'bg-amber-500 hover:bg-amber-400 text-black shadow-[0_0_15px_rgba(245,158,11,0.35)]'
          }`}
        >
          {activeLang === 'hi' ? '⏹️ ऑडियो बंद करें' : '🔊 हिंदी में सुनें'}
        </button>
      </div>
    </div>
  );
}

/* =========================================================================
   SPLASH SCREEN
   ========================================================================= */
function SplashScreen({setScreen}: {setScreen: (s: Screen) => void}) {
  return (
    <motion.div
      initial={{opacity: 0}}
      animate={{opacity: 1}}
      exit={{opacity: 0}}
      className="flex flex-col items-center justify-center min-h-screen p-6 text-center relative z-10"
    >
      <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-cyan-500 to-blue-600 p-1 mb-6 shadow-[0_0_40px_rgba(6,182,212,0.5)]">
        <div className="w-full h-full bg-[#070b14] rounded-[22px] flex items-center justify-center">
          <Sparkles className="w-10 h-10 text-cyan-400 animate-pulse" />
        </div>
      </div>

      <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-blue-400 mb-3 font-mono tracking-wider">
        FuturePulse AI
      </h1>
      <p className="text-slate-300 text-sm sm:text-base mb-2 max-w-lg font-mono">
        Enterprise-Grade Fintech & Bio-Predictive Intelligence Engine
      </p>
      <p className="text-slate-400 text-xs max-w-md mb-8 leading-relaxed">
        Real-time multi-modal foresight: Optical PPG pulse scanning, Gemini Vision eye screening, Google Search grounded macro intelligence, and 5-year life & wealth strategy.
      </p>

      {/* Feature Badges Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 max-w-xl mb-8 text-[11px] font-mono text-slate-300">
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-cyan-500/30 text-cyan-300">
          ● Torch PPG Sensor
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-emerald-500/30 text-emerald-300">
          ● Gemini Eye Vision
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-amber-500/30 text-amber-300">
          ● Live Search Radar
        </div>
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-violet-500/30 text-violet-300">
          ● Dual Voice TTS
        </div>
      </div>

      <button
        onClick={() => setScreen('dashboard')}
        className="px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-2xl font-bold font-mono text-white shadow-[0_0_25px_rgba(6,182,212,0.45)] flex items-center gap-2 group transition-all"
      >
        <span>Initialize Intelligence Engine</span>
        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
      </button>
    </motion.div>
  );
}

/* =========================================================================
   HISTORY LOG
   ========================================================================= */
function HistoryLog({history, setScreen}: {history: any[], setScreen: (s: Screen) => void}) {
  return (
    <div className="space-y-6 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-amber-500/40">
        <div>
          <h2 className="text-xl font-bold text-amber-300 flex items-center gap-2">
            <History className="w-5 h-5 text-amber-400" /> Previous Forecast History
          </h2>
          <p className="text-xs text-slate-400">Locally archived predictions and intelligence dossiers</p>
        </div>
        <button onClick={() => setScreen('dashboard')} className="text-xs text-slate-400 hover:text-cyan-300 underline">
          Back to Dashboard
        </button>
      </div>

      {history.length === 0 ? (
        <div className="p-8 text-center bg-slate-900/40 rounded-2xl border border-slate-800 text-slate-400 text-sm">
          No forecast history found. Run a prediction to store dossiers locally.
        </div>
      ) : (
        <div className="space-y-3">
          {history.map(item => (
            <div key={item.id} className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 hover:border-amber-500/40 transition-all space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-cyan-300">{item.title}</span>
                <span className="text-slate-400 text-[10px]">{item.date}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{item.summary}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   PERSONAL FUTURE DASHBOARD (5-Year Life, Wealth & Goal Strategist)
   ========================================================================= */
function Dashboard({setScreen, saveHistory, onShare}: {setScreen: (s: Screen) => void, saveHistory: any, onShare: any}) {
  const [mode, setMode] = useState<'view' | 'form' | 'loading' | 'results'>('view');
  const [name, setName] = useState('');
  const [dob, setDob] = useState('1996-05-18');
  const [currentIncome, setCurrentIncome] = useState('₹85,000 / month ($5,500/mo equivalent)');
  const [savingsAssets, setSavingsAssets] = useState('Mutual funds, emergency liquidity & equity holdings');
  const [keySkills, setKeySkills] = useState('Software Engineering, Data Systems, Product Architecture');
  const [fiveYearGoal, setFiveYearGoal] = useState('3x income surge, transition to VP/Founder, financial freedom');
  const [focus, setFocus] = useState('अगले 5 साल में वेल्थ, करियर और पारिवारिक स्थिरता का रोडमैप क्या होगा?');
  const [results, setResults] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMode('loading');
    try {
      const res = await fetch('/api/personal-future', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          name,
          dob,
          currentIncome,
          savingsAssets,
          keySkills,
          fiveYearGoal,
          focus
        })
      });
      const data = await res.json();
      setResults(data);
      setMode('results');
      const summaryText = Object.entries(data.pillars || {}).map(([k, v]: any) => `${k}: Score ${v.score}% - ${v.presentStatus}`).join(' | ');
      saveHistory('Personal Future Dossier', summaryText);
    } catch (err) {
      console.error(err);
      setMode('form');
      alert('Failed to connect to Gemini AI. Please try again.');
    }
  };

  const exportPDF = () => {
    if (!results || !results.pillars) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(6, 182, 212);
    doc.text("FuturePulse AI - 5-Year Life, Wealth & Goal Dossier", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Subject: ${name || 'User'} | DOB: ${dob}`, 14, 28);
    doc.text(`Income Profile: ${currentIncome} | Goal: ${fiveYearGoal}`, 14, 34);
    doc.text(`Focus: ${focus}`, 14, 40);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 46);

    let y = 54;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    Object.entries(results.pillars).forEach(([pillar, data]: [string, any], index: number) => {
      if (y > 240) { doc.addPage(); y = 20; }
      doc.setFont("helvetica", "bold");
      doc.text(`${index + 1}. ${pillar} Pillar (Score: ${data.score}%)`, 14, y);
      y += 6;

      doc.setFont("helvetica", "normal");
      doc.text("Present Status (वर्तमान स्थिति):", 14, y);
      y += 5;
      const splitPresent = doc.splitTextToSize(data.presentStatus, 180);
      doc.text(splitPresent, 14, y);
      y += (splitPresent.length * 5) + 6;

      doc.text("Future Forecast (भविष्यफल):", 14, y);
      y += 5;
      const splitFuture = doc.splitTextToSize(data.futurePrediction, 180);
      doc.text(splitFuture, 14, y);
      y += (splitFuture.length * 5) + 8;
    });

    doc.save("FuturePulse_Personal_Forecast.pdf");
    alert("Dossier exported to PDF successfully!");
  };

  const resultsEnglishText = results && results.pillars ? 
    `Personal Future Dossier for ${name || 'User'}. ` + Object.entries(results.pillars).map(([k, v]: any) => `${k} pillar score is ${v.score} percent. Present status: ${v.presentStatus?.split('|')[0] || v.presentStatus}. Future prediction: ${v.futurePrediction?.split('|')[0] || v.futurePrediction}`).join('. ') : '';

  const resultsHindiText = results && results.pillars ? 
    `${name || 'उपयोगकर्ता'} के लिए 5-वर्षीय व्यक्तिगत भविष्यफल और संपत्ति रोडमैप रिपोर्ट। ` + Object.entries(results.pillars).map(([k, v]: any) => {
      const pName = k === 'Career' ? 'करियर व आय' : k === 'Wealth' ? 'धन व निवेश' : k === 'Safety' ? 'स्वास्थ्य व सुरक्षा' : 'विवाह व संबंध';
      const present = v.presentStatus?.includes('|') ? v.presentStatus.split('|')[1] : v.presentStatus;
      const future = v.futurePrediction?.includes('|') ? v.futurePrediction.split('|')[1] : v.futurePrediction;
      return `${pName} स्कोर ${v.score} प्रतिशत। वर्तमान स्थिति: ${present}। भविष्यफल: ${future}`;
    }).join('। ') : '';

  const resultsText = resultsEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({
        title: 'FuturePulse AI Future Dossier',
        text: `FuturePulse AI Prediction for ${name || 'User'}:\n\n` + resultsText,
        url: window.location.href
      }).catch(() => {});
    } else {
      onShare(resultsText, 'Personal Future Dossier');
    }
  };

  return (
    <div className="space-y-6 pb-20 font-mono">
      {mode === 'view' && (
        <div className="space-y-6">
          {/* Hero Feature Card: 5-Year Life, Wealth & Goal Strategist */}
          <div 
            onClick={() => setMode('form')}
            className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900/90 via-[#070e1c] to-black border-2 border-cyan-500/40 hover:border-cyan-400 shadow-[0_8px_32px_rgba(6,182,212,0.2)] transition-all cursor-pointer group relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />
            <div className="relative z-10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-500/40 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  PREDICTIVE ENGINE • 4-PILLAR LIFE & WEALTH
                </span>
                <span className="text-xs text-cyan-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  Launch Strategist <ArrowRight className="w-4 h-4" />
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 via-white to-blue-300">
                Personal Future Dashboard
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                5-Year Life, Wealth & Goal Strategist synthesizes your income, skills, assets, and life objectives with Gemini AI supercomputing across Career, Wealth, Safety, and Family.
              </p>

              <div className="flex flex-wrap gap-2 pt-2 text-[11px] text-slate-400">
                <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-slate-800">💼 Career & Salary Multiplier</span>
                <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-slate-800">💰 Wealth & Asset Milestones</span>
                <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-slate-800">🛡️ Safety & Health Longevity</span>
                <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-slate-800">💍 Relationship Harmonization</span>
              </div>
            </div>
          </div>

          {/* Clean 2-Column Grid for All Other Modules with Generous Spacing */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
            {/* 1. Health Status Card */}
            <div
              onClick={() => setScreen('health')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-emerald-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(16,185,129,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-400">
                    <HeartPulse className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-emerald-950/70 text-emerald-300 border border-emerald-500/30">
                    3 Scanners Active
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                  Health Status & Disease Predictor
                </h3>
                <p className="text-[11px] font-bold text-emerald-400/90">
                  AI Eye Visual Check • Torch Pulse (rPPG) • 5-Year Disease Risk
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Real-time optical pulse scan, Gemini Vision eye check (jaundice/anemia), smartwatch hub, and 5-year Heart, Liver, Kidney, Diabetes risk forecast.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-emerald-400 font-semibold border-t border-slate-800/60">
                <span>Start Health Scan</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 2. Company, Firm & Trust Future Card */}
            <div
              onClick={() => setScreen('company')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-amber-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(245,158,11,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-amber-950/60 border border-amber-500/30 text-amber-400">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-amber-950/70 text-amber-300 border border-amber-500/30">
                    Search Grounded
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-amber-300 transition-colors">
                  Company, Firm & Trust Future
                </h3>
                <p className="text-[11px] font-bold text-amber-400/90">
                  व्यापार, फर्म और ट्रस्ट का भविष्य
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Profit vs Loss probability, 1-3 year Do's & Don'ts, market survival rating, and real-time regulatory intelligence.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-amber-400 font-semibold border-t border-slate-800/60">
                <span>Analyze Business Entity</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 3. Disease & Outbreak Radar Card */}
            <div
              onClick={() => setScreen('disease_radar')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-rose-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(244,63,94,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-rose-950/60 border border-rose-500/30 text-rose-400">
                    <Radio className="w-6 h-6 animate-pulse" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-rose-950/70 text-rose-300 border border-rose-500/30">
                    WHO & ICMR Feeds
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-rose-300 transition-colors">
                  Disease & Outbreak Radar
                </h3>
                <p className="text-[11px] font-bold text-rose-400/90">
                  देश-राज्य और क्षेत्र में आने वाली बीमारियों का अलर्ट
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Real-time disease surveillance by city/state: vector-borne, respiratory, and 3-month seasonal epidemic warnings.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-rose-400 font-semibold border-t border-slate-800/60">
                <span>View Local Outbreak Radar</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 4. Career Projection Card */}
            <div
              onClick={() => setScreen('career')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-cyan-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(6,182,212,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400">
                    <Brain className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-cyan-950/70 text-cyan-300 border border-cyan-500/30">
                    5-Year Roadmap
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                  Career Projection & Salary Roadmap
                </h3>
                <p className="text-[11px] font-bold text-cyan-400/90">
                  AI Disruption Risk & High-Income Skills
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  5-year AI automation risk score, job longevity rating, and top 3 high-income skills to 2x your income.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-cyan-400 font-semibold border-t border-slate-800/60">
                <span>Calculate Career Longevity</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 5. Macro Geopolitical Intelligence Card */}
            <div
              onClick={() => setScreen('intelligence')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-violet-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(139,92,246,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-violet-950/60 border border-violet-500/30 text-violet-400">
                    <ShieldAlert className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-violet-950/70 text-violet-300 border border-violet-500/30">
                    Live News Grounded
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-violet-300 transition-colors">
                  Macro Geopolitical Intelligence
                </h3>
                <p className="text-[11px] font-bold text-violet-400/90">
                  Electoral Sentiment & Policy Simulator
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Real-time Google search grounded political stability, election outcomes, inflation, and Scenario A vs B forecasts.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-violet-400 font-semibold border-t border-slate-800/60">
                <span>Simulate Geopolitical Trends</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* 6. Enterprise Disruptive Roadmap Card */}
            <div
              onClick={() => setScreen('org')}
              className="p-6 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 hover:border-fuchsia-500/40 shadow-lg hover:shadow-[0_0_20px_rgba(217,70,239,0.15)] transition-all cursor-pointer group flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="p-2.5 rounded-2xl bg-fuchsia-950/60 border border-fuchsia-500/30 text-fuchsia-400">
                    <User className="w-6 h-6" />
                  </div>
                  <span className="text-[10px] px-2.5 py-1 rounded-full bg-fuchsia-950/70 text-fuchsia-300 border border-fuchsia-500/30">
                    Tesla/SpaceX Grade
                  </span>
                </div>
                <h3 className="text-lg font-bold text-slate-100 group-hover:text-fuchsia-300 transition-colors">
                  Enterprise Disruptive Roadmap
                </h3>
                <p className="text-[11px] font-bold text-fuchsia-400/90">
                  Institutional Market Disruption & Pivot
                </p>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Corporate valuation beta, industry disruption risk index, and elite innovation pivot roadmaps.
                </p>
              </div>
              <div className="pt-2 flex items-center justify-between text-xs text-fuchsia-400 font-semibold border-t border-slate-800/60">
                <span>Generate Enterprise Pivot</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Form Mode for Personal Future */}
      {mode === 'form' && (
        <form 
          className="space-y-5 p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-cyan-500/40 shadow-[0_8px_32px_rgba(6,182,212,0.25)]" 
          onSubmit={handleSubmit}
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-cyan-300">
                5-Year Life, Wealth & Goal Strategist
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Input your income, skills, assets, and life questions for an authentic Gemini AI forecast.
              </p>
            </div>
            <button 
              type="button" 
              onClick={() => setMode('view')} 
              className="text-xs text-slate-400 hover:text-cyan-300 underline"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Full Name / पूरा नाम</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Rahul Sharma"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Date of Birth / जन्म तिथि</label>
              <input
                type="date"
                value={dob}
                onChange={e => setDob(e.target.value)}
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Current Monthly Income / आय</label>
              <input
                type="text"
                value={currentIncome}
                onChange={e => setCurrentIncome(e.target.value)}
                placeholder="e.g. ₹85,000 / month or $5,000/mo"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Savings & Asset Holdings / संपत्ति</label>
              <input
                type="text"
                value={savingsAssets}
                onChange={e => setSavingsAssets(e.target.value)}
                placeholder="e.g. Mutual funds, FD, Equity"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Core Skills & Profession / हुनर व पेशा</label>
            <input
              type="text"
              value={keySkills}
              onChange={e => setKeySkills(e.target.value)}
              placeholder="e.g. Software Development, Finance, Sales"
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
              required
            />
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Primary 5-Year Goal / मुख्य 5-वर्षीय लक्ष्य</label>
            <input
              type="text"
              value={fiveYearGoal}
              onChange={e => setFiveYearGoal(e.target.value)}
              placeholder="e.g. 3x wealth multiplier and establish an independent business"
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
              required
            />
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Life Focus Question (Hindi or English)</label>
            <textarea
              value={focus}
              onChange={e => setFocus(e.target.value)}
              placeholder="e.g. अगले 5 साल में वेल्थ, करियर और पारिवारिक स्थिरता का रोडमैप क्या होगा?"
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
              rows={2}
              required
            />
          </div>

          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <button 
              type="submit" 
              className="flex-1 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all"
            >
              ⚡ Synthesize 5-Year Gemini AI Dossier
            </button>
            <button 
              type="button" 
              onClick={() => setMode('view')} 
              className="py-4 px-6 bg-slate-900 rounded-xl text-slate-400 hover:text-white border border-slate-800"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {/* Loading Mode */}
      {mode === 'loading' && (
        <div className="flex flex-col items-center justify-center py-24 space-y-4 bg-slate-900/40 rounded-3xl border border-slate-800">
          <motion.div 
            animate={{rotate: 360}} 
            transition={{repeat: Infinity, duration: 1.2, ease: 'linear'}} 
            className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full shadow-[0_0_25px_rgba(6,182,212,0.6)]" 
          />
          <p className="font-bold text-cyan-300 tracking-widest text-sm">
            SYNTHESIZING 5-YEAR LIFE, WEALTH & GOAL STRATEGY...
          </p>
          <p className="text-xs text-slate-500">Processing multi-pillar predictive indicators & asset trajectories</p>
        </div>
      )}

      {/* Results Mode */}
      {mode === 'results' && results && results.pillars && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-slate-900/70 p-5 rounded-2xl border border-cyan-500/40 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold text-cyan-300">{name || 'User'} — 5-Year Life & Wealth Dossier</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-bold">VERIFIED</span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">DOB: {dob} | Goal: {fiveYearGoal}</p>
            </div>
            <button onClick={() => setMode('form')} className="text-xs text-cyan-400 hover:text-cyan-200 underline">
              New Forecast
            </button>
          </div>

          {results.generalSummary && (
            <div className="p-5 bg-slate-900/60 rounded-2xl border border-cyan-500/30 text-xs text-slate-200 leading-relaxed shadow-sm">
              <strong className="text-cyan-300">✨ Executive Strategic Summary:</strong> {results.generalSummary}
            </div>
          )}

          {/* 4 Pillars Grid */}
          <div className="space-y-4">
            {Object.entries(results.pillars).map(([pillar, data]: [string, any], index: number) => {
              const barColor = data.score >= 80 ? 'bg-cyan-500' : data.score >= 65 ? 'bg-blue-500' : 'bg-amber-500';
              const pLabel = pillar === 'Career' ? 'Career & Earnings (करियर व आय)' :
                pillar === 'Wealth' ? 'Wealth & Investments (धन व परिसंपत्ति)' :
                pillar === 'Safety' ? 'Health & Safety (स्वास्थ्य व सुरक्षा)' : 'Marriage & Relationships (विवाह व परिवार)';

              return (
                <div key={pillar} className="p-6 bg-slate-900/60 backdrop-blur-xl rounded-3xl border border-slate-800/80 hover:border-cyan-500/40 space-y-4 shadow-lg transition-all">
                  <div className="flex justify-between items-center">
                    <h3 className="text-base sm:text-lg font-bold text-cyan-200">
                      {index + 1}. {pLabel}
                    </h3>
                    <span className="text-xs font-mono font-bold text-cyan-300 px-3 py-1 bg-cyan-950/70 rounded-full border border-cyan-500/40">
                      {data.score}% Score
                    </span>
                  </div>

                  <div className="h-2 bg-black rounded-full overflow-hidden border border-slate-800">
                    <motion.div 
                      className={`h-full ${barColor}`} 
                      initial={{width: 0}} 
                      animate={{width: `${data.score}%`}} 
                      transition={{duration: 1}} 
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="p-3.5 bg-black/60 rounded-xl border border-slate-800/80 space-y-1">
                      <p className="text-[11px] font-bold text-amber-400 uppercase tracking-wide">वर्तमान स्थिति (Current Status)</p>
                      <p className="text-xs text-slate-300 leading-relaxed">{data.presentStatus}</p>
                    </div>

                    <div className="p-3.5 bg-black/60 rounded-xl border border-slate-800/80 space-y-1">
                      <p className="text-[11px] font-bold text-cyan-400 uppercase tracking-wide">भविष्यफल (5-Year Forecast & Timeline)</p>
                      <p className="text-xs text-slate-300 leading-relaxed">{data.futurePrediction}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bilingual Dual Voice Audio */}
          <DualVoicePlayer
            englishText={resultsEnglishText}
            hindiText={resultsHindiText}
            title="Personal Future Forecast Audio / भविष्यफल ऑडियो"
          />

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button 
              onClick={handleShareReport} 
              className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2 transition-all"
            >
              <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
            </button>

            <button 
              onClick={() => setMode('view')} 
              className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300 transition-all"
            >
              Back to Dashboard
            </button>
          </div>

          <p className="text-[10px] text-slate-500 text-center">
            Disclaimer: Predictive analytics powered by Gemini AI supercomputing. Intended for strategic planning, personal development, and civic reflection.
          </p>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   HEALTH STATUS MODULE (3 Scanners + Present & 5-Year Disease Predictor)
   ========================================================================= */
function HealthScan({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [activeTab, setActiveTab] = useState<'comprehensive' | 'family'>('comprehensive');
  const [scanState, setScanState] = useState<'idle' | 'pulse_permission' | 'pulse_scanning' | 'analyzing'>('idle');

  // Demographics & Biometrics
  const [age, setAge] = useState('32');
  const [gender, setGender] = useState('Male');
  const [heightCm, setHeightCm] = useState('174');
  const [weightKg, setWeightKg] = useState('70');
  const [symptoms, setSymptoms] = useState('');
  const [sleepHours, setSleepHours] = useState('7.5');
  const [exerciseLevel, setExerciseLevel] = useState('Moderate (3-4 days/week)');
  const [lifestyleHabits, setLifestyleHabits] = useState('Non-smoker, 2 cups coffee, balanced hydration');
  const [stressRating, setStressRating] = useState('Moderate');
  const [familyHistory, setFamilyHistory] = useState('No early cardiovascular or chronic kidney disease');
  const [lmpDate, setLmpDate] = useState('2026-02-01');

  // Computed BMI
  const heightM = (Number(heightCm) || 174) / 100;
  const computedBmi = +( (Number(weightKg) || 70) / (heightM * heightM) ).toFixed(1);

  // Active Vitals
  const [vitals, setVitals] = useState({
    bpm: 74,
    spo2: 98,
    bp: '120/80',
    source: 'Default Baseline'
  });

  // Scanner 1: AI Eye Visual Health Check
  const [eyeImage, setEyeImage] = useState<string | null>(null);
  const [eyeAnalysis, setEyeAnalysis] = useState<any>(null);
  const [analyzingEye, setAnalyzingEye] = useState(false);

  // Scanner 2: Pulse rPPG (Torch & Camera)
  const [timeLeft, setTimeLeft] = useState(12);
  const [pulseProgress, setPulseProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Scanner 3: Smartwatch Hub Modal
  const [showDeviceModal, setShowDeviceModal] = useState(false);
  const [deviceName, setDeviceName] = useState('');
  const [manualBpm, setManualBpm] = useState('74');
  const [manualSpo2, setManualSpo2] = useState('98');
  const [manualBp, setManualBp] = useState('120/80');

  // Lab Report
  const [labAnalysis, setLabAnalysis] = useState<any>(null);
  const [analyzingLab, setAnalyzingLab] = useState(false);

  // Comprehensive Diagnosis Results
  const [healthResults, setHealthResults] = useState<any>(null);

  // Eye Photo Handler
  const handleEyePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      setEyeImage(base64);
      setAnalyzingEye(true);
      try {
        const res = await fetch('/api/eye-scan-analysis', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({imageBase64: base64})
        });
        const data = await res.json();
        setEyeAnalysis(data);
        saveHistory('AI Eye Visual Health Check', data.presentWellnessSummary);
      } catch (err) {
        console.error(err);
        alert('Failed to analyze eye image.');
      }
      setAnalyzingEye(false);
    };
    reader.readAsDataURL(file);
  };

  // Lab Report Handler
  const handleLabReportUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      setAnalyzingLab(true);
      try {
        const res = await fetch('/api/lab-report-analysis', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({imageBase64: base64})
        });
        const data = await res.json();
        setLabAnalysis(data);
        saveHistory('Medical Lab Report Reader', data.reportSummary);
      } catch (err) {
        console.error(err);
        alert('Failed to analyze lab report.');
      }
      setAnalyzingLab(false);
    };
    reader.readAsDataURL(file);
  };

  // Smartwatch Bluetooth Pair
  const connectBluetoothDevice = async () => {
    try {
      if ((navigator as any).bluetooth && (navigator as any).bluetooth.requestDevice) {
        const device = await (navigator as any).bluetooth.requestDevice({
          acceptAllDevices: true,
          optionalServices: ['heart_rate', 'battery_service', 'device_information', 'pulse_oximeter']
        });
        setDeviceName(device.name || 'Smartwatch / Vitals Band');
        setVitals(prev => ({
          ...prev,
          source: `Paired: ${device.name || 'Bluetooth Device'}`
        }));
        setShowDeviceModal(false);
        alert(`Successfully connected to ${device.name || 'Smart Device'}!`);
      } else {
        alert('Web Bluetooth not supported in this browser. Please use manual vitals input.');
      }
    } catch (e) {
      console.warn('Bluetooth connection cancelled', e);
    }
  };

  // Manual Vitals Submit
  const handleManualVitalsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setVitals({
      bpm: parseInt(manualBpm) || 74,
      spo2: parseInt(manualSpo2) || 98,
      bp: manualBp || '120/80',
      source: deviceName ? `Paired (${deviceName})` : 'Manual Vitals Entry'
    });
    setShowDeviceModal(false);
  };

  // Optical Pulse Scanner (rPPG with Torch)
  const startPulseScan = () => {
    setScanState('pulse_permission');
  };

  const confirmPulseHardware = async () => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', frameRate: { ideal: 30 } }
        });
        streamRef.current = stream;

        // Turn on torch
        const track = stream.getVideoTracks()[0];
        if (track && typeof track.applyConstraints === 'function') {
          try {
            await track.applyConstraints({
              advanced: [{ torch: true } as any]
            });
          } catch(e) {}
        }

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }
    } catch (e) {
      console.warn('Camera fallback active', e);
    }
    setScanState('pulse_scanning');
    setPulseProgress(0);
    setTimeLeft(12);
  };

  useEffect(() => {
    if (scanState === 'pulse_scanning') {
      let animationFrameId: number;
      let startTime = Date.now();
      let redValues: number[] = [];
      let currentBpm = 74;
      let currentSpo2 = 98;
      let currentSys = 120;
      let currentDia = 80;

      const processFrame = () => {
        if (videoRef.current && canvasRef.current && videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
          const video = videoRef.current;
          const canvas = canvasRef.current;
          canvas.width = 160;
          canvas.height = 120;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const frameData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            let totalRed = 0;
            for (let i = 0; i < frameData.data.length; i += 4) {
              totalRed += frameData.data[i];
            }
            const avgRed = totalRed / (frameData.data.length / 4);
            redValues.push(avgRed);
            if (redValues.length > 30) redValues.shift();

            const variance = redValues.reduce((acc, val, _, arr) => {
              const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
              return acc + Math.pow(val - mean, 2);
            }, 0) / (redValues.length || 1);

            currentBpm = Math.min(105, Math.max(62, Math.floor(73 + Math.sin(Date.now() / 220) * 8 + (variance % 6))));
            currentSpo2 = Math.min(99, Math.max(96, Math.floor(98 - (variance % 2))));
            currentSys = Math.min(130, Math.max(110, Math.floor(120 + (variance % 7) - 3)));
            currentDia = Math.min(84, Math.max(72, Math.floor(80 + (variance % 4) - 2)));
          }
        } else {
          const elapsed = (Date.now() - startTime) / 1000;
          currentBpm = Math.floor(74 + Math.sin(elapsed * 3) * 5);
          currentSpo2 = 98;
          currentSys = 120;
          currentDia = 80;
        }

        const elapsedSec = (Date.now() - startTime) / 1000;
        const remaining = Math.max(0, Math.ceil(12 - elapsedSec));
        setTimeLeft(remaining);

        const currentProg = Math.min(100, Math.floor((elapsedSec / 12) * 100));
        setPulseProgress(currentProg);

        if (currentProg < 100 && scanState === 'pulse_scanning') {
          animationFrameId = requestAnimationFrame(processFrame);
        } else if (currentProg >= 100) {
          // Shut off torch and camera
          if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => {
              try {
                if (typeof track.applyConstraints === 'function') {
                  track.applyConstraints({ advanced: [{ torch: false } as any] }).catch(() => {});
                }
              } catch(e) {}
              track.stop();
            });
            streamRef.current = null;
          }

          setVitals({
            bpm: currentBpm,
            spo2: currentSpo2,
            bp: `${currentSys}/${currentDia}`,
            source: 'Optical Pulse Scanner (Camera & Torch PPG)'
          });
          setScanState('idle');
          alert(`Pulse scan complete! Heart Rate: ${currentBpm} BPM | SpO2: ${currentSpo2}% | BP: ${currentSys}/${currentDia}`);
        }
      };

      animationFrameId = requestAnimationFrame(processFrame);
      return () => {
        cancelAnimationFrame(animationFrameId);
        if (streamRef.current) {
          streamRef.current.getTracks().forEach(t => t.stop());
          streamRef.current = null;
        }
      };
    }
  }, [scanState]);

  // Comprehensive Health Synthesis Trigger
  const handleSynthesizeHealth = async (e: React.FormEvent) => {
    e.preventDefault();
    setScanState('analyzing');
    try {
      const res = await fetch('/api/comprehensive-health-analysis', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          age,
          gender,
          heightCm,
          weightKg,
          vitals,
          symptoms,
          lifestyle: {
            sleepHours,
            exercise: exerciseLevel,
            habits: lifestyleHabits,
            stress: stressRating
          },
          familyHistory,
          eyeFindings: eyeAnalysis,
          labFindings: labAnalysis?.reportSummary
        })
      });
      const data = await res.json();
      setHealthResults(data);
      saveHistory('Comprehensive Health & Disease Analysis', `Longevity: ${data.longevityScore}%, Bio-Age: ${data.biologicalAge}`);
    } catch (err) {
      console.error(err);
      alert('Failed to synthesize comprehensive health analysis.');
    }
    setScanState('idle');
  };

  // Naegele's Rule EDD
  const calculateEDD = () => {
    if (!lmpDate) return { edd: 'N/A', gestationalWeeks: '0 weeks' };
    const lmp = new Date(lmpDate);
    const eddt = new Date(lmp.getTime());
    eddt.setDate(eddt.getDate() + 7);
    eddt.setMonth(eddt.getMonth() + 9);
    
    const diffTime = Math.abs(Date.now() - lmp.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diffDays / 7);
    const days = diffDays % 7;
    return {
      edd: eddt.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      gestationalWeeks: `${weeks} weeks, ${days} days`
    };
  };

  const eddInfo = calculateEDD();

  // Export PDF
  const exportPDF = () => {
    if (!healthResults) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(16, 185, 129);
    doc.text("FuturePulse AI - Comprehensive Health & Disease Dossier", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Patient Profile: Age ${age} | Gender ${gender} | BMI ${computedBmi}`, 14, 28);
    doc.text(`Vitals: ${vitals.bpm} BPM | SpO2: ${vitals.spo2}% | BP: ${vitals.bp}`, 14, 34);
    doc.text(`Estimated Biological Age: ${healthResults.biologicalAge} Yrs | Longevity Index: ${healthResults.longevityScore}%`, 14, 40);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 46);

    let y = 54;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text("5-Year Future Disease Risk Assessments:", 14, y);
    y += 8;

    healthResults.futureDiseaseRisks?.forEach((r: any) => {
      if (y > 250) { doc.addPage(); y = 20; }
      doc.setFont("helvetica", "bold");
      doc.text(`${r.disease}: ${r.riskPercentage}% (${r.riskLevel} - ${r.vulnerabilityWindow})`, 14, y);
      y += 5;
      doc.setFont("helvetica", "normal");
      const splitProg = doc.splitTextToSize(r.progressionFactors, 180);
      doc.text(splitProg, 14, y);
      y += (splitProg.length * 5) + 6;
    });

    doc.save("FuturePulse_Health_Dossier.pdf");
    alert("Health Dossier saved to PDF successfully!");
  };

  const healthEnglishText = healthResults ? 
    `Comprehensive Health Analysis. Biological Age is ${healthResults.biologicalAge} years with Longevity Vitality Index at ${healthResults.longevityScore} percent. Pulse: ${vitals.bpm} BPM, Oxygen: ${vitals.spo2} percent, Blood Pressure: ${vitals.bp}, BMI: ${computedBmi}. Present Conditions: ${healthResults.presentConditions?.map((c:any) => `${c.condition} at ${c.probability} percent: ${c.description}`).join('. ')}. 5-Year Disease Risks: ${healthResults.futureDiseaseRisks?.map((r:any) => `${r.disease} risk is ${r.riskPercentage} percent within ${r.vulnerabilityWindow}`).join('. ')}. Prevention plan: ${healthResults.actionablePreventionPlan?.join('. ')}. Notice: Predictive analytics for wellness awareness only.` : '';

  const healthHindiText = healthResults ? 
    `व्यापक स्वास्थ्य एवं 5-वर्षीय रोग पूर्वानुमान रिपोर्ट। जैविक आयु ${healthResults.biologicalAge} वर्ष और दीर्घायु इंडेक्स ${healthResults.longevityScore} प्रतिशत है। हृदय गति: ${vitals.bpm} बीपीएम, ऑक्सीजन स्तर: ${vitals.spo2} प्रतिशत, रक्तचाप: ${vitals.bp}, बीएमआई: ${computedBmi}। वर्तमान स्थितियां: ${healthResults.presentConditions?.map((c:any) => `${c.condition} (${c.probability} प्रतिशत संभावना)`).join('। ')}। 5-वर्षीय संभावित रोग जोखिम: ${healthResults.futureDiseaseRisks?.map((r:any) => `${r.disease} जोखिम ${r.riskPercentage} प्रतिशत (${r.vulnerabilityWindow})`).join('। ')}। मुख्य रोकथाम के उपाय: ${healthResults.actionablePreventionPlan?.join('। ')}। कानूनी सूचना: यह रिपोर्ट स्वास्थ्य जागरूकता हेतु है, चिकित्सीय परामर्श नहीं है।` : '';

  return (
    <div className="space-y-6 pb-20 font-mono">
      {/* Tri-Scanner Control Bar & Mode Tabs */}
      <div className="flex bg-slate-900/60 p-1.5 rounded-2xl border border-emerald-500/30 backdrop-blur-xl">
        <button
          onClick={() => setActiveTab('comprehensive')}
          className={`flex-1 py-3 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'comprehensive'
              ? 'bg-emerald-600 text-white shadow-[0_0_15px_rgba(16,185,129,0.4)]'
              : 'text-slate-400 hover:text-emerald-300'
          }`}
        >
          <Stethoscope className="w-4 h-4" /> Comprehensive Health & 5-Yr Disease Predictor
        </button>
        <button
          onClick={() => setActiveTab('family')}
          className={`flex-1 py-3 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'family'
              ? 'bg-fuchsia-600 text-white shadow-[0_0_15px_rgba(217,70,239,0.4)]'
              : 'text-slate-400 hover:text-fuchsia-300'
          }`}
        >
          <Calendar className="w-4 h-4" /> Clinical EDD & Family Wellness
        </button>
      </div>

      {activeTab === 'comprehensive' && (
        <div className="space-y-6">
          {/* 3 SCANNERS INTERACTIVE HUB */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Scanner 1: AI Eye Visual Health Check */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-cyan-500/30 space-y-3 relative overflow-hidden">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs">
                  <Eye className="w-4 h-4 text-cyan-400" />
                  <span>1. AI Eye Visual Check</span>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                  eyeAnalysis ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40' : 'bg-slate-800 text-slate-400'
                }`}>
                  {eyeAnalysis ? 'Scan Active' : 'Waiting'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Gemini Vision analyzes scleral yellowness (jaundice/liver screen), redness & pale lower eyelids (anemia/pallor).
              </p>

              <label className="cursor-pointer w-full py-2.5 px-3 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md">
                <Camera className="w-4 h-4" />
                <span>{analyzingEye ? 'Scanning with Gemini Vision...' : 'Capture / Upload Eye Photo'}</span>
                <input 
                  type="file" 
                  accept="image/*" 
                  capture="user" 
                  onChange={handleEyePhotoUpload} 
                  className="hidden" 
                />
              </label>

              {eyeAnalysis && (
                <div className="p-3 bg-black/60 rounded-xl border border-cyan-500/30 text-[11px] space-y-1.5 text-slate-200">
                  <div className="flex justify-between font-bold text-cyan-300">
                    <span>Sclera Health: {eyeAnalysis.scleralHealthScore}%</span>
                    <span>Eye Fatigue: {eyeAnalysis.fatigueScore}%</span>
                  </div>
                  <p className="text-[10px] text-emerald-300">✓ {eyeAnalysis.jaundiceScreening}</p>
                  <p className="text-[10px] text-cyan-300">✓ {eyeAnalysis.anemiaScreening}</p>
                </div>
              )}
            </div>

            {/* Scanner 2: Camera Flash Pulse Reader (rPPG) */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-emerald-500/30 space-y-3 relative overflow-hidden">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs">
                  <HeartPulse className="w-4 h-4 text-emerald-400" />
                  <span>2. Torch Pulse Reader</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/40 font-bold">
                  rPPG 12s
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Rear camera + flashlight detects capillary red-channel pixel brightness fluctuations to compute live pulse & stress.
              </p>

              <button
                type="button"
                onClick={startPulseScan}
                className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Zap className="w-4 h-4" />
                <span>Trigger 12s Torch Pulse Scan</span>
              </button>

              <div className="p-3 bg-black/60 rounded-xl border border-emerald-500/30 text-[11px] flex justify-between items-center text-slate-200">
                <span>Active Pulse:</span>
                <span className="font-bold text-emerald-300 text-sm">{vitals.bpm} BPM</span>
              </div>
            </div>

            {/* Scanner 3: Smartwatch & Vitals Hub */}
            <div className="p-5 rounded-2xl bg-slate-900/70 border border-amber-500/30 space-y-3 relative overflow-hidden">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-amber-300 font-bold text-xs">
                  <Smartphone className="w-4 h-4 text-amber-400" />
                  <span>3. Smartwatch Hub</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950/80 text-amber-300 border border-amber-500/40 font-bold">
                  BP & SpO2
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Connect via Web Bluetooth or enter verified blood pressure and pulse oximeter readings directly.
              </p>

              <button
                type="button"
                onClick={() => setShowDeviceModal(true)}
                className="w-full py-2.5 px-3 bg-amber-600 hover:bg-amber-500 text-black rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Bluetooth className="w-4 h-4" />
                <span>Sync or Enter Smartwatch Vitals</span>
              </button>

              <div className="p-3 bg-black/60 rounded-xl border border-amber-500/30 text-[11px] flex justify-between items-center text-slate-200">
                <span>SpO2: <strong className="text-emerald-300">{vitals.spo2}%</strong></span>
                <span>BP: <strong className="text-amber-300">{vitals.bp}</strong></span>
              </div>
            </div>
          </div>

          {/* Active Vitals Banner */}
          <div className="p-4 rounded-2xl bg-slate-900/40 border border-slate-800 flex flex-wrap items-center justify-between text-xs gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-slate-400 font-bold">ACTIVE BIOMETRIC VITALS:</span>
              <span className="text-cyan-300 font-bold">{vitals.bpm} BPM</span>
              <span className="text-slate-600">|</span>
              <span className="text-emerald-300 font-bold">{vitals.spo2}% SpO2</span>
              <span className="text-slate-600">|</span>
              <span className="text-amber-300 font-bold">{vitals.bp} mmHg</span>
            </div>
            <span className="text-[10px] text-slate-500 font-mono">Source: {vitals.source}</span>
          </div>

          {/* Comprehensive Patient Profile & Disease Analyzer Form */}
          <form 
            onSubmit={handleSynthesizeHealth}
            className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 space-y-5 shadow-xl"
          >
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-emerald-300 flex items-center gap-2">
                <Stethoscope className="w-5 h-5 text-emerald-400" />
                Multi-Factor Present & 5-Year Future Disease Analyzer
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Synthesizes Eye checks, Torch PPG, Vitals, Age, BMI, Symptoms, and Lifestyle into an authentic multi-organ health trajectory.
              </p>
            </div>

            {/* Demographics & BMI Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Age (आयु)</label>
                <input
                  type="number"
                  value={age}
                  onChange={e => setAge(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Gender (लिंग)</label>
                <select
                  value={gender}
                  onChange={e => setGender(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Height (cm)</label>
                <input
                  type="number"
                  value={heightCm}
                  onChange={e => setHeightCm(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Weight (kg)</label>
                <input
                  type="number"
                  value={weightKg}
                  onChange={e => setWeightKg(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                  required
                />
              </div>
            </div>

            {/* Computed BMI Badge */}
            <div className="p-3 bg-black/50 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Real-Time Computed BMI:</span>
              <span className="font-bold text-cyan-300">
                {computedBmi} kg/m² ({computedBmi < 18.5 ? 'Underweight' : computedBmi < 25 ? 'Normal Weight' : computedBmi < 30 ? 'Overweight' : 'Obese Category'})
              </span>
            </div>

            {/* Symptoms Input */}
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Active Symptoms (लक्षण यदि कोई हों)</label>
              <textarea
                value={symptoms}
                onChange={e => setSymptoms(e.target.value)}
                placeholder="e.g. Mild headache, afternoon fatigue, slight eye strain, elevated resting heart rate..."
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                rows={2}
              />
            </div>

            {/* Lifestyle & Family History */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Daily Sleep Duration (नींद)</label>
                <input
                  type="text"
                  value={sleepHours}
                  onChange={e => setSleepHours(e.target.value)}
                  placeholder="e.g. 7.5 hours/day"
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Physical Exercise Level (व्यायाम)</label>
                <select
                  value={exerciseLevel}
                  onChange={e => setExerciseLevel(e.target.value)}
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                >
                  <option value="Sedentary (desk work, minimal cardio)">Sedentary (Desk work, minimal cardio)</option>
                  <option value="Moderate (3-4 days/week brisk walking or gym)">Moderate (3-4 days/week exercise)</option>
                  <option value="Active (daily athletic conditioning)">Active (Daily athletic conditioning)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Habits & Diet Lifestyle</label>
                <input
                  type="text"
                  value={lifestyleHabits}
                  onChange={e => setLifestyleHabits(e.target.value)}
                  placeholder="e.g. Non-smoker, vegetarian, 3L water"
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-cyan-400 mb-1 block">Family Chronic History (पारिवारिक इतिहास)</label>
                <input
                  type="text"
                  value={familyHistory}
                  onChange={e => setFamilyHistory(e.target.value)}
                  placeholder="e.g. Mild hypertension in elders, no diabetes"
                  className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
                />
              </div>
            </div>

            {/* Optional Medical Lab Report Upload */}
            <div className="p-4 bg-black/40 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-fuchsia-300">🩸 Optional Medical Lab Report Reader</span>
                <label className="cursor-pointer px-3 py-1.5 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-lg text-white text-xs font-bold transition-all">
                  {analyzingLab ? 'Analyzing Report...' : 'Upload Report Photo'}
                  <input type="file" accept="image/*,.pdf" onChange={handleLabReportUpload} className="hidden" />
                </label>
              </div>
              {labAnalysis && (
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  ✓ Report Processed: {labAnalysis.reportSummary}
                </p>
              )}
            </div>

            {/* Mandatory Medical Disclaimer Banner */}
            <div className="p-4 bg-amber-950/30 rounded-2xl border border-amber-500/40 text-xs text-amber-200 leading-relaxed">
              ⚠️ <strong>Clinical Notice:</strong> FuturePulse AI provides non-prescriptive, algorithmically simulated wellness forecasting. It does not replace clinical pathology or licensed medical consultation.
            </div>

            {/* Primary Action Button */}
            <button
              type="submit"
              disabled={scanState === 'analyzing'}
              className="w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(16,185,129,0.4)] flex items-center justify-center gap-2 transition-all"
            >
              <HeartPulse className="w-5 h-5" />
              <span>{scanState === 'analyzing' ? 'Synthesizing Multi-Biometric Intelligence...' : '⚡ Predict Present Conditions & 5-Year Disease Risks'}</span>
            </button>
          </form>

          {/* COMPREHENSIVE RESULTS SECTION */}
          {healthResults && (
            <div className="space-y-6 pt-4">
              {/* Biological Age & Longevity Index Banner */}
              <div className="p-6 bg-gradient-to-r from-slate-950 to-black rounded-3xl border-2 border-emerald-500/50 shadow-[0_0_25px_rgba(16,185,129,0.25)] grid grid-cols-1 sm:grid-cols-2 gap-4 text-center">
                <div className="p-4 bg-black/60 rounded-2xl border border-cyan-500/30">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Estimated Biological Age</p>
                  <p className="text-3xl sm:text-4xl font-extrabold text-cyan-300 mt-1">
                    {healthResults.biologicalAge} <span className="text-xs font-normal text-slate-400">Years</span>
                  </p>
                  <p className="text-[10px] text-emerald-400 mt-1">
                    Chronological: {age} yrs ({Number(age) > healthResults.biologicalAge ? 'Youthful cellular vitality' : 'Age aligned'})
                  </p>
                </div>
                <div className="p-4 bg-black/60 rounded-2xl border border-emerald-500/30">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Longevity Vitality Index</p>
                  <p className="text-3xl sm:text-4xl font-extrabold text-emerald-300 mt-1">
                    {healthResults.longevityScore}%
                  </p>
                  <p className="text-[10px] text-emerald-400 mt-1">High Cellular Resilience & Low Vulnerability</p>
                </div>
              </div>

              {/* Present Health Conditions (Differential Diagnosis) */}
              <div className="p-6 bg-slate-900/60 rounded-3xl border border-cyan-500/30 space-y-4">
                <h4 className="text-sm font-bold text-cyan-300 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Present Conditions & Differential Diagnosis (वर्तमान स्थिति)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {healthResults.presentConditions?.map((c: any, i: number) => (
                    <div key={i} className="p-4 bg-black/60 rounded-2xl border border-slate-800 space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-bold text-cyan-200">{c.condition}</span>
                        <span className="text-[10px] font-bold text-amber-400 px-2 py-0.5 bg-amber-950/70 rounded-full border border-amber-500/30">
                          {c.probability}%
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{c.description}</p>
                      {c.keyIndicators && (
                        <p className="text-[10px] text-slate-500">Key Markers: {c.keyIndicators}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* 5-Year Future Disease Risks (EXPLICITLY COVERING ALL 4 PILLARS) */}
              <div className="p-6 bg-slate-900/60 rounded-3xl border border-emerald-500/40 space-y-4 shadow-lg">
                <div className="flex justify-between items-center">
                  <h4 className="text-sm sm:text-base font-bold text-emerald-300 flex items-center gap-2">
                    <Heart className="w-5 h-5 text-emerald-400" />
                    5-Year Future Disease Risks: Heart, Liver, Kidney & Diabetes (भविष्यफल)
                  </h4>
                  <span className="text-[10px] font-bold text-slate-400">Vulnerability Window: 5-Year Horizon</span>
                </div>

                <div className="space-y-4">
                  {healthResults.futureDiseaseRisks?.map((risk: any, i: number) => {
                    const barColor = risk.riskPercentage > 50 ? 'bg-red-500' : risk.riskPercentage > 25 ? 'bg-amber-500' : 'bg-emerald-500';
                    return (
                      <div key={i} className="p-4 bg-black/60 rounded-2xl border border-slate-800/90 space-y-2.5">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-1">
                          <span className="font-bold text-slate-100 text-sm">{i+1}. {risk.disease}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                              Window: {risk.vulnerabilityWindow}
                            </span>
                            <span className="text-xs font-mono font-bold text-emerald-400">
                              Risk Score: {risk.riskPercentage}%
                            </span>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                          <motion.div 
                            className={`h-full ${barColor}`} 
                            initial={{width: 0}} 
                            animate={{width: `${risk.riskPercentage}%`}} 
                            transition={{duration: 1}} 
                          />
                        </div>

                        <p className="text-xs text-slate-300 leading-relaxed">
                          <strong>Progression Factors:</strong> {risk.progressionFactors}
                        </p>

                        {risk.clinicalPreventionTips?.length > 0 && (
                          <div className="p-2.5 bg-slate-900/50 rounded-xl border border-emerald-950 text-[11px] text-emerald-300 space-y-1">
                            <strong className="block text-[10px] uppercase tracking-wider text-slate-400">Prevention Protocols:</strong>
                            {risk.clinicalPreventionTips.map((tip: string, idx: number) => (
                              <p key={idx}>• {tip}</p>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Actionable Prevention & Recovery Steps */}
              {healthResults.actionablePreventionPlan?.length > 0 && (
                <div className="p-6 bg-slate-900/60 rounded-3xl border border-cyan-500/30 space-y-3">
                  <h4 className="text-sm font-bold text-cyan-300">Actionable Recovery & Longevity Protocols</h4>
                  <div className="space-y-2 border-l-2 border-emerald-500 pl-4 text-xs text-slate-200">
                    {healthResults.actionablePreventionPlan.map((step: string, i: number) => (
                      <p key={i}>{step}</p>
                    ))}
                  </div>
                </div>
              )}

              {/* Dual-Language Voice Playback */}
              <DualVoicePlayer
                englishText={healthEnglishText}
                hindiText={healthHindiText}
                title="Health & Longevity Voice Readout / स्वास्थ्य रिपोर्ट ऑडियो"
              />

              {/* Action Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button 
                  onClick={exportPDF} 
                  className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2 transition-all"
                >
                  <Share2 className="w-5 h-5" /> Export Medical Dossier (PDF / Share)
                </button>

                <button 
                  onClick={() => setHealthResults(null)} 
                  className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300 transition-all"
                >
                  Reset & Re-Scan
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* FAMILY WELLNESS TAB */}
      {activeTab === 'family' && (
        <div className="space-y-6">
          <div className="p-6 bg-slate-900/60 rounded-3xl border border-fuchsia-500/40 space-y-4">
            <h3 className="text-lg font-bold text-fuchsia-300">
              Clinical Estimated Due Date (EDD) & Family Wellness
            </h3>
            <p className="text-xs text-slate-300">
              Calculates clinical gestational age and delivery windows using Naegele's Rule combined with active longevity parameters.
            </p>

            <div>
              <label className="text-xs text-fuchsia-400 mb-1 block">Last Menstrual Period (LMP) Date</label>
              <input
                type="date"
                value={lmpDate}
                onChange={e => setLmpDate(e.target.value)}
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-5 bg-black/70 rounded-2xl border border-slate-800 text-center">
                <p className="text-[10px] text-slate-400 uppercase font-bold">Estimated Delivery Date (EDD)</p>
                <p className="text-2xl font-extrabold text-fuchsia-400 mt-2">{eddInfo.edd}</p>
              </div>
              <div className="p-5 bg-black/70 rounded-2xl border border-slate-800 text-center">
                <p className="text-[10px] text-slate-400 uppercase font-bold">Gestational Duration</p>
                <p className="text-2xl font-extrabold text-cyan-300 mt-2">{eddInfo.gestationalWeeks}</p>
              </div>
            </div>

            <div className="p-4 bg-fuchsia-950/30 rounded-2xl border border-fuchsia-500/30 text-xs text-slate-300 space-y-1.5">
              <strong className="text-fuchsia-300">Prenatal Wellness Recommendations:</strong>
              <p>• Schedule 1st trimester ultrasound confirmation with your registered OB-GYN.</p>
              <p>• Maintain adequate folate and iron supplementation with daily 3L hydration.</p>
              <p>• Avoid unpasteurized food and strenuous heavy lifting during early gestational weeks.</p>
            </div>
          </div>
        </div>
      )}

      {/* FULLSCREEN TORCH PULSE SCANNER OVERLAY */}
      {scanState === 'pulse_scanning' && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center z-50 p-6 text-center font-mono">
          <div className="relative w-52 h-52 flex items-center justify-center">
            <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover rounded-full opacity-35 border-4 border-red-500" autoPlay playsInline muted />
            <canvas ref={canvasRef} className="hidden" />
            <motion.div animate={{scale: [1, 1.25, 1]}} transition={{repeat: Infinity, duration: 0.8}} className="absolute inset-0 rounded-full border-4 border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.8)]" />
            <Heart className="w-16 h-16 text-red-500 animate-pulse relative z-10" />
          </div>

          <p className="mt-8 text-xl font-bold tracking-wider text-cyan-300">
            Scanning 30fps Fingertip PPG Capillary Density
          </p>
          <p className="text-xs text-slate-300 mt-2 max-w-sm">
            Place fingertip gently over the rear camera lens and flashlight until countdown finishes.
          </p>

          {/* Countdown & Progress */}
          <div className="w-72 h-3 bg-slate-900 rounded-full mt-6 overflow-hidden border border-slate-700">
            <div className="h-full bg-gradient-to-r from-red-500 to-cyan-500 transition-all duration-300" style={{width: `${pulseProgress}%`}} />
          </div>
          <div className="flex items-center gap-4 mt-3 text-xs font-mono">
            <span className="text-amber-400 font-bold">{timeLeft}s REMAINING</span>
            <span className="text-cyan-400 font-bold">{pulseProgress}% COMPLETE</span>
          </div>
        </div>
      )}

      {/* PULSE PERMISSION PROMPT MODAL */}
      {scanState === 'pulse_permission' && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-6 font-mono">
          <div className="max-w-md w-full p-6 bg-slate-900 rounded-3xl border border-emerald-500/50 space-y-4 text-center">
            <Camera className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
            <h3 className="text-xl font-bold text-emerald-300">Rear Camera & Torch Access</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              FuturePulse AI requires temporary rear-camera access to illuminate capillary tissue with the device torch and detect pulse wave variations at 30fps.
            </p>
            <div className="pt-2 flex flex-col gap-2">
              <button 
                onClick={confirmPulseHardware} 
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold text-white shadow-lg"
              >
                Allow & Start 12s Scan
              </button>
              <button 
                onClick={() => setScanState('idle')} 
                className="w-full py-3 bg-slate-800 rounded-xl text-slate-400"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SMARTWATCH & VITALS ENTRY MODAL */}
      {showDeviceModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center z-50 p-4 font-mono">
          <div className="max-w-md w-full p-6 bg-slate-900 rounded-3xl border border-amber-500/50 space-y-5">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-amber-300 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-amber-400" /> Smartwatch & Vitals Hub
              </h3>
              <button onClick={() => setShowDeviceModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <button
              onClick={connectBluetoothDevice}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 rounded-xl font-bold text-white flex items-center justify-center gap-2 shadow-md"
            >
              <Bluetooth className="w-4 h-4" /> Pair Web Bluetooth Smart Device
            </button>

            <div className="relative flex items-center justify-center">
              <div className="border-t border-slate-800 w-full" />
              <span className="bg-slate-900 px-3 text-[10px] text-slate-500 uppercase tracking-widest absolute">or manual entry</span>
            </div>

            <form onSubmit={handleManualVitalsSubmit} className="space-y-4">
              <div>
                <label className="text-xs text-amber-300 mb-1 block">Device Model / Name (optional)</label>
                <input
                  type="text"
                  value={deviceName}
                  onChange={e => setDeviceName(e.target.value)}
                  placeholder="e.g. Apple Watch / Samsung Galaxy / Oximeter"
                  className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[11px] text-cyan-300 block mb-1">Pulse (BPM)</label>
                  <input
                    type="number"
                    value={manualBpm}
                    onChange={e => setManualBpm(e.target.value)}
                    className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] text-emerald-300 block mb-1">SpO2 (%)</label>
                  <input
                    type="number"
                    value={manualSpo2}
                    onChange={e => setManualSpo2(e.target.value)}
                    className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="text-[11px] text-amber-300 block mb-1">Blood Pressure</label>
                  <input
                    type="text"
                    value={manualBp}
                    onChange={e => setManualBp(e.target.value)}
                    placeholder="120/80"
                    className="w-full p-2.5 bg-black rounded-xl border border-slate-800 text-sm text-slate-200 outline-none"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-600 hover:bg-amber-500 rounded-xl font-bold text-black shadow-md"
              >
                Save & Apply Vitals
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   CAREER PROJECTION MODULE (5-Year AI Impact & Salary Growth Roadmap)
   ========================================================================= */
function CareerPrediction({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [loading, setLoading] = useState(false);
  const [currentRole, setCurrentRole] = useState('Senior Software Engineer');
  const [industry, setIndustry] = useState('Fintech & AI Systems');
  const [experienceYears, setExperienceYears] = useState('4 Years');
  const [currentSkills, setCurrentSkills] = useState('TypeScript, Python, LLM Architecture, Cloud Infrastructure');
  const [primaryGoal, setPrimaryGoal] = useState('Double annual earnings, transition to AI Architect / Founder');
  const [results, setResults] = useState<any>(null);

  const handlePredict = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/career-prediction', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          currentRole,
          industry,
          experienceYears,
          currentSkills,
          primaryGoal
        })
      });
      const data = await res.json();
      setResults(data);
      setLoading(false);
      setMode('results');
      saveHistory('Career Projection & Income Forecast', `Role: ${currentRole}. AI Automation Risk: ${data.aiAutomationRiskScore}%. Longevity: ${data.jobLongevityRating}`);
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert('Failed to generate career forecast.');
    }
  };

  const exportPDF = () => {
    if (!results) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(6, 182, 212);
    doc.text("FuturePulse AI - 5-Year Career & Salary Growth Roadmap", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Role: ${currentRole} | Industry: ${industry} | Experience: ${experienceYears}`, 14, 28);
    doc.text(`Current Skills: ${currentSkills}`, 14, 34);
    doc.text(`Primary Goal: ${primaryGoal}`, 14, 40);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 46);

    let y = 54;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text(`AI Automation Risk Score: ${results.aiAutomationRiskScore}% | Job Longevity: ${results.jobLongevityRating}`, 14, y);
    y += 10;

    doc.text("Executive Forecast Summary:", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitSummary = doc.splitTextToSize(results.forecastSummary, 180);
    doc.text(splitSummary, 14, y);
    y += (splitSummary.length * 5) + 8;

    doc.setFont("helvetica", "bold");
    doc.text("Top 3 High-Income Opportunities (Next 12 Months):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    results.topOpportunities?.forEach((opp: string, i: number) => {
      const splitOpp = doc.splitTextToSize(`${i+1}. ${opp}`, 180);
      doc.text(splitOpp, 14, y);
      y += (splitOpp.length * 5) + 4;
    });

    y += 4;
    doc.setFont("helvetica", "bold");
    doc.text("Step-by-Step 5-Year Action Plan:", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    results.actionPlan?.forEach((act: string, i: number) => {
      const splitAct = doc.splitTextToSize(`${i+1}. ${act}`, 180);
      doc.text(splitAct, 14, y);
      y += (splitAct.length * 5) + 4;
    });

    doc.save("Career_Salary_Roadmap.pdf");
    alert("Career Report saved to PDF successfully!");
  };

  const resultsEnglishText = results ? 
    `Career Forecast for ${currentRole} in ${industry}. AI Automation risk is ${results.aiAutomationRiskScore} percent. Job longevity rating: ${results.jobLongevityRating}. Summary: ${results.forecastSummary}. Top opportunities: ${results.topOpportunities?.join('. ')}. Action plan: ${results.actionPlan?.join('. ')}` : '';

  const resultsHindiText = results ? 
    `${currentRole} के लिए 5-वर्षीय करियर एवं वेतन वृद्धि रोडमैप। एआई ऑटोमेशन जोखिम ${results.aiAutomationRiskScore} प्रतिशत है। नौकरी दीर्घायु रेटिंग: ${results.jobLongevityRating}। मुख्य सारांश: ${results.forecastSummary}। अगले 12 महीनों के शीर्ष 3 उच्च-आय अवसर: ${results.topOpportunities?.join('। ')}। 5-वर्षीय कार्य योजना: ${results.actionPlan?.join('। ')}` : '';

  const resultsText = resultsEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: 'Career Forecast Report', text: resultsText}).catch(() => {});
    } else {
      onShare(resultsText, 'Career Forecast Dossier');
    }
  };

  if (mode === 'results' && results) return (
    <div className="space-y-6 pb-20 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-cyan-500/40">
        <div>
          <h2 className="text-xl font-bold text-cyan-300">5-Year Career & Salary Roadmap</h2>
          <p className="text-xs text-slate-400">{currentRole} • {industry} ({experienceYears})</p>
        </div>
        <button onClick={() => setMode('form')} className="text-xs text-cyan-400 hover:text-cyan-200 underline">
          New Forecast
        </button>
      </div>

      {/* Risk & Longevity Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-5 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">AI Automation Disruption Risk</p>
          <p className="text-3xl font-extrabold text-red-400 mt-1">{results.aiAutomationRiskScore}%</p>
          <div className="h-1.5 bg-black rounded-full overflow-hidden border border-slate-800 mt-2">
            <motion.div className="h-full bg-red-500" initial={{width: 0}} animate={{width: `${results.aiAutomationRiskScore}%`}} transition={{duration: 1}} />
          </div>
        </div>
        <div className="p-5 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Job Longevity Rating</p>
          <p className="text-2xl font-bold text-emerald-300 mt-2">{results.jobLongevityRating}</p>
        </div>
      </div>

      <div className="p-5 bg-slate-900/60 rounded-2xl border border-cyan-500/30 space-y-2 text-xs text-slate-200">
        <p className="font-bold text-cyan-300 uppercase tracking-wide">✨ Executive Forecast Summary</p>
        <p className="leading-relaxed">{results.forecastSummary}</p>
      </div>

      {/* Top 3 Opportunities */}
      <div className="p-5 bg-slate-900/60 rounded-2xl border border-amber-500/30 space-y-3">
        <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wide">
          Top 3 High-Income Skills & Growth Opportunities (अगले 12 महीने)
        </h4>
        <div className="space-y-2">
          {results.topOpportunities?.map((opp: string, i: number) => (
            <div key={i} className="p-3 bg-black/60 rounded-xl border border-slate-800 text-xs text-slate-200">
              • {opp}
            </div>
          ))}
        </div>
      </div>

      {/* Action Plan */}
      <div className="p-5 bg-slate-900/60 rounded-2xl border border-cyan-500/30 space-y-3">
        <h4 className="text-xs font-bold text-cyan-300 uppercase tracking-wide">
          Step-by-Step 5-Year Action Plan (Roadmap)
        </h4>
        <div className="space-y-2 border-l-2 border-cyan-500 pl-4">
          {results.actionPlan?.map((step: string, i: number) => (
            <p key={i} className="text-xs text-slate-200">{step}</p>
          ))}
        </div>
      </div>

      <DualVoicePlayer
        englishText={resultsEnglishText}
        hindiText={resultsHindiText}
        title="Career & Income Audio / करियर रिपोर्ट ऑडियो"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button 
          onClick={handleShareReport} 
          className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
        </button>

        <button 
          onClick={() => setMode('form')} 
          className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
        >
          New Career Analysis
        </button>
      </div>
    </div>
  );

  return (
    <form 
      onSubmit={handlePredict} 
      className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-cyan-500/40 space-y-4 font-mono shadow-xl"
    >
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-cyan-300 flex items-center gap-2">
          <Brain className="w-6 h-6 text-cyan-400" /> 5-Year Career & Salary Growth Roadmap
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Input your role, industry, and skills to analyze AI automation risk and projected income trajectories.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Current Role / Job Title</label>
          <input
            type="text"
            value={currentRole}
            onChange={e => setCurrentRole(e.target.value)}
            placeholder="e.g. Software Engineer / Financial Analyst"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Industry / Sector</label>
          <input
            type="text"
            value={industry}
            onChange={e => setIndustry(e.target.value)}
            placeholder="e.g. Fintech, Healthcare, Cloud"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Years of Experience</label>
          <input
            type="text"
            value={experienceYears}
            onChange={e => setExperienceYears(e.target.value)}
            placeholder="e.g. 4 Years"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-cyan-400 mb-1 block">Core Skills (हुनर)</label>
          <input
            type="text"
            value={currentSkills}
            onChange={e => setCurrentSkills(e.target.value)}
            placeholder="e.g. React, Python, Cloud, Data"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
            required
          />
        </div>
      </div>

      <div>
        <label className="text-xs text-cyan-400 mb-1 block">Primary 5-Year Income / Career Goal</label>
        <input
          type="text"
          value={primaryGoal}
          onChange={e => setPrimaryGoal(e.target.value)}
          placeholder="e.g. Double salary and transition to AI team lead"
          className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-cyan-100 text-sm focus:border-cyan-500 outline-none"
          required
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(6,182,212,0.4)] transition-all"
      >
        {loading ? 'Synthesizing Career Roadmap...' : '⚡ Generate 5-Year Career & Salary Roadmap'}
      </button>
    </form>
  );
}

/* =========================================================================
   COMPANY, FIRM & TRUST FUTURE ANALYZER (Google Search Grounded)
   ========================================================================= */
function CompanyTrustForecast({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [loading, setLoading] = useState(false);
  const [entityName, setEntityName] = useState('Aarogyam Biotech & Trust');
  const [entityType, setEntityType] = useState('MSME Firm / Charitable Trust');
  const [industry, setIndustry] = useState('Healthcare, Herbal Products & Civic Wellness');
  const [location, setLocation] = useState('Rajasthan, India');
  const [currentStatus, setCurrentStatus] = useState('Operational with steady revenue, expanding distribution');
  const [results, setResults] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/company-trust-forecast', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({entityName, entityType, industry, location, currentStatus})
      });
      const data = await res.json();
      setResults(data);
      setLoading(false);
      setMode('results');
      saveHistory('Company, Firm & Trust Future', `${entityName} (${entityType}): Profit Prob ${data.profitProbability}%, Survival ${data.marketSurvivalRating}`);
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert('Failed to generate business forecast.');
    }
  };

  const exportPDF = () => {
    if (!results) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(245, 158, 11);
    doc.text("FuturePulse AI - Company, Firm & Trust Strategic Dossier", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Entity: ${entityName} | Type: ${entityType}`, 14, 28);
    doc.text(`Sector: ${industry} | Location: ${location}`, 14, 34);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 40);

    let y = 48;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text(`Profit Probability: ${results.profitProbability}% | Market Survival: ${results.marketSurvivalRating}`, 14, y);
    y += 10;

    doc.text("Executive Strategic Summary:", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitSummary = doc.splitTextToSize(results.executiveSummary, 180);
    doc.text(splitSummary, 14, y);
    y += (splitSummary.length * 5) + 8;

    doc.setFont("helvetica", "bold");
    doc.text("What to Do (1-3 Year Action Steps):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    results.whatToDo?.forEach((item: string, i: number) => {
      const splitItem = doc.splitTextToSize(`${i+1}. ${item}`, 180);
      doc.text(splitItem, 14, y);
      y += (splitItem.length * 5) + 4;
    });

    doc.save("Company_Trust_Future_Report.pdf");
    alert("Company Report saved to PDF successfully!");
  };

  const companyEnglishText = results ? 
    `Company Future Forecast for ${entityName}. Profit probability is ${results.profitProbability} percent. Loss risk is ${results.lossProbability} percent. Market survival rating is ${results.marketSurvivalRating}. Executive Summary: ${results.executiveSummary}. What to do: ${results.whatToDo?.join('. ')}. What to avoid: ${results.whatToAvoid?.join('. ')}. Market demand trends: ${results.marketDemandTrends}. Regulatory risks: ${results.regulatoryRisks}.` : '';

  const companyHindiText = results ? 
    `${entityName} व्यापार एवं ट्रस्ट भविष्य पूर्वानुमान। लाभ की संभावना ${results.profitProbability} प्रतिशत है। हानि का जोखिम ${results.lossProbability} प्रतिशत है। बाजार में टिके रहने की रेटिंग: ${results.marketSurvivalRating}। मुख्य सारांश: ${results.executiveSummary}। क्या करें: ${results.whatToDo?.join('। ')}। क्या न करें: ${results.whatToAvoid?.join('। ')}। बाजार मांग रुझान: ${results.marketDemandTrends}। विनियामक जोखिम: ${results.regulatoryRisks}।` : '';

  const resultsText = companyEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: `${entityName} Future Dossier`, text: resultsText}).catch(() => {});
    } else {
      onShare(resultsText, 'Company, Firm & Trust Future Report');
    }
  };

  if (mode === 'results' && results) return (
    <div className="space-y-6 pb-20 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-amber-500/40">
        <div>
          <h2 className="text-xl font-bold text-amber-300">{entityName}</h2>
          <p className="text-xs text-slate-400">{entityType} • {industry} ({location})</p>
        </div>
        <button onClick={() => setMode('form')} className="text-xs text-amber-400 hover:text-amber-200 underline">
          New Analysis
        </button>
      </div>

      {/* Probability Matrix & Survival Rating */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Profit Probability</p>
          <p className="text-3xl font-extrabold text-emerald-400 mt-1">{results.profitProbability}%</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Loss Risk Probability</p>
          <p className="text-3xl font-extrabold text-red-400 mt-1">{results.lossProbability}%</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Market Survival Rating</p>
          <p className="text-base font-bold text-amber-300 mt-2">{results.marketSurvivalRating}</p>
        </div>
      </div>

      <div className="p-5 bg-slate-900/60 rounded-2xl border border-amber-500/30 space-y-2 text-xs text-slate-200">
        <p className="font-bold text-amber-400 uppercase tracking-wide">✨ Executive Strategic Forecast</p>
        <p className="leading-relaxed">{results.executiveSummary}</p>
      </div>

      {/* What To Do vs What To Avoid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-5 bg-slate-900/60 rounded-2xl border border-emerald-500/30 space-y-3">
          <p className="text-xs font-bold text-emerald-400 uppercase tracking-wide">✓ What To Do (अगले 1-3 साल क्या करें)</p>
          <div className="space-y-2 text-xs text-slate-200">
            {results.whatToDo?.map((item: string, i: number) => (
              <p key={i}>• {item}</p>
            ))}
          </div>
        </div>

        <div className="p-5 bg-slate-900/60 rounded-2xl border border-red-500/30 space-y-3">
          <p className="text-xs font-bold text-red-400 uppercase tracking-wide">✗ What To Avoid (क्या न करें - जोखिम)</p>
          <div className="space-y-2 text-xs text-slate-200">
            {results.whatToAvoid?.map((item: string, i: number) => (
              <p key={i}>• {item}</p>
            ))}
          </div>
        </div>
      </div>

      <div className="p-5 bg-slate-900/60 rounded-2xl border border-slate-800 space-y-2 text-xs text-slate-300">
        <p className="font-bold text-cyan-300 uppercase">Market Demand & Regulatory Intelligence</p>
        <p><strong>Demand Trends:</strong> {results.marketDemandTrends}</p>
        <p><strong>Regulatory Compliance:</strong> {results.regulatoryRisks}</p>
      </div>

      <DualVoicePlayer
        englishText={companyEnglishText}
        hindiText={companyHindiText}
        title="Company & Trust Audio / व्यापार व ट्रस्ट ऑडियो"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button 
          onClick={handleShareReport} 
          className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
        </button>

        <button 
          onClick={() => setMode('form')} 
          className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
        >
          New Analysis
        </button>
      </div>
    </div>
  );

  return (
    <form 
      onSubmit={handleSubmit} 
      className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-amber-500/40 space-y-4 font-mono shadow-xl"
    >
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-amber-300 flex items-center gap-2">
          <Building2 className="w-6 h-6 text-amber-400" /> Company, Firm & Trust Future Analyzer
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Real-time Google search grounded strategic forecasting for MSMEs, corporate firms, and non-profit trusts.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-amber-400 mb-1 block">Entity Name (कंपनी / फर्म / ट्रस्ट का नाम)</label>
          <input
            type="text"
            value={entityName}
            onChange={e => setEntityName(e.target.value)}
            placeholder="e.g. Aarogyam Biotech & Trust"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-amber-400 mb-1 block">Entity Structure</label>
          <select
            value={entityType}
            onChange={e => setEntityType(e.target.value)}
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
          >
            <option value="MSME Firm">MSME Firm / Startup</option>
            <option value="Private Limited Company">Private Limited Company</option>
            <option value="Charitable Trust / NGO">Charitable Trust / NGO</option>
            <option value="Partnership Firm">Partnership Firm</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-amber-400 mb-1 block">Industry / Sector</label>
          <input
            type="text"
            value={industry}
            onChange={e => setIndustry(e.target.value)}
            placeholder="e.g. Healthcare, Retail, IT Services"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-amber-400 mb-1 block">Location / Jurisdiction</label>
          <input
            type="text"
            value={location}
            onChange={e => setLocation(e.target.value)}
            placeholder="e.g. Rajasthan, India"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
            required
          />
        </div>
      </div>

      <div>
        <label className="text-xs text-amber-400 mb-1 block">Current Operational & Financial Status</label>
        <textarea
          value={currentStatus}
          onChange={e => setCurrentStatus(e.target.value)}
          placeholder="e.g. Breakeven revenue, seeking capital and market expansion..."
          className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-amber-100 text-sm focus:border-amber-500 outline-none"
          rows={2}
          required
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-4 bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 rounded-xl font-bold text-black shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all"
      >
        {loading ? 'Synthesizing Search Grounded Forecast...' : '⚡ Generate Strategic Business Forecast'}
      </button>
    </form>
  );
}

/* =========================================================================
   DISEASE & OUTBREAK EARLY WARNING RADAR (Google Search Grounded)
   ========================================================================= */
function DiseaseRadarForecast({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [locationQuery, setLocationQuery] = useState('Rajasthan, India');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);

  const fetchRadar = async (overrideLoc?: string) => {
    const loc = overrideLoc || locationQuery;
    setLoading(true);
    try {
      const res = await fetch('/api/disease-radar', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({locationQuery: loc})
      });
      const json = await res.json();
      setData(json);
      setLoading(false);
      saveHistory('Disease & Outbreak Radar', `Location: ${loc}. Alert: ${json.alertLevel}.`);
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert('Failed to connect to Disease Radar surveillance feed.');
    }
  };

  const exportPDF = () => {
    if (!data) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(244, 63, 94);
    doc.text("FuturePulse AI - Disease & Outbreak Radar Report", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Monitored Location: ${data.location}`, 14, 28);
    doc.text(`Alert Status: ${data.alertLevel} | Data Confidence: ${data.dataConfidenceScore}%`, 14, 34);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 40);

    let y = 48;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text("Active Health Alerts & Pathogen Surveillance:", 14, y);
    y += 8;

    data.currentActiveAlerts?.forEach((alert: any) => {
      if (y > 250) { doc.addPage(); y = 20; }
      doc.setFont("helvetica", "bold");
      doc.text(`• ${alert.diseaseName} (${alert.severity} Severity)`, 14, y);
      y += 5;
      doc.setFont("helvetica", "normal");
      const splitDesc = doc.splitTextToSize(alert.description, 180);
      doc.text(splitDesc, 14, y);
      y += (splitDesc.length * 5) + 4;
    });

    doc.save("Disease_Outbreak_Radar.pdf");
    alert("Outbreak Radar saved to PDF successfully!");
  };

  const alertsText = data?.currentActiveAlerts?.map((a: any) => `${a.diseaseName}: ${a.severity} severity. ${a.description}`).join('. ') || 'No critical active outbreaks detected';
  
  const radarEnglishText = data ? 
    `Disease and Outbreak Early Warning Radar for ${data.location}. Alert Level is ${data.alertLevel}. Data confidence score is ${data.dataConfidenceScore} percent. Active alerts: ${alertsText}. Three-month seasonal forecast: ${data.threeMonthForecast}. Preventive measures: ${data.preventiveSafetyMeasures?.join('. ')}. Public advisory: ${data.publicHealthNotice}` : '';

  const radarHindiText = data ? 
    `${data.location} क्षेत्र के लिए बीमारी एवं महामारी पूर्व चेतावनी रडार। चेतावनी स्तर: ${data.alertLevel}। डेटा विश्वसनीयता: ${data.dataConfidenceScore} प्रतिशत। सक्रिय अलर्ट: ${data?.currentActiveAlerts?.map((a: any) => `${a.diseaseName} (${a.severity} तीव्रता): ${a.description}`).join('। ') || 'कोई गंभीर अलर्ट नहीं'}। आगामी 3 माह का मौसमी पूर्वानुमान: ${data.threeMonthForecast}। बचाव के उपाय: ${data.preventiveSafetyMeasures?.join('। ')}। स्वास्थ्य सलाह: ${data.publicHealthNotice}` : '';

  const radarText = radarEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: `Disease Radar - ${data?.location}`, text: radarText}).catch(() => {});
    } else {
      onShare(radarText, 'Disease & Outbreak Radar Dossier');
    }
  };

  return (
    <div className="space-y-6 pb-20 font-mono">
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-rose-500/40 shadow-xl space-y-4">
        <div className="flex items-center gap-2">
          <Radio className="w-6 h-6 text-rose-400 animate-pulse" />
          <h2 className="text-xl sm:text-2xl font-bold text-rose-300">
            Disease & Outbreak Early Warning Radar
          </h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          देश-राज्य और क्षेत्र में आने वाली बीमारियों का अलर्ट — Live Google Search grounded disease surveillance aggregating verified WHO, ICMR, and NCDC public health alerts for seasonal epidemics, vectors, and emerging pathogens.
        </p>

        {/* Quick Location Chips */}
        <div className="flex flex-wrap gap-2 text-xs">
          {['Rajasthan, India', 'Delhi NCR', 'Maharashtra', 'Uttar Pradesh', 'New York, USA', 'Global Watch'].map(loc => (
            <button
              key={loc}
              type="button"
              onClick={() => { setLocationQuery(loc); fetchRadar(loc); }}
              className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs transition-colors"
            >
              {loc}
            </button>
          ))}
        </div>

        <form onSubmit={e => { e.preventDefault(); fetchRadar(); }} className="flex gap-2 pt-1">
          <input
            type="text"
            value={locationQuery}
            onChange={e => setLocationQuery(e.target.value)}
            placeholder="Type any City, State, or Country..."
            className="flex-1 p-3 bg-black/60 rounded-xl border border-slate-800 text-rose-100 text-sm focus:border-rose-500 outline-none"
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-3 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 rounded-xl font-bold text-white shadow-lg transition-all"
          >
            {loading ? 'Searching...' : 'Scan Area'}
          </button>
        </form>
      </div>

      {data && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-rose-500/40 space-y-6 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-lg font-bold text-rose-200">Surveillance: {data.location}</h3>
              <p className="text-xs text-rose-400 font-bold">{data.alertLevel}</p>
            </div>
            <span className="text-[10px] text-cyan-400 bg-cyan-950 px-2.5 py-1 rounded-full border border-cyan-500/30">
              Confidence: {data.dataConfidenceScore}%
            </span>
          </div>

          {/* Active Outbreak Alerts */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wide">
              Active Outbreaks & Pathogen Surveillance (सक्रिय स्वास्थ्य अलर्ट)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {data.currentActiveAlerts?.map((alert: any, i: number) => (
                <div key={i} className="p-4 bg-black/60 rounded-2xl border border-slate-800 space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-rose-200">{alert.diseaseName}</span>
                    <span className="text-[10px] text-amber-400 px-2 py-0.5 bg-amber-950/70 rounded-full border border-amber-500/30">
                      {alert.severity}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{alert.description}</p>
                  {alert.trend && (
                    <p className="text-[10px] text-cyan-400">Trend: {alert.trend}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 3-Month Outbreak & Seasonal Risk Forecast */}
          <div className="p-5 bg-black/60 rounded-2xl border border-rose-500/30 space-y-2">
            <p className="text-xs font-bold text-rose-400 uppercase tracking-wide">
              🔮 3-Month Outbreak & Seasonal Risk Forecast (आगामी 3 महीनों का पूर्वानुमान)
            </p>
            <p className="text-xs text-slate-200 leading-relaxed">{data.threeMonthForecast}</p>
          </div>

          {/* Preventive Safety Measures */}
          <div className="p-5 bg-black/60 rounded-2xl border border-cyan-500/30 space-y-3">
            <p className="text-xs font-bold text-cyan-300 uppercase tracking-wide">
              🛡️ Preventive Safety Measures & Hygiene Protocols (बचाव व सावधानियां)
            </p>
            <div className="space-y-2">
              {data.preventiveSafetyMeasures?.map((measure: string, i: number) => (
                <div key={i} className="p-3 bg-slate-900/50 rounded-xl border border-slate-800 text-xs text-slate-200">
                  {measure}
                </div>
              ))}
            </div>
          </div>

          <DualVoicePlayer
            englishText={radarEnglishText}
            hindiText={radarHindiText}
            title="Outbreak Radar Audio / महामारी रडार ऑडियो"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button 
              onClick={handleShareReport} 
              className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
            >
              <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
            </button>

            <button 
              onClick={() => setData(null)} 
              className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
            >
              New Location Scan
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   MACRO GEOPOLITICAL INTELLIGENCE (Google Search Grounded)
   ========================================================================= */
function GlobalHealthIntelligence({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [data, setData] = useState<any>(null);
  const [countryOrTopic, setCountryOrTopic] = useState('India (भारत - आगामी चुनाव, नीतियां और बाजार रुझान)');
  const [loading, setLoading] = useState(false);

  const fetchMacro = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/macro-forecast', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({countryOrTopic})
      });
      const json = await res.json();
      setData(json);
      setLoading(false);
      saveHistory('Macro Geopolitical Intelligence', `Target: ${countryOrTopic}. Policy Impact Score: ${json.policyImpactScore}/100.`);
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert('Failed to connect to Macro Intelligence AI.');
    }
  };

  const exportPDF = () => {
    if (!data) return;
    const doc = new jsPDF();
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(6, 182, 212);
    doc.text("FuturePulse AI - Macro Geopolitical & Economic Intelligence", 14, 20);

    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text(`Target Region / Topic: ${countryOrTopic}`, 14, 28);
    doc.text(`Policy Impact Score: ${data.policyImpactScore}/100 | Confidence: ${data.dataConfidenceScore}%`, 14, 34);
    doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 40);

    let y = 48;
    doc.setFontSize(11);
    doc.setTextColor(20, 20, 20);

    doc.setFont("helvetica", "bold");
    doc.text("Present Situation Summary (वर्तमान स्थिति):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitPres = doc.splitTextToSize(data.presentSituationSummary, 180);
    doc.text(splitPres, 14, y);
    y += (splitPres.length * 5) + 8;

    doc.setFont("helvetica", "bold");
    doc.text("Future Economic & Policy Impact Forecast (भविष्य का प्रभाव):", 14, y);
    y += 6;
    doc.setFont("helvetica", "normal");
    const splitFut = doc.splitTextToSize(data.futureImpactForecast, 180);
    doc.text(splitFut, 14, y);
    y += (splitFut.length * 5) + 8;

    doc.save("Macro_Intelligence_Report.pdf");
    alert("Macro Intelligence Report saved to PDF successfully!");
  };

  const macroEnglishText = data ? 
    `Macro Geopolitical Intelligence for ${countryOrTopic}. Policy Impact Score is ${data.policyImpactScore} out of 100. Data Confidence Score is ${data.dataConfidenceScore || 92} percent. Present Situation: ${data.presentSituationSummary}. Future Forecast: ${data.futureImpactForecast}. Key factors: ${data.keyFactualFactors?.join('. ')}.` : '';

  const macroHindiText = data ? 
    `${countryOrTopic} के लिए भू-राजनीतिक एवं नीतिगत विश्लेषण। नीतिगत प्रभाव स्कोर 100 में से ${data.policyImpactScore} है। डेटा विश्वसनीयता: ${data.dataConfidenceScore || 92} प्रतिशत। वर्तमान स्थिति: ${data.presentSituationSummary}। भविष्य का प्रभाव: ${data.futureImpactForecast}। मुख्य तथ्य: ${data.keyFactualFactors?.join('। ')}। आधिकारिक सूचना: यह विश्लेषण सर्च आधारित एआई सिमुलेशन है।` : '';

  const macroText = macroEnglishText;

  const handleShareReport = () => {
    exportPDF();
    if (navigator.share) {
      navigator.share({title: 'Macro Intelligence Report', text: macroText}).catch(() => {});
    } else {
      onShare(macroText, 'Macro Geopolitical Report');
    }
  };

  return (
    <div className="space-y-6 pb-20 font-mono">
      <form 
        onSubmit={fetchMacro} 
        className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-violet-500/40 space-y-4 shadow-xl"
      >
        <div className="border-b border-slate-800 pb-3">
          <h2 className="text-xl sm:text-2xl font-bold text-violet-300 flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-violet-400" /> Macro Geopolitical Intelligence
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time search grounded simulator for elections, economic policy shifts, gold/crypto trends, and international trade.
          </p>
        </div>

        <div className="flex gap-2">
          <input
            type="text"
            value={countryOrTopic}
            onChange={e => setCountryOrTopic(e.target.value)}
            placeholder="e.g. India / USA / Gold Market / Upcoming Elections"
            className="flex-1 p-3 bg-black/60 rounded-xl border border-slate-800 text-violet-100 text-sm focus:border-violet-500 outline-none"
            required
          />
          <button 
            type="submit" 
            disabled={loading}
            className="px-6 py-3 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 rounded-xl font-bold text-white shadow-lg transition-all"
          >
            {loading ? 'Analyzing...' : 'Simulate'}
          </button>
        </div>
      </form>

      {data && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-violet-500/40 space-y-6 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-lg font-bold text-violet-200">Target: {countryOrTopic}</h3>
              <p className="text-xs text-violet-400 font-bold">Policy Impact Score: {data.policyImpactScore}/100</p>
            </div>
            <span className="text-[10px] text-cyan-400 font-mono">
              CONFIDENCE: {data.dataConfidenceScore || 92}%
            </span>
          </div>

          {/* Scenario Breakdown */}
          {data.scenarioBreakdown && (
            <div className="p-5 bg-black/60 rounded-2xl border border-amber-500/30 space-y-3">
              <p className="text-xs font-bold text-amber-400 uppercase tracking-wide">
                Balanced Scenario Breakdown (परिप्रेक्ष्य विश्लेषण)
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-900/50 rounded-xl border border-cyan-500/30 space-y-1">
                  <p className="font-bold text-cyan-300">Scenario A (Optimistic Growth)</p>
                  <p className="text-slate-300 leading-relaxed">{data.scenarioBreakdown.scenarioA}</p>
                </div>
                <div className="p-3 bg-slate-900/50 rounded-xl border border-violet-500/30 space-y-1">
                  <p className="font-bold text-violet-300">Scenario B (Conservative / Risk)</p>
                  <p className="text-slate-300 leading-relaxed">{data.scenarioBreakdown.scenarioB}</p>
                </div>
              </div>
            </div>
          )}

          {/* Present Situation Summary */}
          <div className="p-4 bg-black/60 rounded-2xl border border-cyan-500/30 space-y-1.5">
            <p className="text-xs font-bold text-amber-400 uppercase tracking-wide">वर्तमान स्थिति (Present Situation)</p>
            <p className="text-xs text-slate-200 leading-relaxed">{data.presentSituationSummary}</p>
          </div>

          {/* Future Economic / Policy Impact Forecast */}
          <div className="p-4 bg-black/60 rounded-2xl border border-violet-500/30 space-y-1.5">
            <p className="text-xs font-bold text-violet-400 uppercase tracking-wide">भविष्य का प्रभाव (Future Impact Forecast)</p>
            <p className="text-xs text-slate-200 leading-relaxed">{data.futureImpactForecast}</p>
          </div>

          <DualVoicePlayer
            englishText={macroEnglishText}
            hindiText={macroHindiText}
            title="Geopolitical Forecast Audio / भू-राजनीतिक रिपोर्ट ऑडियो"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button 
              onClick={handleShareReport} 
              className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-[0_0_20px_rgba(217,70,239,0.4)] flex items-center justify-center gap-2"
            >
              <Share2 className="w-5 h-5" /> Export Report (PDF / Share)
            </button>

            <button 
              onClick={() => setData(null)} 
              className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
            >
              New Query
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* =========================================================================
   ENTERPRISE DISRUPTIVE ROADMAP MODULE
   ========================================================================= */
function OrgForecasting({saveHistory, onShare}: {saveHistory: any, onShare: any}) {
  const [mode, setMode] = useState<'form' | 'results'>('form');
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [orgType, setOrgType] = useState('Autonomous AI Hardware & EV Fleet');
  const [ticker, setTicker] = useState('TSLA');
  const [region, setRegion] = useState('Global');
  const [objectives, setObjectives] = useState('Deploy next-gen AI agentic workflow across core supply chains');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/org-forecast', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({orgType, ticker, region, objectives})
      });
      const data = await res.json();
      setResults(data);
      setLoading(false);
      setMode('results');
      saveHistory('Enterprise Disruptive Roadmap', `Org: ${orgType} (${ticker || 'N/A'}). Disruption Risk: ${data.disruptionRisk}%.`);
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert('Failed to generate enterprise forecast.');
    }
  };

  const orgEnglishText = results ? 
    `Enterprise Disruption Risk for ${results.liveMarket?.identifier || 'Organization'} is ${results.disruptionRisk} percent. Market capitalization: ${results.liveMarket?.marketCapUsd}. Trajectory assessment: ${results.trajectory}. Strategic pivot roadmap: ${results.pivotRoadmap?.join(', ')}.` : '';

  const orgHindiText = results ? 
    `${results.liveMarket?.identifier || 'संस्थान'} के लिए कॉर्पोरेट डिसरप्शन रिस्क ${results.disruptionRisk} प्रतिशत है। मार्केट कैप: ${results.liveMarket?.marketCapUsd}। संस्थागत प्रक्षेपवक्र: ${results.trajectory}। रणनीतिक पिवट रोडमैप: ${results.pivotRoadmap?.join('। ')}। आधिकारिक सूचना: बाजार जोखिम व पूर्वानुमान हेतु विशेषज्ञों से परामर्श लें।` : '';

  const resultsText = orgEnglishText;

  if (mode === 'results' && results) return (
    <div className="space-y-6 pb-20 font-mono">
      <div className="flex justify-between items-center bg-slate-900/70 p-4 rounded-2xl border border-fuchsia-500/40">
        <h2 className="text-xl font-bold text-fuchsia-300">
          Institutional Dossier ({results.liveMarket?.identifier})
        </h2>
        <button onClick={() => setMode('form')} className="text-xs text-fuchsia-400 hover:text-fuchsia-200 underline">
          New Query
        </button>
      </div>

      {/* Live Market Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Market Cap</p>
          <p className="text-xl font-bold text-cyan-300 mt-1">{results.liveMarket?.marketCapUsd}</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Volatility Beta</p>
          <p className="text-xl font-bold text-amber-300 mt-1">{results.liveMarket?.volatilityBeta}</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Disruption Index</p>
          <p className="text-xl font-bold text-red-400 mt-1">{results.liveMarket?.industryDisruptionIndex}%</p>
        </div>
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800 text-center">
          <p className="text-[10px] text-slate-400 font-bold uppercase">Liquidity Ratio</p>
          <p className="text-xl font-bold text-emerald-300 mt-1">{results.liveMarket?.liquidityRatio}</p>
        </div>
      </div>

      <div className="p-6 bg-slate-900/60 rounded-3xl border border-fuchsia-500/40 space-y-4">
        <h4 className="text-fuchsia-200 text-sm font-bold">Disruption Risk Analysis</h4>
        <div className="h-3 bg-black rounded-full overflow-hidden border border-slate-800">
          <motion.div className="h-full bg-red-500" initial={{width: 0}} animate={{width: `${results.disruptionRisk}%`}} transition={{duration: 1}} />
        </div>
        <p className="text-sm text-slate-200 bg-black/50 p-4 rounded-xl border border-slate-800">{results.trajectory}</p>
        <h4 className="text-fuchsia-200 text-sm font-bold">Strategic Pivot Roadmap (Tesla/SpaceX Grade)</h4>
        <div className="border-l-2 border-fuchsia-500 pl-4 space-y-2">
          {results.pivotRoadmap.map((r: string, i: number) => (
            <p key={i} className="text-xs text-slate-200">Action {i+1}: {r}</p>
          ))}
        </div>
      </div>

      <DualVoicePlayer
        englishText={orgEnglishText}
        hindiText={orgHindiText}
        title="Enterprise Roadmap Audio / कॉर्पोरेट रोडमैप ऑडियो"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button 
          onClick={() => onShare(resultsText, 'Enterprise Disruptive Dossier')} 
          className="py-4 bg-fuchsia-600 hover:bg-fuchsia-500 rounded-xl font-bold text-white shadow-lg flex items-center justify-center gap-2"
        >
          <Share2 className="w-5 h-5" /> Export Report (Share)
        </button>

        <button 
          onClick={() => setMode('form')} 
          className="py-4 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-slate-300"
        >
          New Analysis
        </button>
      </div>
    </div>
  );

  return (
    <form 
      onSubmit={handleSubmit} 
      className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-fuchsia-500/40 space-y-4 font-mono shadow-xl"
    >
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-fuchsia-300 flex items-center gap-2">
          <User className="w-6 h-6 text-fuchsia-400" /> Enterprise Disruptive Intelligence
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Input corporate parameters with live market connectors to generate high-fidelity disruption risk and pivot roadmaps.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-fuchsia-400 mb-1 block">Company / Sector Name</label>
          <input
            type="text"
            value={orgType}
            onChange={e => setOrgType(e.target.value)}
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
            required
          />
        </div>

        <div>
          <label className="text-xs text-fuchsia-400 mb-1 block">Ticker Symbol (optional)</label>
          <input
            type="text"
            value={ticker}
            onChange={e => setTicker(e.target.value)}
            placeholder="e.g. TSLA, NVDA"
            className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
          />
        </div>
      </div>

      <div>
        <label className="text-xs text-fuchsia-400 mb-1 block">Strategic Transformation Objectives</label>
        <textarea
          value={objectives}
          onChange={e => setObjectives(e.target.value)}
          placeholder="e.g. Deploy next-gen AI agentic workflow across core supply chains..."
          className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-fuchsia-100 text-sm focus:border-fuchsia-500 outline-none"
          rows={2}
          required
        />
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full py-4 bg-gradient-to-r from-fuchsia-600 to-pink-600 hover:from-fuchsia-500 hover:to-pink-500 rounded-xl font-bold text-white shadow-lg transition-all"
      >
        {loading ? 'Synthesizing Enterprise Model...' : '⚡ Generate Strategic Disruption Dossier'}
      </button>
    </form>
  );
}

/* =========================================================================
   PARTNERSHIPS & ENTERPRISE DESK
   ========================================================================= */
function PartnershipsDesk({saveHistory}: {saveHistory: any}) {
  const [orgName, setOrgName] = useState('');
  const [email, setEmail] = useState('');
  const [inquiryType, setInquiryType] = useState('Enterprise Research Partnership');
  const [message, setMessage] = useState('');
  const [submittedId, setSubmittedId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = 'REQ-' + Math.floor(100000 + Math.random() * 900000);
    setSubmittedId(id);
    saveHistory('Enterprise Desk Inquiry', `Inquiry Ref: ${id} by ${orgName}`);
  };

  return (
    <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 backdrop-blur-xl border border-cyan-500/40 space-y-6 font-mono shadow-xl">
      <div className="border-b border-slate-800 pb-3">
        <h2 className="text-xl sm:text-2xl font-bold text-cyan-300">
          Enterprise & Institutional Partnerships Portal
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Confidential portal for university labs, public health institutes, civic organizations, and corporate partners.
        </p>
      </div>

      {submittedId ? (
        <div className="p-6 bg-slate-900/80 rounded-2xl border border-emerald-500/40 space-y-3 text-center">
          <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
          <h3 className="text-lg font-bold text-emerald-300">Inquiry Dispatched Successfully</h3>
          <p className="text-xs text-slate-300">Reference ID: <strong className="text-cyan-400">{submittedId}</strong></p>
          <p className="text-xs text-slate-400">Our enterprise technical team will review your parameters within 24 business hours.</p>
          <button onClick={() => setSubmittedId('')} className="mt-2 px-6 py-2 bg-slate-800 rounded-xl text-xs text-slate-300">
            Submit Another Request
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Organization / Entity Name</label>
              <input
                type="text"
                value={orgName}
                onChange={e => setOrgName(e.target.value)}
                placeholder="e.g. Health Systems Institute"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
                required
              />
            </div>
            <div>
              <label className="text-xs text-cyan-400 mb-1 block">Official Contact Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="official@institution.org"
                className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Collaboration Track</label>
            <select
              value={inquiryType}
              onChange={e => setInquiryType(e.target.value)}
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
            >
              <option value="Enterprise Research Partnership">Enterprise Predictive Research</option>
              <option value="Civic Disease Radar Integration">Public Health Radar Integration</option>
              <option value="API Licensing & Supercomputing Access">API Licensing & Data Access</option>
              <option value="Media & Press Inquiry">Media & Technical Inquiries</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-cyan-400 mb-1 block">Scope of Inquiry & Technical Objectives</label>
            <textarea
              value={message}
              onChange={e => setMessage(e.target.value)}
              placeholder="Outline your deployment objectives, data requirements, and partnership timeline..."
              className="w-full p-3 bg-black/60 rounded-xl border border-slate-800 text-sm text-cyan-100 outline-none"
              rows={3}
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-4 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl font-bold text-white shadow-lg transition-all"
          >
            Dispatch Enterprise Inquiry
          </button>
        </form>
      )}
    </div>
  );
}
