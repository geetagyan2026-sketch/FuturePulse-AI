import {GoogleGenAI, Type} from '@google/genai';

const DEFAULT_GEMINI_API_KEY = "AQ.Ab8RN6JCviydgmyU9LNv6FiFNe6p_FQX2AQjwdlJu_bjv9RSOg";
export const GEMINI_MODEL = 'gemini-3.1-flash-lite';
const REQUEST_TIMEOUT_MS = 15000;

export function getGeminiApiKey(): string {
  return DEFAULT_GEMINI_API_KEY;
}

function getAiClient(): GoogleGenAI {
  return new GoogleGenAI({apiKey: DEFAULT_GEMINI_API_KEY});
}

function parseJsonResponse<T>(rawText: string | undefined): T {
  const text = (rawText || '{}').trim();
  const cleaned = text
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```\s*$/i, '')
    .trim();

  try {
    return JSON.parse(cleaned) as T;
  } catch {
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace > firstBrace) {
      return JSON.parse(cleaned.slice(firstBrace, lastBrace + 1)) as T;
    }
    throw new Error('Invalid JSON returned by Gemini AI.');
  }
}

function extractInlinePart(dataUrl: string): {inlineData: {data: string; mimeType: string}} {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (match) {
    return {
      inlineData: {
        mimeType: match[1],
        data: match[2],
      },
    };
  }
  return {
    inlineData: {
      mimeType: 'image/jpeg',
      data: dataUrl.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, ''),
    },
  };
}

function normalizeGeminiError(error: unknown): Error {
  if (error instanceof Error) {
    return error;
  }
  return new Error(String(error) || 'Gemini AI request failed.');
}

async function withTimeout<R>(ms: number, task: Promise<R>, message: string): Promise<R> {
  let timeoutId: ReturnType<typeof setTimeout> | undefined;
  try {
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutId = setTimeout(() => {
        reject(new Error(message));
      }, ms);
    });
    return await Promise.race([task, timeoutPromise]);
  } finally {
    if (timeoutId !== undefined) {
      clearTimeout(timeoutId);
    }
  }
}

function canAttemptServerFallback(): boolean {
  if (typeof window === 'undefined') return false;
  const proto = window.location?.protocol || '';
  return proto === 'http:' || proto === 'https:';
}

async function generateStructured<T>(options: {
  contents: any;
  responseSchema: any;
}): Promise<{data: T; sources: Array<{title: string; uri: string}>; usedFallback: boolean}> {
  const ai = getAiClient();

  // 1. Primary path: Direct @google/genai SDK call (works natively on standalone Android APK / Capacitor WebView with zero backend)
  let directError: unknown;
  try {
    const response = await withTimeout(
      REQUEST_TIMEOUT_MS,
      ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: options.contents,
        config: {
          responseMimeType: 'application/json',
          responseSchema: options.responseSchema,
        },
      }),
      'Request timed out after 15 seconds. Please check your internet connection and try again.'
    );

    return {
      data: parseJsonResponse<T>(response.text),
      sources: [],
      usedFallback: false,
    };
  } catch (err) {
    directError = err;
  }

  // 2. Sandbox fallback: If running in an HTTP/HTTPS browser preview with local Express proxy, fall back to POST /api/generate
  if (canAttemptServerFallback()) {
    let response: Response;
    try {
      response = await withTimeout(
        REQUEST_TIMEOUT_MS,
        fetch('/api/generate', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            model: GEMINI_MODEL,
            contents: options.contents,
            responseSchema: options.responseSchema,
          }),
        }),
        'Server fallback timed out after 15 seconds. Please try again.'
      );
    } catch {
      throw normalizeGeminiError(directError);
    }

    const contentType = response.headers.get('content-type') || '';
    if (
      response.status === 404 ||
      response.status === 405 ||
      !contentType.includes('application/json')
    ) {
      throw normalizeGeminiError(directError);
    }

    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload) {
      throw new Error(payload?.error || `Server error (${response.status}). Please try again.`);
    }

    return {
      data: parseJsonResponse<T>(payload.text),
      sources: [],
      usedFallback: true,
    };
  }

  throw normalizeGeminiError(directError);
}

/* =========================================================================
   1. PERSONAL FUTURE DASHBOARD (3-Scenario Search-Grounded Future Engine)
   ========================================================================= */
export interface PersonalFutureMilestone {
  year: string;
  milestoneEnglish: string;
  milestoneHindi: string;
  estimatedIncome: string;
}

export interface PersonalFutureResult {
  locationMarketInsight: string;
  locationMarketInsightHindi: string;
  pathA: {
    title: string;
    fiveYearIncomeEstimate: string;
    summaryEnglish: string;
    summaryHindi: string;
    keyIndicators: string[];
  };
  pathB: {
    title: string;
    fiveYearRiskOutcome: string;
    summaryEnglish: string;
    summaryHindi: string;
    warningTriggers: string[];
  };
  pathC: {
    title: string;
    fiveYearIncomeEstimate: string;
    summaryEnglish: string;
    summaryHindi: string;
    requiredSkillsAndSteps: string[];
    yearlyMilestones: PersonalFutureMilestone[];
  };
  sources?: Array<{title: string; uri: string}>;
  usedFallback?: boolean;
}

export async function runPersonalFutureForecast(params: {
  name: string;
  age: string;
  location: string;
  currentIncome: string;
  savingsAssets: string;
  keySkills: string;
  fiveYearGoal: string;
  focus: string;
}): Promise<PersonalFutureResult> {
  const userLoc = params.location?.trim() || 'India';
  const userAge = params.age?.trim() || '25';
  const userIncome = params.currentIncome?.trim() || '₹0 (Student / Starting Out)';

  const prompt = `Analyze current ${userLoc} industry demand & salary benchmarks for this profile:
- Name: "${params.name || 'User'}", Age: ${userAge}, Location: "${userLoc}"
- Income: "${userIncome}", Savings: "${params.savingsAssets || 'Minimal'}"
- Skills/Education: "${params.keySkills || 'Foundational skills'}"
- 5-Year Goal: "${params.fiveYearGoal || params.focus || 'Career and financial independence'}"
- Question: "${params.focus || '5-Year career and income outlook'}"

Return a concise, structured 3-Scenario 5-Year Forecast tailored to ${userLoc} (keep text crisp for fast mobile loading):
- pathA (Current Trajectory if no upskilling): 1-2 line English & Hindi summary + EXACTLY 3-4 short bullet points in keyIndicators.
- pathB (High-Risk Path if skills/health ignored): 1-2 line English & Hindi summary + EXACTLY 3-4 short bullet points in warningTriggers.
- pathC (Best Possible Future with peak realistic ${userLoc} income): 1-2 line English & Hindi summary + EXACTLY 3-4 short bullet points in requiredSkillsAndSteps + 5 crisp yearlyMilestones (Year 1 to Year 5).

Return strictly JSON with exact keys:
{
  "locationMarketInsight": string,
  "locationMarketInsightHindi": string,
  "pathA": { "title": string, "fiveYearIncomeEstimate": string, "summaryEnglish": string, "summaryHindi": string, "keyIndicators": string[] },
  "pathB": { "title": string, "fiveYearRiskOutcome": string, "summaryEnglish": string, "summaryHindi": string, "warningTriggers": string[] },
  "pathC": {
    "title": string, "fiveYearIncomeEstimate": string, "summaryEnglish": string, "summaryHindi": string,
    "requiredSkillsAndSteps": string[],
    "yearlyMilestones": [{ "year": string, "milestoneEnglish": string, "milestoneHindi": string, "estimatedIncome": string }]
  }
}`;

  const {data, sources, usedFallback} = await generateStructured<PersonalFutureResult>({
    contents: prompt,
    responseSchema: {
      type: Type.OBJECT,
      required: ['locationMarketInsight', 'locationMarketInsightHindi', 'pathA', 'pathB', 'pathC'],
      properties: {
        locationMarketInsight: {type: Type.STRING},
        locationMarketInsightHindi: {type: Type.STRING},
        pathA: {
          type: Type.OBJECT,
          required: ['title', 'fiveYearIncomeEstimate', 'summaryEnglish', 'summaryHindi', 'keyIndicators'],
          properties: {
            title: {type: Type.STRING},
            fiveYearIncomeEstimate: {type: Type.STRING},
            summaryEnglish: {type: Type.STRING},
            summaryHindi: {type: Type.STRING},
            keyIndicators: {type: Type.ARRAY, items: {type: Type.STRING}},
          },
        },
        pathB: {
          type: Type.OBJECT,
          required: ['title', 'fiveYearRiskOutcome', 'summaryEnglish', 'summaryHindi', 'warningTriggers'],
          properties: {
            title: {type: Type.STRING},
            fiveYearRiskOutcome: {type: Type.STRING},
            summaryEnglish: {type: Type.STRING},
            summaryHindi: {type: Type.STRING},
            warningTriggers: {type: Type.ARRAY, items: {type: Type.STRING}},
          },
        },
        pathC: {
          type: Type.OBJECT,
          required: [
            'title',
            'fiveYearIncomeEstimate',
            'summaryEnglish',
            'summaryHindi',
            'requiredSkillsAndSteps',
            'yearlyMilestones',
          ],
          properties: {
            title: {type: Type.STRING},
            fiveYearIncomeEstimate: {type: Type.STRING},
            summaryEnglish: {type: Type.STRING},
            summaryHindi: {type: Type.STRING},
            requiredSkillsAndSteps: {type: Type.ARRAY, items: {type: Type.STRING}},
            yearlyMilestones: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ['year', 'milestoneEnglish', 'milestoneHindi', 'estimatedIncome'],
                properties: {
                  year: {type: Type.STRING},
                  milestoneEnglish: {type: Type.STRING},
                  milestoneHindi: {type: Type.STRING},
                  estimatedIncome: {type: Type.STRING},
                },
              },
            },
          },
        },
      },
    },
  });

  return {...data, sources, usedFallback};
}

/* =========================================================================
   2. HEALTH SCANNER - AI EYE VISUAL HEALTH CHECK
   ========================================================================= */
export async function runEyeScanAnalysis(imageBase64: string) {
  const prompt = `Perform an AI Eye Visual Health Check on this close-up open-eye photograph.
  Evaluate external wellness indicators:
  1. Scleral yellowness / icterus (screening indicator for liver wellness & bilirubin).
  2. Conjunctival vascular redness / injection (screening for digital screen strain, fatigue, allergy, or vascular stress).
  3. Palpebral conjunctival pallor / pale lower eyelids (screening indicator for anemia / iron vitality).
  4. Periorbital dark circles / puffiness (screening for sleep deficit & systemic fatigue).

  Use non-prescriptive medical hedging language ("potential indicator", "consistent with", "for awareness only").
  Provide concise results:
  1. presentWellnessSummary (2 crisp sentences in bilingual Hindi & English).
  2. futureLifestylePrevention (2-3 crisp sentences with preventive guidance in bilingual Hindi & English).
  3. fatigueScore (number 0-100).
  4. scleralHealthScore (number 0-100, where 100 is pristine clear sclera).
  5. jaundiceScreening (string, e.g. "Normal Clear Sclera (Low Icterus Indicator)" or "Mild Yellowish Tint Observed").
  6. anemiaScreening (string, e.g. "Healthy Inner Eyelid Perfusion" or "Mild Pallor Observed").
  7. stressFatigueLevel (string, e.g. "Minimal Strain" or "Moderate Digital Eye Strain").
  8. clinicalObservations (array of 3 concise observations in bilingual English & Hindi).
  Return strictly as JSON.`;

  const contents = imageBase64
    ? {parts: [extractInlinePart(imageBase64), {text: prompt}]}
    : prompt;

  const {data} = await generateStructured<any>({
    contents,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        presentWellnessSummary: {type: Type.STRING},
        futureLifestylePrevention: {type: Type.STRING},
        fatigueScore: {type: Type.NUMBER},
        scleralHealthScore: {type: Type.NUMBER},
        jaundiceScreening: {type: Type.STRING},
        anemiaScreening: {type: Type.STRING},
        stressFatigueLevel: {type: Type.STRING},
        clinicalObservations: {type: Type.ARRAY, items: {type: Type.STRING}},
      },
    },
  });

  return data;
}

/* =========================================================================
   3. HEALTH SCANNER - MEDICAL LAB REPORT READER
   ========================================================================= */
export async function runLabReportAnalysis(imageBase64: string) {
  const prompt = `Analyze this medical lab report image (blood, liver, kidney, lipid, or glucose). Explain the values clearly and concisely in Hindi and English. Provide:
  1. reportSummary (concise explanation of markers in bilingual Hindi & English).
  2. dietTips (array of 3-4 dietary recommendation strings).
  3. doctorQuestions (array of 3-4 questions to ask a licensed doctor).
  4. abnormalMarkers (array of strings highlighting any elevated/low values).
  Return strictly as JSON.`;

  const contents = imageBase64
    ? {parts: [extractInlinePart(imageBase64), {text: prompt}]}
    : prompt;

  const {data} = await generateStructured<any>({
    contents,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        reportSummary: {type: Type.STRING},
        dietTips: {type: Type.ARRAY, items: {type: Type.STRING}},
        doctorQuestions: {type: Type.ARRAY, items: {type: Type.STRING}},
        abnormalMarkers: {type: Type.ARRAY, items: {type: Type.STRING}},
      },
    },
  });

  return data;
}

/* =========================================================================
   4. HEALTH PREDICTOR - COMPREHENSIVE PRESENT & 5-YEAR DISEASE ANALYZER
   ========================================================================= */
export async function runComprehensiveHealthAnalysis(params: {
  age: string;
  gender: string;
  heightCm: string;
  weightKg: string;
  vitals: {bpm: number | null; spo2: string | null; bp: string | null; source?: string};
  symptoms: string;
  lifestyle: {sleepHours: string; exercise: string; habits: string; stress: string};
  familyHistory: string;
  eyeFindings?: any;
  labFindings?: string;
}) {
  const heightM = (Number(params.heightCm) || 172) / 100;
  const weight = Number(params.weightKg) || 68;
  const bmiVal = +(weight / (heightM * heightM)).toFixed(1);

  const bpmText = params.vitals.bpm ? `${params.vitals.bpm} BPM` : 'Not scanned yet';
  const spo2Text = params.vitals.spo2 ? `${params.vitals.spo2}%` : 'Not synced via Smartwatch Hub';
  const bpText = params.vitals.bp ? `${params.vitals.bp} mmHg` : 'Not synced via Smartwatch Hub';

  const prompt = `Synthesize a non-prescriptive, medically compliant Health Status & 5-Year Disease Risk Prediction (keep points crisp & fast):
  Patient Profile:
  - Age: ${params.age || 30} | Gender: ${params.gender || 'Unspecified'}
  - Height: ${params.heightCm || 172} cm | Weight: ${params.weightKg || 68} kg | Computed BMI: ${bmiVal}
  - Biometric Vitals: Heart Rate: ${bpmText}, Blood Oxygen (SpO2): ${spo2Text}, Blood Pressure: ${bpText}
  - AI Eye Visual Health Findings: ${
    params.eyeFindings
      ? `Scleral Health: ${params.eyeFindings.scleralHealthScore}/100, Fatigue: ${params.eyeFindings.fatigueScore}/100, Jaundice Screen: "${params.eyeFindings.jaundiceScreening}", Anemia Screen: "${params.eyeFindings.anemiaScreening}"`
      : 'Not captured yet'
  }
  - Current Symptoms Reported: "${params.symptoms || 'None reported (preventive wellness check)'}"
  - Lifestyle Factors: Sleep: ${params.lifestyle.sleepHours}, Exercise: "${params.lifestyle.exercise}", Habits: "${params.lifestyle.habits}", Stress: "${params.lifestyle.stress}"
  - Family Medical History: "${params.familyHistory || 'No major premature chronic diseases reported'}"
  - Optional Lab Report Markers: "${params.labFindings || 'None uploaded'}"

  Provide:
  1. biologicalAge (number).
  2. longevityScore (number 0-100).
  3. bmiStatus (string e.g. "Normal Weight (BMI ${bmiVal})").
  4. presentConditions: Array of 3 realistic present differential indicators ({ condition, probability, severity, description, keyIndicators } concise in bilingual English & Hindi).
  5. futureDiseaseRisks: Array of EXACTLY 4 distinct 5-Year Future Disease Risk assessments covering:
     a. "Cardiovascular & Heart Health (हृदय स्वास्थ्य)"
     b. "Liver Vitality & Scleral Wellness (लिवर स्वास्थ्य)"
     c. "Renal & Kidney Filtration Function (किडनी स्वास्थ्य)"
     d. "Type-2 Diabetes & Metabolic Syndrome (डायबिटीज व मेटाबॉलिक)"
     Each with: disease, riskPercentage (0-100), riskLevel ("Low", "Moderate", "Elevated"), vulnerabilityWindow, progressionFactors, clinicalPreventionTips (2-3 crisp items in bilingual English & Hindi).
  6. actionablePreventionPlan: Array of 4 concrete preventive recovery steps in bilingual English & Hindi.
  7. executiveSummary: Concise narrative summary in bilingual English & Hindi.
  8. medicalDisclaimer: Standard non-prescriptive medical disclaimer.
  Return strictly as JSON.`;

  const {data} = await generateStructured<any>({
    contents: prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        biologicalAge: {type: Type.NUMBER},
        longevityScore: {type: Type.NUMBER},
        bmiStatus: {type: Type.STRING},
        presentConditions: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              condition: {type: Type.STRING},
              probability: {type: Type.NUMBER},
              severity: {type: Type.STRING},
              description: {type: Type.STRING},
              keyIndicators: {type: Type.STRING},
            },
          },
        },
        futureDiseaseRisks: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              disease: {type: Type.STRING},
              riskPercentage: {type: Type.NUMBER},
              riskLevel: {type: Type.STRING},
              vulnerabilityWindow: {type: Type.STRING},
              progressionFactors: {type: Type.STRING},
              clinicalPreventionTips: {type: Type.ARRAY, items: {type: Type.STRING}},
            },
          },
        },
        actionablePreventionPlan: {type: Type.ARRAY, items: {type: Type.STRING}},
        executiveSummary: {type: Type.STRING},
        medicalDisclaimer: {type: Type.STRING},
      },
    },
  });

  return data;
}

/* =========================================================================
   5. CAREER PROJECTION ROADMAP
   ========================================================================= */
export async function runCareerPrediction(params: {
  currentRole: string;
  industry: string;
  experienceYears: string;
  currentSkills: string;
  primaryGoal: string;
  language?: string;
}) {
  const prompt = `Generate a concise 5-Year Career, AI Impact & Salary Growth Forecast for:
  - Role: "${params.currentRole || 'Software Professional'}", Industry: "${params.industry || 'Technology'}"
  - Experience: "${params.experienceYears || '3 years'}", Skills: "${params.currentSkills || 'General skills'}"
  - Goal: "${params.primaryGoal || 'Scale income and leadership'}"
  Language: ${params.language || 'English and Hindi (bilingual)'}.

  Provide:
  1. aiAutomationRiskScore (number 0-100).
  2. jobLongevityRating (string e.g. "High (88%)").
  3. topOpportunities (array of 3 concise high-income skills/opportunities for next 12 months in bilingual English & Hindi).
  4. actionPlan (array of 3-4 concise step-by-step actions in bilingual English & Hindi).
  5. forecastSummary (concise summary in bilingual Hindi & English).
  Return strictly JSON with keys: aiAutomationRiskScore, jobLongevityRating, topOpportunities, actionPlan, forecastSummary.`;

  const {data} = await generateStructured<any>({
    contents: prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        aiAutomationRiskScore: {type: Type.NUMBER},
        jobLongevityRating: {type: Type.STRING},
        topOpportunities: {type: Type.ARRAY, items: {type: Type.STRING}},
        actionPlan: {type: Type.ARRAY, items: {type: Type.STRING}},
        forecastSummary: {type: Type.STRING},
      },
    },
  });

  return data;
}

/* =========================================================================
   6. COMPANY, FIRM & TRUST FUTURE ANALYZER (Google Search Grounded)
   ========================================================================= */
export async function runCompanyTrustForecast(params: {
  entityName: string;
  entityType: string;
  industry: string;
  location: string;
  currentStatus: string;
}) {
  const prompt = `Analyze current market trends and generate a concise strategic forecast for:
  - Entity: "${params.entityName || 'Enterprise Entity'}" (${params.entityType || 'Company/Firm/Trust'})
  - Industry: "${params.industry || 'Commercial & Service'}", Location: "${params.location || 'India'}"
  - Status: "${params.currentStatus || 'Operational'}"

  Return strictly JSON with exact keys:
  {
    "profitProbability": number (0-100),
    "lossProbability": number (0-100),
    "marketSurvivalRating": string,
    "whatToDo": string[] (3-4 crisp bilingual Hindi & English bullet points),
    "whatToAvoid": string[] (3-4 crisp bilingual Hindi & English bullet points),
    "marketDemandTrends": string (concise bilingual Hindi & English),
    "regulatoryRisks": string (concise bilingual Hindi & English),
    "growthOpportunities": string[] (3 concise points),
    "executiveSummary": string (concise bilingual Hindi & English),
    "dataConfidenceScore": number (0-100)
  }`;

  const {data, sources, usedFallback} = await generateStructured<any>({
    contents: prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        profitProbability: {type: Type.NUMBER},
        lossProbability: {type: Type.NUMBER},
        marketSurvivalRating: {type: Type.STRING},
        whatToDo: {type: Type.ARRAY, items: {type: Type.STRING}},
        whatToAvoid: {type: Type.ARRAY, items: {type: Type.STRING}},
        marketDemandTrends: {type: Type.STRING},
        regulatoryRisks: {type: Type.STRING},
        growthOpportunities: {type: Type.ARRAY, items: {type: Type.STRING}},
        executiveSummary: {type: Type.STRING},
        dataConfidenceScore: {type: Type.NUMBER},
      },
    },
  });

  return {...data, sources, usedFallback};
}

/* =========================================================================
   7. DISEASE & OUTBREAK EARLY WARNING RADAR (Google Search Grounded)
   ========================================================================= */
export async function runDiseaseRadar(locationQuery: string) {
  const loc = locationQuery || 'India';
  const prompt = `Search latest public health alerts (WHO, ICMR, NCDC, local health bulletins) and seasonal disease patterns for "${loc}".
  Return strictly JSON with exact keys:
  {
    "location": string,
    "alertLevel": string ("Moderate Surveillance" | "Elevated Caution" | "Baseline Stability"),
    "currentActiveAlerts": [{ "diseaseName": string, "severity": string, "description": string, "trend": string }] (3 concise items in bilingual Hindi & English),
    "threeMonthForecast": string (concise 3-month seasonal forecast in bilingual Hindi & English),
    "preventiveSafetyMeasures": string[] (3-4 concise preventive points in bilingual Hindi & English),
    "riskIndicators": { "vectorBorne": number, "respiratoryViral": number, "waterborne": number, "climateStress": number },
    "dataConfidenceScore": number (0-100),
    "publicHealthNotice": string
  }`;

  const {data, sources, usedFallback} = await generateStructured<any>({
    contents: prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        location: {type: Type.STRING},
        alertLevel: {type: Type.STRING},
        currentActiveAlerts: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              diseaseName: {type: Type.STRING},
              severity: {type: Type.STRING},
              description: {type: Type.STRING},
              trend: {type: Type.STRING},
            },
          },
        },
        threeMonthForecast: {type: Type.STRING},
        preventiveSafetyMeasures: {type: Type.ARRAY, items: {type: Type.STRING}},
        riskIndicators: {
          type: Type.OBJECT,
          properties: {
            vectorBorne: {type: Type.NUMBER},
            respiratoryViral: {type: Type.NUMBER},
            waterborne: {type: Type.NUMBER},
            climateStress: {type: Type.NUMBER},
          },
        },
        dataConfidenceScore: {type: Type.NUMBER},
        publicHealthNotice: {type: Type.STRING},
      },
    },
  });

  return {...data, sources, usedFallback};
}

/* =========================================================================
   8. MACRO GEOPOLITICAL INTELLIGENCE (Google Search Grounded)
   ========================================================================= */
export async function runMacroForecast(countryOrTopic: string) {
  const queryTarget = countryOrTopic || 'Global';
  const prompt = `Search latest verified news, economic indicators, policy updates, or election developments for "${queryTarget}".
  Return strictly JSON with exact keys:
  {
    "presentSituationSummary": string (concise 2-3 sentence overview in bilingual English & Hindi),
    "futureImpactForecast": string (concise 1-3 year forecast in bilingual English & Hindi),
    "policyImpactScore": number (0-100),
    "dataConfidenceScore": number (0-100),
    "keyFactualFactors": string[] (3-4 crisp factual bullet points),
    "scenarioBreakdown": { "scenarioA": string, "scenarioB": string },
    "electoralSentiment": { "Optimistic / Growth": number, "Cautious / Defensive": number, "Neutral / Mixed": number },
    "economicTrend": string
  }`;

  const {data, sources, usedFallback} = await generateStructured<any>({
    contents: prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        presentSituationSummary: {type: Type.STRING},
        futureImpactForecast: {type: Type.STRING},
        policyImpactScore: {type: Type.NUMBER},
        dataConfidenceScore: {type: Type.NUMBER},
        keyFactualFactors: {type: Type.ARRAY, items: {type: Type.STRING}},
        scenarioBreakdown: {
          type: Type.OBJECT,
          properties: {
            scenarioA: {type: Type.STRING},
            scenarioB: {type: Type.STRING},
          },
        },
        electoralSentiment: {
          type: Type.OBJECT,
          properties: {
            'Optimistic / Growth': {type: Type.NUMBER},
            'Cautious / Defensive': {type: Type.NUMBER},
            'Neutral / Mixed': {type: Type.NUMBER},
          },
        },
        economicTrend: {type: Type.STRING},
      },
    },
  });

  return {...data, sources, usedFallback};
}

/* =========================================================================
   9. ENTERPRISE DISRUPTIVE INTELLIGENCE (Google Search Grounded)
   ========================================================================= */
export async function runOrgForecast(params: {
  orgType: string;
  ticker?: string;
  region?: string;
  objectives: string;
}) {
  const identifier = params.ticker?.trim() || params.orgType || 'Enterprise';
  const prompt = `Analyze current market & disruption outlook for "${params.orgType}" (Ticker: ${identifier}, Region: ${params.region || 'Global'}).
  Objectives: "${params.objectives || 'Market expansion and AI transformation'}".
  Return strictly JSON with exact keys:
  {
    "disruptionRisk": number (0-100),
    "pivotRoadmap": string[] (3 concise actionable strategy bullets),
    "trajectory": string (concise 2-3 sentence assessment),
    "liveMarket": {
      "identifier": string,
      "marketCapUsd": string,
      "volatilityBeta": number,
      "industryDisruptionIndex": number,
      "competitorPressureScore": number,
      "liquidityRatio": number
    }
  }`;

  const {data, sources, usedFallback} = await generateStructured<any>({
    contents: prompt,
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        disruptionRisk: {type: Type.NUMBER},
        pivotRoadmap: {type: Type.ARRAY, items: {type: Type.STRING}},
        trajectory: {type: Type.STRING},
        liveMarket: {
          type: Type.OBJECT,
          properties: {
            identifier: {type: Type.STRING},
            marketCapUsd: {type: Type.STRING},
            volatilityBeta: {type: Type.NUMBER},
            industryDisruptionIndex: {type: Type.NUMBER},
            competitorPressureScore: {type: Type.NUMBER},
            liquidityRatio: {type: Type.NUMBER},
          },
        },
      },
    },
  });

  return {...data, sources, usedFallback};
}
